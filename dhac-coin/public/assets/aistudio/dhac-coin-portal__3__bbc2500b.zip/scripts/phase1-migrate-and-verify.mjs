#!/usr/bin/env node
/**
 * Phase 1: Data Inspection, Immutable Backup, Validation & SQL Migration Generator
 * DARUL HUDA ISLAMIC UNIVERSITY — ASSAM CENTRE (DHAC Coin Portal)
 *
 * Strictly read-only on existing source files.
 * Generates:
 *   - data/backups/database.backup.2026-11-05.json (exact byte-for-byte backup)
 *   - data/backups/migration-manifest.json (sanitized export + checksums + cohort audit)
 *   - supabase/migrations/202611050001_schema_and_indexes.sql
 *   - supabase/migrations/202611050002_rls_and_atomic_rpcs.sql
 *   - supabase/seed.sql (290 students, 20 mentors, 12 classes, 9 unions, 15 coin categories — zero plaintext passwords)
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, '..');

const DB_PATH = path.join(ROOT, 'data', 'database.json');
const TEACHERS_TS_PATH = path.join(ROOT, 'src', 'data', 'teachers.ts');

const BACKUP_DIR = path.join(ROOT, 'data', 'backups');
const MIGRATIONS_DIR = path.join(ROOT, 'supabase', 'migrations');
const SEED_PATH = path.join(ROOT, 'supabase', 'seed.sql');

fs.mkdirSync(BACKUP_DIR, { recursive: true });
fs.mkdirSync(MIGRATIONS_DIR, { recursive: true });

function sha256(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

function sqlStr(val) {
  if (val === null || val === undefined) return 'NULL';
  return `'${String(val).replace(/'/g, "''")}'`;
}

function sqlInt(val) {
  if (val === null || val === undefined) return 'NULL';
  const n = Number(val);
  if (!Number.isFinite(n)) throw new Error(`Invalid SQL integer: ${val}`);
  return String(Math.trunc(n));
}

function sqlBool(val) {
  return val ? 'TRUE' : 'FALSE';
}

function sanitizeAdSlug(adNo) {
  return String(adNo)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function sanitizeStaffEmail(username) {
  return `${String(username).trim().toLowerCase().replace(/[^a-z0-9._-]+/g, '.')}@faculty.dhac.edu.in`;
}

function sanitizeStudentEmail(adNo) {
  return `stu-${sanitizeAdSlug(adNo)}@student.dhac.edu.in`;
}

console.log('=== DHAC COIN PORTAL — PHASE 1 INSPECTION, BACKUP & MIGRATION GENERATOR ===\n');

// 1. Read & verify raw database.json byte-for-byte
const rawDbBuffer = fs.readFileSync(DB_PATH);
const sourceDigest = sha256(rawDbBuffer);
const db = JSON.parse(rawDbBuffer.toString('utf8'));

// Create exact immutable backup
const BACKUP_FILE = path.join(BACKUP_DIR, 'database.backup.2026-11-05.json');
fs.writeFileSync(BACKUP_FILE, rawDbBuffer);
const backupDigest = sha256(fs.readFileSync(BACKUP_FILE));

if (sourceDigest !== backupDigest) {
  throw new Error('CRITICAL: Backup SHA-256 mismatch!');
}
console.log(`[1/6] Immutable backup created: data/backups/database.backup.2026-11-05.json`);
console.log(`      SHA-256 verified: ${backupDigest}`);

// 2. Parse reference teachers.ts to cross-verify mentor metadata (stripping passwords immediately)
const teachersSource = fs.readFileSync(TEACHERS_TS_PATH, 'utf8');
const parsedTeachers = [];
const teacherLineRegex = /\{\s*serialNo:\s*'([^']+)',\s*teacherId:\s*'([^']+)',\s*name:\s*'([^']+)',\s*username:\s*'([^']+)',\s*password:\s*'([^']+)'\s*\}/g;
let match;
const legacyPasswordsDetected = [];
while ((match = teacherLineRegex.exec(teachersSource)) !== null) {
  parsedTeachers.push({
    serialNo: match[1],
    teacherId: match[2],
    name: match[3],
    username: match[4],
    authEmail: sanitizeStaffEmail(match[4]),
  });
  legacyPasswordsDetected.push(match[5]);
}

const dbTeachers = Array.isArray(db.teachers) && db.teachers.length > 0 ? db.teachers : parsedTeachers;
const cleanMentors = dbTeachers.map((t, idx) => ({
  serialNo: String(t.serialNo || String(idx + 1).padStart(2, '0')),
  staffCode: String(t.teacherId),
  name: String(t.name).trim(),
  username: String(t.username).trim(),
  authEmail: sanitizeStaffEmail(t.username),
}));

if (Array.isArray(db.teachers)) {
  for (const t of db.teachers) {
    if (t.password) legacyPasswordsDetected.push(String(t.password));
  }
}

// 3. Validate Students & Mentors
const students = Array.isArray(db.students) ? db.students : [];
if (students.length !== 290) {
  throw new Error(`Expected 290 students in data/database.json, found ${students.length}`);
}
if (cleanMentors.length !== 20) {
  throw new Error(`Expected 20 mentors, found ${cleanMentors.length}`);
}

const mentorByName = new Map(cleanMentors.map(m => [m.name, m]));
const seenStudentIds = new Set();
const seenAdNos = new Set();
const seenOfficialIds = new Set();

const CLASSES_CONFIG = [
  { code: 'D1', batchName: 'TAIBAH', category: 'Degree', unionId: 'union-taibah', unionName: 'TAIBAH', isNoUnionBatch: false, order: 1 },
  { code: 'D2', batchName: 'MIDAD', category: 'Degree', unionId: 'union-midad', unionName: 'MIDAD', isNoUnionBatch: false, order: 2 },
  { code: 'HS1', batchName: 'USRA', category: 'Higher Secondary', unionId: 'union-usra', unionName: 'USRA', isNoUnionBatch: false, order: 3 },
  { code: 'HS2', batchName: 'IMAD', category: 'Higher Secondary', unionId: 'union-imad', unionName: 'IMAD', isNoUnionBatch: false, order: 4 },
  { code: 'S1A', batchName: '13th Batch', category: 'Secondary', unionId: 'union-13th', unionName: '13th Batch (No Union Created)', isNoUnionBatch: true, order: 5 },
  { code: 'S1B', batchName: '13th Batch', category: 'Secondary', unionId: 'union-13th', unionName: '13th Batch (No Union Created)', isNoUnionBatch: true, order: 6 },
  { code: 'S2A', batchName: 'SAWRA', category: 'Secondary', unionId: 'union-sawra', unionName: 'SAWRA', isNoUnionBatch: false, order: 7 },
  { code: 'S2B', batchName: 'SAWRA', category: 'Secondary', unionId: 'union-sawra', unionName: 'SAWRA', isNoUnionBatch: false, order: 8 },
  { code: 'S3A', batchName: 'QUDWA', category: 'Secondary', unionId: 'union-qudwa', unionName: 'QUDWA', isNoUnionBatch: false, order: 9 },
  { code: 'S3B', batchName: 'QUDWA', category: 'Secondary', unionId: 'union-qudwa', unionName: 'QUDWA', isNoUnionBatch: false, order: 10 },
  { code: 'S4', batchName: 'HIKMA', category: 'Secondary', unionId: 'union-hikma', unionName: 'HIKMA', isNoUnionBatch: false, order: 11 },
  { code: 'S5', batchName: 'IKHWA', category: 'Secondary', unionId: 'union-ikhwa', unionName: 'IKHWA', isNoUnionBatch: false, order: 12 },
];

const validClassCodes = new Set(CLASSES_CONFIG.map(c => c.code));
const classCounts = Object.fromEntries(CLASSES_CONFIG.map(c => [c.code, 0]));
const mentorCounts = Object.fromEntries(cleanMentors.map(m => [m.name, 0]));
const flagCounts = { VALID: 0, ORIGINAL_ASTERISK: 0, MISSING_AD: 0 };

const cleanStudents = students.map((s, idx) => {
  const studentId = String(s.studentId || s.id).trim();
  const adNo = String(s.adNo).trim();
  const officialId = String(s.officialId || `DHAC/ST/2026/${s.className}/${adNo}`).trim();
  const adFlag = String(s.adFlag || 'VALID').trim();
  const name = String(s.name).trim();
  const className = String(s.className).trim();
  const mentorName = String(s.mentorName).trim();
  const totalCoins = Math.max(0, Number(s.totalCoins) || 0);
  const coinStatus = String(s.coinStatus || (totalCoins > 0 ? 'CONFIRMED' : 'ZERO')).trim();
  const rankStatus = String(s.rankStatus || 'OFFICIAL').trim();
  const tier = String(s.tier || 'Zero').trim();
  const notes = String(s.notes || '').trim();

  if (!studentId || seenStudentIds.has(studentId)) {
    throw new Error(`Duplicate or missing studentId at index ${idx}: ${studentId}`);
  }
  if (!adNo || seenAdNos.has(adNo)) {
    throw new Error(`Duplicate or missing adNo at index ${idx}: ${adNo}`);
  }
  if (seenOfficialIds.has(officialId)) {
    throw new Error(`Duplicate officialId at index ${idx}: ${officialId}`);
  }
  if (!validClassCodes.has(className)) {
    throw new Error(`Unknown className for ${studentId}: ${className}`);
  }
  const mentor = mentorByName.get(mentorName);
  if (!mentor) {
    throw new Error(`Orphaned mentorName for ${studentId}: ${mentorName}`);
  }

  seenStudentIds.add(studentId);
  seenAdNos.add(adNo);
  seenOfficialIds.add(officialId);
  classCounts[className] += 1;
  mentorCounts[mentorName] += 1;
  flagCounts[adFlag] = (flagCounts[adFlag] || 0) + 1;

  return {
    studentId,
    officialId,
    adNo,
    adFlag,
    name,
    classCode: className,
    batchName: CLASSES_CONFIG.find(c => c.code === className).batchName,
    mentorStaffCode: mentor.staffCode,
    mentorName,
    authEmail: sanitizeStudentEmail(adNo),
    totalCoins,
    coinStatus,
    rankStatus,
    tier,
    notes,
  };
});

// Assert exact cohort benchmarks
const EXPECTED_CLASS_COUNTS = {
  D1: 15, D2: 14, HS1: 16, HS2: 10,
  S1A: 36, S1B: 38, S2A: 29, S2B: 28,
  S3A: 23, S3B: 21, S4: 33, S5: 27,
};
for (const [cls, expected] of Object.entries(EXPECTED_CLASS_COUNTS)) {
  if (classCounts[cls] !== expected) {
    throw new Error(`Class ${cls} count mismatch: expected ${expected}, got ${classCounts[cls]}`);
  }
}

const zeroMentors = Object.entries(mentorCounts).filter(([, c]) => c === 0);
if (zeroMentors.length > 0) {
  throw new Error(`Found mentors with 0 assigned students: ${JSON.stringify(zeroMentors)}`);
}

const mahmudul = cleanStudents.find(s => s.studentId === 'STU-635');
if (!mahmudul || mahmudul.name !== 'MAHMUDUL HASSAN') {
  throw new Error('Champion record STU-635 spelling check failed!');
}

console.log(`[2/6] Registry & Relationship Validation: ALL PASSED`);
console.log(`      - Total Students: ${cleanStudents.length} (290 unique studentId, 290 unique adNo, 290 unique officialId)`);
console.log(`      - Total Mentors:  ${cleanMentors.length} (0 orphaned mentors, 0 unassigned students)`);
console.log(`      - Class Sizes:    S1A=${classCounts.S1A}, S1B=${classCounts.S1B}, Total across 12 classes=${Object.values(classCounts).reduce((a, b) => a + b, 0)}`);
console.log(`      - AD Hygiene:     VALID=${flagCounts.VALID}, ORIGINAL_ASTERISK=${flagCounts.ORIGINAL_ASTERISK}, MISSING_AD=${flagCounts.MISSING_AD}`);

// 4. Updated Coin Categories & Rules Catalog
const COIN_CATEGORIES_SEED = [
  {
    id: 'publication',
    categoryName: 'PUBLICATION',
    description: 'Literary, journalistic, editorial and creative publications',
    sortOrder: 1,
    activities: [
      { id: 'pub-essay', name: 'Essay & Article', coins: 10, isCustom: false, forClassOnly: false, notes: 'Published article or essay' },
      { id: 'pub-story', name: 'Story', coins: 7, isCustom: false, forClassOnly: false, notes: 'Published creative short story' },
      { id: 'pub-poem', name: 'Poem', coins: 5, isCustom: false, forClassOnly: false, notes: 'Published poem' },
      { id: 'pub-art', name: 'Picture / Painting', coins: 5, isCustom: false, forClassOnly: false, notes: 'Illustrated artwork or painting' },
      { id: 'pub-class-mag', name: 'Class Magazine', coins: 3, isCustom: false, forClassOnly: true, notes: 'Class magazine contribution / edition credit' },
      { id: 'pub-class-news', name: 'Newspaper', coins: 2, isCustom: false, forClassOnly: true, notes: 'Wall / class newspaper bulletin' },
      { id: 'pub-letter-news', name: 'Letter to Newspaper', coins: 10, isCustom: false, forClassOnly: false, notes: 'Published letter in newspaper' },
      { id: 'pub-ind-mag', name: 'Book / Magazine (Individual)', coins: 30, isCustom: false, forClassOnly: false, notes: 'Individual book or magazine publication' },
    ],
  },
  {
    id: 'outer-activities',
    categoryName: 'OUTER ACTIVITIES',
    description: 'Inter-collegiate and external academic representation',
    sortOrder: 2,
    activities: [
      { id: 'outer-paper', name: 'Paper Presentation', coins: 15, isCustom: false, forClassOnly: false, notes: 'External academic paper presentation' },
      { id: 'outer-speech', name: 'Public Speech', coins: 10, isCustom: false, forClassOnly: false, notes: 'External public speech representation' },
    ],
  },
  {
    id: 'inner-campus-contest',
    categoryName: 'INNER CAMPUS CONTEST',
    description: 'Campus-level scholarships and competitive placements',
    sortOrder: 3,
    activities: [
      { id: 'contest-pams', name: 'PAMS Scholarship', coins: 15, isCustom: false, forClassOnly: false, notes: 'PAMS merit scholarship qualifier' },
      { id: 'contest-1st', name: 'First (1st Place)', coins: 7, isCustom: false, forClassOnly: false, notes: 'First place in inner campus contest' },
      { id: 'contest-2nd', name: 'Second (2nd Place)', coins: 5, isCustom: false, forClassOnly: false, notes: 'Second place in inner campus contest' },
      { id: 'contest-3rd', name: 'Third (3rd Place)', coins: 3, isCustom: false, forClassOnly: false, notes: 'Third place in inner campus contest' },
    ],
  },
  {
    id: 'campus-union',
    categoryName: 'CAMPUS UNION',
    description: 'Students Union campus-wide competitions',
    sortOrder: 4,
    activities: [
      { id: 'union-1st', name: 'Campus Union - 1st Place', coins: 7, isCustom: false, forClassOnly: false, notes: null },
      { id: 'union-2nd', name: 'Campus Union - 2nd Place', coins: 5, isCustom: false, forClassOnly: false, notes: null },
      { id: 'union-3rd', name: 'Campus Union - 3rd Place', coins: 3, isCustom: false, forClassOnly: false, notes: null },
    ],
  },
  {
    id: 'class-union',
    categoryName: 'CLASS UNION',
    description: 'Batch & class union weekly competitions',
    sortOrder: 5,
    activities: [
      { id: 'cl-union-1st', name: 'Class Union - 1st Place', coins: 5, isCustom: false, forClassOnly: false, notes: null },
      { id: 'cl-union-2nd', name: 'Class Union - 2nd Place', coins: 3, isCustom: false, forClassOnly: false, notes: null },
      { id: 'cl-union-3rd', name: 'Class Union - 3rd Place', coins: 1, isCustom: false, forClassOnly: false, notes: null },
    ],
  },
  {
    id: 'class-teacher-program',
    categoryName: 'CLASS TEACHER PROGRAM',
    description: 'Class teacher supervised academic activities',
    sortOrder: 6,
    activities: [
      { id: 'ctp-1st', name: 'Class Teacher Program - 1st Place', coins: 6, isCustom: false, forClassOnly: false, notes: null },
      { id: 'ctp-2nd', name: 'Class Teacher Program - 2nd Place', coins: 4, isCustom: false, forClassOnly: false, notes: null },
      { id: 'ctp-3rd', name: 'Class Teacher Program - 3rd Place', coins: 2, isCustom: false, forClassOnly: false, notes: null },
    ],
  },
  {
    id: 'exam-semester',
    categoryName: 'EXAMINATION: Semester Examination',
    description: 'University semester examination percentage tiers',
    sortOrder: 7,
    activities: [
      { id: 'exam-sem-95', name: 'Semester Exam 95%+', coins: 20, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-sem-90', name: 'Semester Exam 90%+', coins: 18, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-sem-85', name: 'Semester Exam 85%+', coins: 16, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-sem-80', name: 'Semester Exam 80%+', coins: 14, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-sem-75', name: 'Semester Exam 75%+', coins: 12, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-sem-70', name: 'Semester Exam 70%+', coins: 10, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-sem-65', name: 'Semester Exam 65%+', coins: 8, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-sem-60', name: 'Semester Exam 60%+', coins: 6, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-sem-55', name: 'Semester Exam 55%+', coins: 4, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-sem-50', name: 'Semester Exam 50%+', coins: 2, isCustom: false, forClassOnly: false, notes: null },
    ],
  },
  {
    id: 'exam-cce',
    categoryName: 'EXAMINATION: CCE Assessment (1st, 2nd & 3rd)',
    description: 'Continuous & Comprehensive Evaluation performance tiers',
    sortOrder: 8,
    activities: [
      { id: 'exam-cce-95', name: 'CCE Assessment 95%+', coins: 10, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-cce-90', name: 'CCE Assessment 90%+', coins: 9, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-cce-85', name: 'CCE Assessment 85%+', coins: 8, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-cce-80', name: 'CCE Assessment 80%+', coins: 7, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-cce-75', name: 'CCE Assessment 75%+', coins: 6, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-cce-70', name: 'CCE Assessment 70%+', coins: 5, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-cce-65', name: 'CCE Assessment 65%+', coins: 4, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-cce-60', name: 'CCE Assessment 60%+', coins: 3, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-cce-55', name: 'CCE Assessment 55%+', coins: 2, isCustom: false, forClassOnly: false, notes: null },
      { id: 'exam-cce-50', name: 'CCE Assessment 50%+', coins: 1, isCustom: false, forClassOnly: false, notes: null },
    ],
  },
  {
    id: 'ibadath',
    categoryName: 'IBADATH',
    description: 'Spiritual leadership and campus mosque responsibilities',
    sortOrder: 9,
    activities: [
      { id: 'iba-imam', name: 'Al-Imam', coins: 5, isCustom: false, forClassOnly: false, notes: null },
      { id: 'iba-haddad', name: 'Haddad Leading', coins: 10, isCustom: false, forClassOnly: false, notes: null },
      { id: 'iba-ziyarat', name: 'Ziyarat / Dua', coins: 3, isCustom: false, forClassOnly: false, notes: null },
      { id: 'iba-azan', name: 'Azan', coins: 3, isCustom: false, forClassOnly: false, notes: null },
    ],
  },
  {
    id: 'special-appreciation',
    categoryName: 'SPECIAL APPRECIATION',
    description: 'Discretionary faculty & principal commendations',
    sortOrder: 10,
    activities: [
      { id: 'spec-teacher', name: 'Class Teacher Appreciation', coins: null, isCustom: true, forClassOnly: false, notes: 'Custom coin amount approved by faculty/admin' },
      { id: 'spec-principal', name: 'Principal Appreciation', coins: null, isCustom: true, forClassOnly: false, notes: 'Custom coin amount approved by Principal/Super Admin' },
    ],
  },
  {
    id: 'self-improvements',
    categoryName: 'SELF IMPROVEMENTS',
    description: 'Measurable academic & behavioral improvement benchmarks',
    sortOrder: 11,
    activities: [
      { id: 'self-70', name: 'Improvement > 70%', coins: 15, isCustom: false, forClassOnly: false, notes: null },
      { id: 'self-65', name: 'Improvement 65%', coins: 13, isCustom: false, forClassOnly: false, notes: null },
      { id: 'self-50', name: 'Improvement 50%', coins: 11, isCustom: false, forClassOnly: false, notes: null },
      { id: 'self-40', name: 'Improvement 40%', coins: 9, isCustom: false, forClassOnly: false, notes: null },
      { id: 'self-30', name: 'Improvement 30%', coins: 7, isCustom: false, forClassOnly: false, notes: null },
      { id: 'self-20', name: 'Improvement 20%', coins: 5, isCustom: false, forClassOnly: false, notes: null },
      { id: 'self-10', name: 'Improvement 10%', coins: 3, isCustom: false, forClassOnly: false, notes: null },
      { id: 'self-5', name: 'Improvement 5%', coins: 1, isCustom: false, forClassOnly: false, notes: null },
    ],
  },
  {
    id: 'special-programs',
    categoryName: 'SPECIAL PROGRAMS (Kulliya, Qawalli, etc.)',
    description: 'Group cultural and linguistic programmes',
    sortOrder: 12,
    activities: [
      { id: 'sp-part', name: 'Group / Kulliya (e.g. Qawalli) - Participation', coins: 5, isCustom: false, forClassOnly: false, notes: null },
      { id: 'sp-1st', name: 'Group / Kulliya (e.g. Qawalli) - 1st Place', coins: 15, isCustom: false, forClassOnly: false, notes: null },
      { id: 'sp-2nd', name: 'Group / Kulliya (e.g. Qawalli) - 2nd Place', coins: 12, isCustom: false, forClassOnly: false, notes: null },
      { id: 'sp-3rd', name: 'Group / Kulliya (e.g. Qawalli) - 3rd Place', coins: 7, isCustom: false, forClassOnly: false, notes: null },
    ],
  },
  {
    id: 'arts-fest-sibaq',
    categoryName: 'ARTS FEST & SIBAQ, 2026',
    description: 'SIBAQ & Arts Fest grade-wise merit points',
    sortOrder: 13,
    activities: [
      { id: 'arts-1st-a', name: 'First (A Grade)', coins: 10, isCustom: false, forClassOnly: false, notes: null },
      { id: 'arts-2nd-a', name: 'Second (A Grade)', coins: 8, isCustom: false, forClassOnly: false, notes: null },
      { id: 'arts-3rd-a', name: 'Third (A Grade)', coins: 6, isCustom: false, forClassOnly: false, notes: null },
      { id: 'arts-1st-b', name: 'First (B Grade)', coins: 8, isCustom: false, forClassOnly: false, notes: null },
      { id: 'arts-2nd-b', name: 'Second (B Grade)', coins: 6, isCustom: false, forClassOnly: false, notes: null },
      { id: 'arts-3rd-b', name: 'Third (B Grade)', coins: 4, isCustom: false, forClassOnly: false, notes: null },
      { id: 'arts-1st-gen', name: 'First (- Grade)', coins: 5, isCustom: false, forClassOnly: false, notes: null },
      { id: 'arts-2nd-gen', name: 'Second (- Grade)', coins: 3, isCustom: false, forClassOnly: false, notes: null },
      { id: 'arts-3rd-gen', name: 'Third (- Grade)', coins: 1, isCustom: false, forClassOnly: false, notes: null },
    ],
  },
  {
    id: 'more-achievement',
    categoryName: 'MORE ACHIEVEMENT, 2026',
    description: 'International, National, State, District & Campus honours',
    sortOrder: 14,
    activities: [
      { id: 'ach-nat-1st', name: 'National & International (1st Place)', coins: 20, isCustom: false, forClassOnly: false, notes: null },
      { id: 'ach-nat-2nd', name: 'National & International (2nd Place)', coins: 15, isCustom: false, forClassOnly: false, notes: null },
      { id: 'ach-nat-3rd', name: 'National & International (3rd Place)', coins: 10, isCustom: false, forClassOnly: false, notes: null },
      { id: 'ach-state-1st', name: 'State & District Level (1st Place)', coins: 15, isCustom: false, forClassOnly: false, notes: null },
      { id: 'ach-state-2nd', name: 'State & District Level (2nd Place)', coins: 10, isCustom: false, forClassOnly: false, notes: null },
      { id: 'ach-state-3rd', name: 'State & District Level (3rd Place)', coins: 5, isCustom: false, forClassOnly: false, notes: null },
      { id: 'ach-campus-1st', name: 'Class & Campus (1st Place)', coins: 12, isCustom: false, forClassOnly: false, notes: null },
      { id: 'ach-campus-2nd', name: 'Class & Campus (2nd Place)', coins: 7, isCustom: false, forClassOnly: false, notes: null },
      { id: 'ach-campus-3rd', name: 'Class & Campus (3rd Place)', coins: 5, isCustom: false, forClassOnly: false, notes: null },
    ],
  },
  {
    id: 'service',
    categoryName: 'SERVICE',
    description: 'Campus community & voluntary service credits',
    sortOrder: 15,
    activities: [
      { id: 'serv-admin', name: 'Service (As per work performed)', coins: null, isCustom: true, forClassOnly: false, notes: 'Custom coin amount approved by Super Admin' },
    ],
  },
];

// Build unique unions list
const unionsMap = new Map();
for (const c of CLASSES_CONFIG) {
  if (!unionsMap.has(c.unionId)) {
    unionsMap.set(c.unionId, {
      id: c.unionId,
      unionName: c.unionName,
      category: c.category,
      isNoUnionBatch: c.isNoUnionBatch,
      classes: [],
    });
  }
  unionsMap.get(c.unionId).classes.push(c.code);
}
const cleanUnions = Array.from(unionsMap.values());

// 5. Write Sanitized Migration Manifest
const manifest = {
  schemaVersion: '2.0.0-supabase',
  institution: 'DARUL HUDA ISLAMIC UNIVERSITY — ASSAM CENTRE',
  shortBrand: 'DARUL HUDA ASSAM CENTRE',
  generatedAt: new Date().toISOString(),
  backupFile: 'data/backups/database.backup.2026-11-05.json',
  sourceSha256: sourceDigest,
  backupSha256: backupDigest,
  securitySanitization: {
    plaintextPasswordsImported: 0,
    legacyCredentialTokensStripped: legacyPasswordsDetected.length + 2,
    note: 'All legacy plaintext passwords were excluded. Users authenticate strictly via Supabase Auth.',
  },
  verifiedCounts: {
    students: cleanStudents.length,
    uniqueStudentIds: seenStudentIds.size,
    uniqueAdNos: seenAdNos.size,
    uniqueOfficialIds: seenOfficialIds.size,
    mentors: cleanMentors.length,
    classes: CLASSES_CONFIG.length,
    unions: cleanUnions.length,
    coinCategories: COIN_CATEGORIES_SEED.length,
    coinRules: COIN_CATEGORIES_SEED.reduce((sum, cat) => sum + cat.activities.length, 0),
  },
  classBreakdown: classCounts,
  mentorBreakdown: mentorCounts,
  adFlagBreakdown: flagCounts,
  data: {
    classes: CLASSES_CONFIG,
    unions: cleanUnions,
    mentors: cleanMentors,
    students: cleanStudents,
    coinCategories: COIN_CATEGORIES_SEED,
  },
};

const MANIFEST_FILE = path.join(BACKUP_DIR, 'migration-manifest.json');
fs.writeFileSync(MANIFEST_FILE, JSON.stringify(manifest, null, 2), 'utf8');
console.log(`[3/6] Sanitized manifest written: data/backups/migration-manifest.json`);

// 6. Generate Supabase PostgreSQL Migration 001 (Schema, Constraints, Triggers & Views)
const schemaSql = `-- ============================================================================
-- DHAC COIN PORTAL — SUPABASE POSTGRESQL SCHEMA (MIGRATION 001)
-- Institution: DARUL HUDA ISLAMIC UNIVERSITY — ASSAM CENTRE
-- Safe, idempotent migration preserving all 290 students & 20 faculty mentors
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1. Academic Classes (12 Batches across Degree, Higher Secondary, Secondary)
CREATE TABLE IF NOT EXISTS public.classes (
  code TEXT PRIMARY KEY,
  batch_name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('Degree', 'Higher Secondary', 'Secondary')),
  class_bonus_coins INTEGER NOT NULL DEFAULT 0 CHECK (class_bonus_coins >= 0),
  display_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Student Unions (9 Cohorts)
CREATE TABLE IF NOT EXISTS public.unions (
  id TEXT PRIMARY KEY,
  union_name TEXT NOT NULL UNIQUE,
  category TEXT NOT NULL CHECK (category IN ('Degree', 'Higher Secondary', 'Secondary')),
  is_no_union_batch BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Union <-> Class Association
CREATE TABLE IF NOT EXISTS public.union_classes (
  class_code TEXT PRIMARY KEY REFERENCES public.classes(code) ON UPDATE CASCADE ON DELETE CASCADE,
  union_id TEXT NOT NULL REFERENCES public.unions(id) ON UPDATE CASCADE ON DELETE CASCADE
);

-- 4. Faculty Mentors (20 Verified Hudawi Mentors — ZERO plaintext passwords)
CREATE TABLE IF NOT EXISTS public.mentors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_code TEXT NOT NULL UNIQUE,
  serial_no TEXT NOT NULL,
  name TEXT NOT NULL UNIQUE,
  username TEXT NOT NULL UNIQUE,
  auth_email TEXT UNIQUE,
  department TEXT NOT NULL DEFAULT 'Faculty Mentor',
  avatar_url TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. Students Registry (290 Preserved Student Records)
CREATE TABLE IF NOT EXISTS public.students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id TEXT NOT NULL UNIQUE,
  official_id TEXT NOT NULL UNIQUE,
  ad_no TEXT NOT NULL UNIQUE,
  ad_flag TEXT NOT NULL DEFAULT 'VALID' CHECK (ad_flag IN ('VALID', 'ORIGINAL_ASTERISK', 'MISSING_AD')),
  name TEXT NOT NULL,
  class_code TEXT NOT NULL REFERENCES public.classes(code) ON UPDATE CASCADE ON DELETE RESTRICT,
  mentor_id UUID NOT NULL REFERENCES public.mentors(id) ON UPDATE CASCADE ON DELETE RESTRICT,
  auth_email TEXT UNIQUE,
  total_coins INTEGER NOT NULL DEFAULT 0 CHECK (total_coins >= 0),
  coin_status TEXT NOT NULL DEFAULT 'ZERO' CHECK (coin_status IN ('CONFIRMED', 'MISSING_OR_ZERO', 'ASSUMED_ZERO', 'ZERO')),
  rank_status TEXT NOT NULL DEFAULT 'OFFICIAL' CHECK (rank_status IN ('OFFICIAL', 'PROVISIONAL')),
  tier TEXT NOT NULL DEFAULT 'Zero' CHECK (tier IN ('Diamond', 'Gold', 'Silver', 'Bronze', 'Starter', 'Zero')),
  notes TEXT NOT NULL DEFAULT '',
  photo_url TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_students_class_code ON public.students(class_code);
CREATE INDEX IF NOT EXISTS idx_students_mentor_id ON public.students(mentor_id);
CREATE INDEX IF NOT EXISTS idx_students_total_coins ON public.students(total_coins DESC);
CREATE INDEX IF NOT EXISTS idx_students_ad_no ON public.students(ad_no);

-- 6. Authenticated User Profiles & Role Bindings (RBAC Source of Truth)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT NOT NULL UNIQUE,
  auth_email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('SUPER_ADMIN', 'MENTOR', 'STUDENT')),
  display_name TEXT NOT NULL,
  student_uuid UUID UNIQUE REFERENCES public.students(id) ON DELETE SET NULL,
  mentor_uuid UUID REFERENCES public.mentors(id) ON DELETE SET NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. Coin Categories & Configurable Activity Rules
CREATE TABLE IF NOT EXISTS public.coin_categories (
  id TEXT PRIMARY KEY,
  category_name TEXT NOT NULL UNIQUE,
  description TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.coin_rules (
  id TEXT PRIMARY KEY,
  category_id TEXT NOT NULL REFERENCES public.coin_categories(id) ON UPDATE CASCADE ON DELETE CASCADE,
  activity_name TEXT NOT NULL,
  coin_value INTEGER CHECK (coin_value IS NULL OR coin_value > 0),
  is_custom BOOLEAN NOT NULL DEFAULT FALSE,
  for_class_only BOOLEAN NOT NULL DEFAULT FALSE,
  notes TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_coin_rules_category ON public.coin_rules(category_id);

-- 8. Student Coin Claims (Pending -> Approved / Rejected)
CREATE TABLE IF NOT EXISTS public.coin_claims (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_code TEXT NOT NULL UNIQUE DEFAULT ('CLM-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10))),
  student_uuid UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  mentor_uuid UUID NOT NULL REFERENCES public.mentors(id) ON DELETE RESTRICT,
  category_id TEXT REFERENCES public.coin_categories(id) ON DELETE SET NULL,
  rule_id TEXT REFERENCES public.coin_rules(id) ON DELETE SET NULL,
  category_name TEXT NOT NULL,
  activity_name TEXT NOT NULL,
  coins INTEGER NOT NULL CHECK (coins > 0 AND coins <= 500),
  proof_notes TEXT NOT NULL,
  evidence_path TEXT,
  evidence_mime TEXT,
  idempotency_key TEXT UNIQUE,
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
  submitted_by_uid UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reviewed_by_uid UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewed_by_name TEXT,
  reviewed_at TIMESTAMPTZ,
  rejection_reason TEXT
);

CREATE INDEX IF NOT EXISTS idx_coin_claims_student ON public.coin_claims(student_uuid);
CREATE INDEX IF NOT EXISTS idx_coin_claims_mentor_status ON public.coin_claims(mentor_uuid, status);
CREATE INDEX IF NOT EXISTS idx_coin_claims_submitted_at ON public.coin_claims(submitted_at DESC);

-- 9. Immutable Append-Only Coin Ledger (Single Source of Truth for Coin Balances)
CREATE TABLE IF NOT EXISTS public.coin_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tx_code TEXT NOT NULL UNIQUE DEFAULT ('TX-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10))),
  target_type TEXT NOT NULL CHECK (target_type IN ('STUDENT', 'CLASS')),
  student_uuid UUID REFERENCES public.students(id) ON DELETE RESTRICT,
  class_code TEXT NOT NULL REFERENCES public.classes(code) ON UPDATE CASCADE ON DELETE RESTRICT,
  mentor_uuid UUID REFERENCES public.mentors(id) ON DELETE SET NULL,
  claim_uuid UUID UNIQUE REFERENCES public.coin_claims(id) ON DELETE RESTRICT,
  category_id TEXT REFERENCES public.coin_categories(id) ON DELETE SET NULL,
  rule_id TEXT REFERENCES public.coin_rules(id) ON DELETE SET NULL,
  category_name TEXT NOT NULL,
  activity_name TEXT NOT NULL,
  coins_delta INTEGER NOT NULL CHECK (coins_delta <> 0),
  reversal_of_tx_uuid UUID UNIQUE REFERENCES public.coin_transactions(id) ON DELETE RESTRICT,
  awarded_by_uid UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  awarded_by_name TEXT NOT NULL,
  notes TEXT,
  idempotency_key TEXT UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_target_consistency CHECK (
    (target_type = 'STUDENT' AND student_uuid IS NOT NULL) OR
    (target_type = 'CLASS' AND student_uuid IS NULL)
  )
);

CREATE INDEX IF NOT EXISTS idx_coin_tx_student ON public.coin_transactions(student_uuid);
CREATE INDEX IF NOT EXISTS idx_coin_tx_mentor ON public.coin_transactions(mentor_uuid);
CREATE INDEX IF NOT EXISTS idx_coin_tx_created_at ON public.coin_transactions(created_at DESC);

-- 10. Mentor Group Competitions / Battle Events
CREATE TABLE IF NOT EXISTS public.mentor_group_battles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('UPCOMING', 'ACTIVE', 'COMPLETED')),
  scoring_mode TEXT NOT NULL DEFAULT 'TOTAL_COINS' CHECK (scoring_mode IN ('TOTAL_COINS', 'AVERAGE_PER_MENTEE')),
  prize_label TEXT,
  created_by_uid UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. Immutable Institutional Audit Logs
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_uid UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  actor_username TEXT,
  actor_role TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  before_data JSONB,
  after_data JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON public.audit_logs(created_at DESC);

-- 12. System Settings Singleton
CREATE TABLE IF NOT EXISTS public.system_settings (
  id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  institution_name TEXT NOT NULL DEFAULT 'DARUL HUDA ISLAMIC UNIVERSITY — ASSAM CENTRE',
  short_brand TEXT NOT NULL DEFAULT 'DARUL HUDA ASSAM CENTRE',
  academic_year TEXT NOT NULL DEFAULT '2026-2027',
  allow_public_leaderboard BOOLEAN NOT NULL DEFAULT TRUE,
  allow_student_claims BOOLEAN NOT NULL DEFAULT TRUE,
  require_evidence_photo BOOLEAN NOT NULL DEFAULT FALSE,
  max_claim_coins INTEGER NOT NULL DEFAULT 50 CHECK (max_claim_coins > 0 AND max_claim_coins <= 500),
  tier_thresholds JSONB NOT NULL DEFAULT '{"diamond":60,"gold":30,"silver":15,"bronze":1}'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO public.system_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

-- ============================================================================
-- TRIGGER 1: Enforce Ledger & Audit Log Immutability (Append-Only)
-- ============================================================================
CREATE OR REPLACE FUNCTION public.fn_prevent_ledger_mutation()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE EXCEPTION 'Ledger and audit tables are strictly append-only. Use a compensating reversal transaction instead.';
END;
$$;

DROP TRIGGER IF EXISTS trg_immutable_coin_transactions ON public.coin_transactions;
CREATE TRIGGER trg_immutable_coin_transactions
BEFORE UPDATE OR DELETE ON public.coin_transactions
FOR EACH ROW
EXECUTE FUNCTION public.fn_prevent_ledger_mutation();

DROP TRIGGER IF EXISTS trg_immutable_audit_logs ON public.audit_logs;
CREATE TRIGGER trg_immutable_audit_logs
BEFORE UPDATE OR DELETE ON public.audit_logs
FOR EACH ROW
EXECUTE FUNCTION public.fn_prevent_ledger_mutation();

-- ============================================================================
-- DYNAMIC 1224 COMPETITION RANKING & AGGREGATION VIEWS
-- ============================================================================
CREATE OR REPLACE VIEW public.v_student_leaderboard AS
SELECT
  s.id,
  s.student_id,
  s.official_id,
  s.ad_no,
  s.ad_flag,
  s.name,
  s.class_code AS class_name,
  c.batch_name,
  c.category AS department_category,
  s.mentor_id,
  m.staff_code AS mentor_staff_code,
  m.name AS mentor_name,
  s.total_coins,
  s.coin_status,
  s.rank_status,
  s.tier,
  s.notes,
  s.photo_url,
  s.is_active,
  RANK() OVER (ORDER BY s.total_coins DESC) AS campus_rank_num,
  COUNT(*) OVER () AS campus_total_students,
  RANK() OVER (PARTITION BY s.class_code ORDER BY s.total_coins DESC) AS class_rank_num,
  COUNT(*) OVER (PARTITION BY s.class_code) AS class_size,
  RANK() OVER (PARTITION BY s.mentor_id ORDER BY s.total_coins DESC) AS mentor_rank_num,
  COUNT(*) OVER (PARTITION BY s.mentor_id) AS mentor_group_size,
  s.updated_at
FROM public.students s
JOIN public.classes c ON c.code = s.class_code
JOIN public.mentors m ON m.id = s.mentor_id
WHERE s.is_active = TRUE;

CREATE OR REPLACE VIEW public.v_mentor_standings AS
SELECT
  m.id AS mentor_id,
  m.staff_code,
  m.serial_no,
  m.name AS mentor_name,
  m.username,
  m.avatar_url,
  COUNT(s.id) AS student_count,
  COALESCE(SUM(s.total_coins), 0) AS total_coins,
  ROUND(COALESCE(AVG(s.total_coins), 0)::numeric, 1) AS average_coins,
  COUNT(*) FILTER (WHERE s.total_coins > 0) AS active_students,
  COUNT(*) FILTER (WHERE s.total_coins = 0) AS zero_coin_students,
  RANK() OVER (ORDER BY COALESCE(SUM(s.total_coins), 0) DESC, COALESCE(AVG(s.total_coins), 0) DESC) AS rank
FROM public.mentors m
LEFT JOIN public.students s ON s.mentor_id = m.id AND s.is_active = TRUE
WHERE m.is_active = TRUE
GROUP BY m.id, m.staff_code, m.serial_no, m.name, m.username, m.avatar_url;

CREATE OR REPLACE VIEW public.v_class_standings AS
SELECT
  c.code AS class_name,
  c.batch_name,
  c.category,
  c.display_order,
  COUNT(s.id) AS student_count,
  COALESCE(SUM(s.total_coins), 0) AS student_coins,
  c.class_bonus_coins AS class_award_coins,
  COALESCE(SUM(s.total_coins), 0) + c.class_bonus_coins AS total_coins,
  ROUND(((COALESCE(SUM(s.total_coins), 0) + c.class_bonus_coins)::numeric / GREATEST(COUNT(s.id), 1)), 1) AS average_coins,
  COUNT(*) FILTER (WHERE s.total_coins > 0) AS active_students,
  COUNT(*) FILTER (WHERE s.total_coins = 0) AS zero_coin_students,
  RANK() OVER (ORDER BY (COALESCE(SUM(s.total_coins), 0) + c.class_bonus_coins) DESC) AS rank
FROM public.classes c
LEFT JOIN public.students s ON s.class_code = c.code AND s.is_active = TRUE
GROUP BY c.code, c.batch_name, c.category, c.class_bonus_coins, c.display_order;

CREATE OR REPLACE VIEW public.v_union_standings AS
SELECT
  u.id,
  u.union_name,
  u.category,
  u.is_no_union_batch,
  ARRAY_AGG(DISTINCT uc.class_code ORDER BY uc.class_code) AS classes,
  COALESCE(SUM(cs.student_count), 0) AS student_count,
  COALESCE(SUM(cs.student_coins), 0) AS student_coins,
  COALESCE(SUM(cs.class_award_coins), 0) AS class_award_coins,
  COALESCE(SUM(cs.total_coins), 0) AS total_coins,
  ROUND((COALESCE(SUM(cs.total_coins), 0)::numeric / GREATEST(COALESCE(SUM(cs.student_count), 0), 1)), 1) AS average_coins,
  COALESCE(SUM(cs.active_students), 0) AS active_students,
  COALESCE(SUM(cs.zero_coin_students), 0) AS zero_coin_students,
  RANK() OVER (ORDER BY COALESCE(SUM(cs.total_coins), 0) DESC, (COALESCE(SUM(cs.total_coins), 0)::numeric / GREATEST(COALESCE(SUM(cs.student_count), 0), 1)) DESC) AS rank
FROM public.unions u
JOIN public.union_classes uc ON uc.union_id = u.id
JOIN public.v_class_standings cs ON cs.class_name = uc.class_code
GROUP BY u.id, u.union_name, u.category, u.is_no_union_batch;
`;

fs.writeFileSync(path.join(MIGRATIONS_DIR, '202611050001_schema_and_indexes.sql'), schemaSql, 'utf8');
console.log(`[4/6] Migration 001 created: supabase/migrations/202611050001_schema_and_indexes.sql`);

// 7. Generate Migration 002 (Non-recursive RLS Helpers, Strict RLS Policies, Atomic RPCs, Auth Auto-Link & Storage Bucket Rules)
const rlsSql = `-- ============================================================================
-- DHAC COIN PORTAL — ROW LEVEL SECURITY & ATOMIC RPC ENGINE (MIGRATION 002)
-- Institution: DARUL HUDA ISLAMIC UNIVERSITY — ASSAM CENTRE
-- ============================================================================

-- 1. Non-Recursive Security Helper Functions (SECURITY DEFINER breaks RLS recursion)
CREATE OR REPLACE FUNCTION public.current_app_role()
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid() AND is_active = TRUE LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.current_mentor_uuid()
RETURNS UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT mentor_uuid FROM public.profiles WHERE id = auth.uid() AND is_active = TRUE LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.current_student_uuid()
RETURNS UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT student_uuid FROM public.profiles WHERE id = auth.uid() AND is_active = TRUE LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.is_super_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(public.current_app_role() = 'SUPER_ADMIN', FALSE);
$$;

-- 2. Enable Row Level Security on All Tables
ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.unions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.union_classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mentors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coin_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coin_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coin_claims ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coin_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mentor_group_battles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;

-- 3. Reference Catalog Policies (Read-only for authenticated & public portal view; write restricted to SUPER_ADMIN)
DROP POLICY IF EXISTS "classes_select_all" ON public.classes;
CREATE POLICY "classes_select_all" ON public.classes FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "classes_admin_all" ON public.classes;
CREATE POLICY "classes_admin_all" ON public.classes FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "unions_select_all" ON public.unions;
CREATE POLICY "unions_select_all" ON public.unions FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "unions_admin_all" ON public.unions;
CREATE POLICY "unions_admin_all" ON public.unions FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "union_classes_select_all" ON public.union_classes;
CREATE POLICY "union_classes_select_all" ON public.union_classes FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "union_classes_admin_all" ON public.union_classes;
CREATE POLICY "union_classes_admin_all" ON public.union_classes FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "mentors_select_all" ON public.mentors;
CREATE POLICY "mentors_select_all" ON public.mentors FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "mentors_admin_all" ON public.mentors;
CREATE POLICY "mentors_admin_all" ON public.mentors FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "categories_select_all" ON public.coin_categories;
CREATE POLICY "categories_select_all" ON public.coin_categories FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "categories_admin_all" ON public.coin_categories;
CREATE POLICY "categories_admin_all" ON public.coin_categories FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "rules_select_all" ON public.coin_rules;
CREATE POLICY "rules_select_all" ON public.coin_rules FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "rules_admin_all" ON public.coin_rules;
CREATE POLICY "rules_admin_all" ON public.coin_rules FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "battles_select_all" ON public.mentor_group_battles;
CREATE POLICY "battles_select_all" ON public.mentor_group_battles FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "battles_admin_all" ON public.mentor_group_battles;
CREATE POLICY "battles_admin_all" ON public.mentor_group_battles FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "settings_select_all" ON public.system_settings;
CREATE POLICY "settings_select_all" ON public.system_settings FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "settings_admin_all" ON public.system_settings;
CREATE POLICY "settings_admin_all" ON public.system_settings FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

-- 4. Profiles Policies (Strict RBAC — Users cannot escalate roles or impersonate student_uuid)
DROP POLICY IF EXISTS "profiles_select_policy" ON public.profiles;
CREATE POLICY "profiles_select_policy" ON public.profiles
FOR SELECT USING (
  id = auth.uid()
  OR public.is_super_admin()
  OR (
    public.current_app_role() = 'MENTOR'
    AND student_uuid IN (SELECT s.id FROM public.students s WHERE s.mentor_id = public.current_mentor_uuid())
  )
);

DROP POLICY IF EXISTS "profiles_update_self_display" ON public.profiles;
CREATE POLICY "profiles_update_self_display" ON public.profiles
FOR UPDATE USING (id = auth.uid())
WITH CHECK (
  id = auth.uid()
  AND role = public.current_app_role()
  AND student_uuid IS NOT DISTINCT FROM public.current_student_uuid()
  AND mentor_uuid IS NOT DISTINCT FROM public.current_mentor_uuid()
);

DROP POLICY IF EXISTS "profiles_admin_manage" ON public.profiles;
CREATE POLICY "profiles_admin_manage" ON public.profiles
FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

-- 5. Students Table Policies + Column-Level Coin Tamper Protection
DROP POLICY IF EXISTS "students_select_policy" ON public.students;
CREATE POLICY "students_select_policy" ON public.students
FOR SELECT USING (
  public.is_super_admin()
  OR id = public.current_student_uuid()
  OR (public.current_app_role() = 'MENTOR' AND mentor_id = public.current_mentor_uuid())
  OR COALESCE((SELECT allow_public_leaderboard FROM public.system_settings WHERE id = 1), TRUE)
);

DROP POLICY IF EXISTS "students_admin_insert" ON public.students;
CREATE POLICY "students_admin_insert" ON public.students
FOR INSERT WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "students_admin_delete" ON public.students;
CREATE POLICY "students_admin_delete" ON public.students
FOR DELETE USING (public.is_super_admin());

DROP POLICY IF EXISTS "students_update_policy" ON public.students;
CREATE POLICY "students_update_policy" ON public.students
FOR UPDATE USING (
  public.is_super_admin()
  OR id = public.current_student_uuid()
  OR (public.current_app_role() = 'MENTOR' AND mentor_id = public.current_mentor_uuid())
)
WITH CHECK (
  public.is_super_admin()
  OR id = public.current_student_uuid()
  OR (public.current_app_role() = 'MENTOR' AND mentor_id = public.current_mentor_uuid())
);

-- Automatic Atomic Balance & Tier Sync Trigger (Sets transaction-local app.in_ledger_sync flag)
CREATE OR REPLACE FUNCTION public.fn_sync_balances_on_transaction()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_new_total INTEGER;
  v_new_tier TEXT;
  v_new_status TEXT;
BEGIN
  PERFORM set_config('app.in_ledger_sync', 'true', TRUE);

  IF NEW.target_type = 'STUDENT' AND NEW.student_uuid IS NOT NULL THEN
    UPDATE public.students
    SET
      total_coins = GREATEST(0, total_coins + NEW.coins_delta),
      updated_at = NOW()
    WHERE id = NEW.student_uuid
    RETURNING total_coins INTO v_new_total;

    IF v_new_total >= 60 THEN v_new_tier := 'Diamond';
    ELSIF v_new_total >= 30 THEN v_new_tier := 'Gold';
    ELSIF v_new_total >= 15 THEN v_new_tier := 'Silver';
    ELSIF v_new_total > 0 THEN v_new_tier := 'Bronze';
    ELSE v_new_tier := 'Zero';
    END IF;

    v_new_status := CASE WHEN v_new_total > 0 THEN 'CONFIRMED' ELSE 'ZERO' END;

    UPDATE public.students
    SET
      tier = v_new_tier,
      coin_status = v_new_status,
      rank_status = 'OFFICIAL'
    WHERE id = NEW.student_uuid;
  ELSIF NEW.target_type = 'CLASS' THEN
    UPDATE public.classes
    SET
      class_bonus_coins = GREATEST(0, class_bonus_coins + NEW.coins_delta),
      updated_at = NOW()
    WHERE code = NEW.class_code;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_sync_balances_on_transaction ON public.coin_transactions;
CREATE TRIGGER trg_sync_balances_on_transaction
AFTER INSERT ON public.coin_transactions
FOR EACH ROW
EXECUTE FUNCTION public.fn_sync_balances_on_transaction();

-- Column-Level Tamper Guard on Students (Only photo_url editable by non-admin clients)
CREATE OR REPLACE FUNCTION public.fn_guard_student_protected_columns()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND NOT public.is_super_admin() THEN
    IF NEW.total_coins IS DISTINCT FROM OLD.total_coins
       OR NEW.tier IS DISTINCT FROM OLD.tier
       OR NEW.coin_status IS DISTINCT FROM OLD.coin_status
       OR NEW.student_id IS DISTINCT FROM OLD.student_id
       OR NEW.official_id IS DISTINCT FROM OLD.official_id
       OR NEW.ad_no IS DISTINCT FROM OLD.ad_no
       OR NEW.class_code IS DISTINCT FROM OLD.class_code
       OR NEW.mentor_id IS DISTINCT FROM OLD.mentor_id
       OR NEW.name IS DISTINCT FROM OLD.name
       OR NEW.is_active IS DISTINCT FROM OLD.is_active THEN
      IF current_setting('app.in_ledger_sync', TRUE) IS DISTINCT FROM 'true' THEN
        RAISE EXCEPTION 'Unauthorized column mutation on students table. Coin balances can only change via approved ledger RPCs.';
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_guard_student_protected_columns ON public.students;
CREATE TRIGGER trg_guard_student_protected_columns
BEFORE UPDATE ON public.students
FOR EACH ROW
EXECUTE FUNCTION public.fn_guard_student_protected_columns();

-- 6. Coin Claims Policies (Strict Mentee Isolation)
DROP POLICY IF EXISTS "claims_select_policy" ON public.coin_claims;
CREATE POLICY "claims_select_policy" ON public.coin_claims
FOR SELECT USING (
  public.is_super_admin()
  OR student_uuid = public.current_student_uuid()
  OR (public.current_app_role() = 'MENTOR' AND mentor_uuid = public.current_mentor_uuid())
);

DROP POLICY IF EXISTS "claims_student_insert" ON public.coin_claims;
CREATE POLICY "claims_student_insert" ON public.coin_claims
FOR INSERT WITH CHECK (
  public.current_app_role() = 'STUDENT'
  AND student_uuid = public.current_student_uuid()
  AND status = 'PENDING'
  AND mentor_uuid = (SELECT mentor_id FROM public.students WHERE id = public.current_student_uuid())
);

-- 7. Coin Transactions Policies (Read scoped by role; direct client writes revoked)
DROP POLICY IF EXISTS "transactions_select_policy" ON public.coin_transactions;
CREATE POLICY "transactions_select_policy" ON public.coin_transactions
FOR SELECT USING (
  public.is_super_admin()
  OR student_uuid = public.current_student_uuid()
  OR (
    public.current_app_role() = 'MENTOR'
    AND (
      mentor_uuid = public.current_mentor_uuid()
      OR student_uuid IN (SELECT id FROM public.students WHERE mentor_id = public.current_mentor_uuid())
    )
  )
);

-- 8. Audit Logs Policy (Strict SUPER_ADMIN Read Only)
DROP POLICY IF EXISTS "audit_logs_admin_select" ON public.audit_logs;
CREATE POLICY "audit_logs_admin_select" ON public.audit_logs
FOR SELECT USING (public.is_super_admin());

-- ============================================================================
-- SECURE AUTH USER -> PROFILE BINDING TRIGGER (Zero Privilege Escalation)
-- Automatically binds new Supabase Auth users to their verified institutional row
-- ============================================================================
CREATE OR REPLACE FUNCTION public.fn_auto_link_profile_on_signup()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email TEXT;
  v_mentor public.mentors%ROWTYPE;
  v_student public.students%ROWTYPE;
BEGIN
  v_email := lower(trim(COALESCE(NEW.email, '')));
  IF v_email = '' THEN
    RETURN NEW;
  END IF;

  -- 1. Super Admin canonical email binding
  IF v_email = 'sidra2026@admin.dhac.edu.in' THEN
    INSERT INTO public.profiles (id, username, auth_email, role, display_name)
    VALUES (NEW.id, 'sidra2026', v_email, 'SUPER_ADMIN', 'Super Admin (Sidra)')
    ON CONFLICT (id) DO NOTHING;
    RETURN NEW;
  END IF;

  -- 2. Faculty Mentor email binding
  SELECT * INTO v_mentor FROM public.mentors WHERE lower(auth_email) = v_email AND is_active = TRUE LIMIT 1;
  IF FOUND THEN
    INSERT INTO public.profiles (id, username, auth_email, role, display_name, mentor_uuid)
    VALUES (NEW.id, v_mentor.username, v_email, 'MENTOR', v_mentor.name || ' (' || v_mentor.staff_code || ')', v_mentor.id)
    ON CONFLICT (id) DO NOTHING;
    RETURN NEW;
  END IF;

  -- 3. Student email binding
  SELECT * INTO v_student FROM public.students WHERE lower(auth_email) = v_email AND is_active = TRUE LIMIT 1;
  IF FOUND THEN
    INSERT INTO public.profiles (id, username, auth_email, role, display_name, student_uuid)
    VALUES (NEW.id, 'student_' || v_student.ad_no, v_email, 'STUDENT', v_student.name || ' (AD #' || v_student.ad_no || ')', v_student.id)
    ON CONFLICT (id) DO NOTHING;
    RETURN NEW;
  END IF;

  -- 4. Unmatched email defaults strictly to unlinked STUDENT role (never elevates privileges)
  INSERT INTO public.profiles (id, username, auth_email, role, display_name)
  VALUES (NEW.id, split_part(v_email, '@', 1) || '_' || substr(NEW.id::text, 1, 6), v_email, 'STUDENT', COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(v_email, '@', 1)))
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;

DO $$
BEGIN
  DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
  CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.fn_auto_link_profile_on_signup();
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Auth trigger setup notice: %', SQLERRM;
END $$;

-- ============================================================================
-- SECURE SERVER-ENFORCED ATOMIC RPC FUNCTIONS
-- ============================================================================

-- RPC 1: Resolve Username / AD Number / Staff Code -> Supabase Auth Email
CREATE OR REPLACE FUNCTION public.resolve_login_email(p_identifier TEXT)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_clean TEXT;
  v_email TEXT;
  v_ad TEXT;
BEGIN
  v_clean := trim(COALESCE(p_identifier, ''));
  IF v_clean = '' THEN
    RETURN NULL;
  END IF;

  SELECT auth_email INTO v_email
  FROM public.profiles
  WHERE lower(auth_email) = lower(v_clean) AND is_active = TRUE
  LIMIT 1;
  IF v_email IS NOT NULL THEN RETURN v_email; END IF;

  SELECT auth_email INTO v_email
  FROM public.profiles
  WHERE lower(username) = lower(v_clean) AND is_active = TRUE
  LIMIT 1;
  IF v_email IS NOT NULL THEN RETURN v_email; END IF;

  SELECT auth_email INTO v_email
  FROM public.mentors
  WHERE (lower(username) = lower(v_clean) OR lower(staff_code) = lower(v_clean)) AND is_active = TRUE
  LIMIT 1;
  IF v_email IS NOT NULL THEN RETURN v_email; END IF;

  v_ad := regexp_replace(v_clean, '^(student_|STU-)', '', 'i');
  v_ad := replace(v_ad, '*', '');
  SELECT auth_email INTO v_email
  FROM public.students
  WHERE (lower(ad_no) = lower(v_ad) OR lower(student_id) = lower(v_clean)) AND is_active = TRUE
  LIMIT 1;
  IF v_email IS NOT NULL THEN RETURN v_email; END IF;

  IF lower(v_clean) = 'sidra2026' THEN
    RETURN 'sidra2026@admin.dhac.edu.in';
  END IF;

  RETURN NULL;
END;
$$;

-- RPC 2: Student Submits Coin Claim with Server Rule Validation & Duplicate Guard
CREATE OR REPLACE FUNCTION public.submit_coin_claim(
  p_rule_id TEXT,
  p_proof_notes TEXT,
  p_evidence_path TEXT DEFAULT NULL,
  p_custom_coins INTEGER DEFAULT NULL,
  p_idempotency_key TEXT DEFAULT NULL
)
RETURNS public.coin_claims
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_student_id UUID;
  v_student public.students%ROWTYPE;
  v_rule public.coin_rules%ROWTYPE;
  v_cat public.coin_categories%ROWTYPE;
  v_coins INTEGER;
  v_max_coins INTEGER;
  v_claims_enabled BOOLEAN;
  v_existing public.coin_claims%ROWTYPE;
  v_inserted public.coin_claims%ROWTYPE;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Authentication required.';
  END IF;

  IF public.current_app_role() <> 'STUDENT' THEN
    RAISE EXCEPTION 'Only authenticated students can submit activity claims.';
  END IF;

  SELECT allow_student_claims, max_claim_coins INTO v_claims_enabled, v_max_coins
  FROM public.system_settings WHERE id = 1;
  IF NOT COALESCE(v_claims_enabled, TRUE) THEN
    RAISE EXCEPTION 'Student claim submissions are currently paused by administration.';
  END IF;

  IF p_idempotency_key IS NOT NULL THEN
    SELECT * INTO v_existing FROM public.coin_claims WHERE idempotency_key = p_idempotency_key;
    IF FOUND THEN
      RETURN v_existing;
    END IF;
  END IF;

  v_student_id := public.current_student_uuid();
  SELECT * INTO v_student FROM public.students WHERE id = v_student_id AND is_active = TRUE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Student profile not linked to active student record.';
  END IF;

  SELECT * INTO v_rule FROM public.coin_rules WHERE id = p_rule_id AND is_active = TRUE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Invalid or inactive coin activity rule.';
  END IF;
  SELECT * INTO v_cat FROM public.coin_categories WHERE id = v_rule.category_id;

  IF v_rule.is_custom THEN
    v_coins := COALESCE(p_custom_coins, 0);
  ELSE
    v_coins := v_rule.coin_value;
  END IF;

  IF v_coins IS NULL OR v_coins <= 0 OR v_coins > COALESCE(v_max_coins, 50) THEN
    RAISE EXCEPTION 'Claimed coin value (%) is outside permitted bounds (1..%).', v_coins, COALESCE(v_max_coins, 50);
  END IF;

  IF length(trim(COALESCE(p_proof_notes, ''))) < 4 THEN
    RAISE EXCEPTION 'Please provide meaningful achievement details / proof notes.';
  END IF;

  INSERT INTO public.coin_claims (
    student_uuid,
    mentor_uuid,
    category_id,
    rule_id,
    category_name,
    activity_name,
    coins,
    proof_notes,
    evidence_path,
    idempotency_key,
    status,
    submitted_by_uid
  ) VALUES (
    v_student.id,
    v_student.mentor_id,
    v_cat.id,
    v_rule.id,
    v_cat.category_name,
    v_rule.activity_name,
    v_coins,
    trim(p_proof_notes),
    p_evidence_path,
    p_idempotency_key,
    'PENDING',
    auth.uid()
  )
  RETURNING * INTO v_inserted;

  INSERT INTO public.audit_logs (
    actor_uid, actor_username, actor_role, action, entity_type, entity_id, after_data
  ) VALUES (
    auth.uid(),
    (SELECT username FROM public.profiles WHERE id = auth.uid()),
    'STUDENT',
    'CLAIM_SUBMITTED',
    'coin_claims',
    v_inserted.id::text,
    to_jsonb(v_inserted)
  );

  RETURN v_inserted;
END;
$$;

-- RPC 3: Atomic Mentor / Super Admin Claim Approval (Row-Locked + Single Credit Guarantee)
CREATE OR REPLACE FUNCTION public.approve_coin_claim(p_claim_id UUID)
RETURNS public.coin_transactions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role TEXT;
  v_mentor_id UUID;
  v_reviewer_name TEXT;
  v_reviewer_user TEXT;
  v_claim public.coin_claims%ROWTYPE;
  v_student public.students%ROWTYPE;
  v_tx public.coin_transactions%ROWTYPE;
BEGIN
  v_role := public.current_app_role();
  IF v_role NOT IN ('SUPER_ADMIN', 'MENTOR') THEN
    RAISE EXCEPTION 'Only authorized Mentors or Super Admin can approve coin claims.';
  END IF;

  SELECT display_name, username, mentor_uuid
  INTO v_reviewer_name, v_reviewer_user, v_mentor_id
  FROM public.profiles WHERE id = auth.uid();

  SELECT * INTO v_claim FROM public.coin_claims WHERE id = p_claim_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Claim record not found.';
  END IF;

  IF v_claim.status <> 'PENDING' THEN
    RAISE EXCEPTION 'Claim has already been processed (status: %).', v_claim.status;
  END IF;

  IF v_role = 'MENTOR' AND v_claim.mentor_uuid <> v_mentor_id THEN
    RAISE EXCEPTION 'Access denied: Mentors can only approve claims for their own assigned mentees.';
  END IF;

  SELECT * INTO v_student FROM public.students WHERE id = v_claim.student_uuid FOR UPDATE;

  UPDATE public.coin_claims
  SET
    status = 'APPROVED',
    reviewed_by_uid = auth.uid(),
    reviewed_by_name = v_reviewer_name,
    reviewed_at = NOW()
  WHERE id = p_claim_id;

  INSERT INTO public.coin_transactions (
    target_type,
    student_uuid,
    class_code,
    mentor_uuid,
    claim_uuid,
    category_id,
    rule_id,
    category_name,
    activity_name,
    coins_delta,
    awarded_by_uid,
    awarded_by_name,
    notes
  ) VALUES (
    'STUDENT',
    v_student.id,
    v_student.class_code,
    v_claim.mentor_uuid,
    v_claim.id,
    v_claim.category_id,
    v_claim.rule_id,
    v_claim.category_name,
    v_claim.activity_name,
    v_claim.coins,
    auth.uid(),
    'Confirmed by ' || v_reviewer_name,
    v_claim.proof_notes
  )
  RETURNING * INTO v_tx;

  INSERT INTO public.audit_logs (
    actor_uid, actor_username, actor_role, action, entity_type, entity_id, after_data
  ) VALUES (
    auth.uid(), v_reviewer_user, v_role, 'CLAIM_APPROVED', 'coin_claims', p_claim_id::text,
    jsonb_build_object('claim_id', p_claim_id, 'tx_id', v_tx.id, 'coins', v_claim.coins, 'student_id', v_student.student_id)
  );

  RETURN v_tx;
END;
$$;

-- RPC 4: Atomic Mentor / Super Admin Claim Rejection
CREATE OR REPLACE FUNCTION public.reject_coin_claim(p_claim_id UUID, p_reason TEXT DEFAULT NULL)
RETURNS public.coin_claims
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role TEXT;
  v_mentor_id UUID;
  v_reviewer_name TEXT;
  v_reviewer_user TEXT;
  v_claim public.coin_claims%ROWTYPE;
BEGIN
  v_role := public.current_app_role();
  IF v_role NOT IN ('SUPER_ADMIN', 'MENTOR') THEN
    RAISE EXCEPTION 'Only authorized Mentors or Super Admin can reject coin claims.';
  END IF;

  SELECT display_name, username, mentor_uuid
  INTO v_reviewer_name, v_reviewer_user, v_mentor_id
  FROM public.profiles WHERE id = auth.uid();

  SELECT * INTO v_claim FROM public.coin_claims WHERE id = p_claim_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Claim record not found.';
  END IF;

  IF v_claim.status <> 'PENDING' THEN
    RAISE EXCEPTION 'Claim has already been processed (status: %).', v_claim.status;
  END IF;

  IF v_role = 'MENTOR' AND v_claim.mentor_uuid <> v_mentor_id THEN
    RAISE EXCEPTION 'Access denied: Mentors can only reject claims for their own assigned mentees.';
  END IF;

  UPDATE public.coin_claims
  SET
    status = 'REJECTED',
    reviewed_by_uid = auth.uid(),
    reviewed_by_name = v_reviewer_name,
    reviewed_at = NOW(),
    rejection_reason = NULLIF(trim(COALESCE(p_reason, '')), '')
  WHERE id = p_claim_id
  RETURNING * INTO v_claim;

  INSERT INTO public.audit_logs (
    actor_uid, actor_username, actor_role, action, entity_type, entity_id, after_data
  ) VALUES (
    auth.uid(), v_reviewer_user, v_role, 'CLAIM_REJECTED', 'coin_claims', p_claim_id::text, to_jsonb(v_claim)
  );

  RETURN v_claim;
END;
$$;

-- RPC 5: Direct Atomic Coin Award (Mentors for own mentees / Super Admin for any student or class)
CREATE OR REPLACE FUNCTION public.award_coins_atomic(
  p_target_type TEXT,
  p_student_uuid UUID,
  p_class_code TEXT,
  p_rule_id TEXT,
  p_custom_coins INTEGER DEFAULT NULL,
  p_notes TEXT DEFAULT NULL,
  p_idempotency_key TEXT DEFAULT NULL
)
RETURNS public.coin_transactions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role TEXT;
  v_mentor_id UUID;
  v_actor_name TEXT;
  v_actor_user TEXT;
  v_student public.students%ROWTYPE;
  v_rule public.coin_rules%ROWTYPE;
  v_cat public.coin_categories%ROWTYPE;
  v_coins INTEGER;
  v_existing public.coin_transactions%ROWTYPE;
  v_tx public.coin_transactions%ROWTYPE;
BEGIN
  v_role := public.current_app_role();
  IF v_role NOT IN ('SUPER_ADMIN', 'MENTOR') THEN
    RAISE EXCEPTION 'Access denied: Only Mentors and Super Admin can award coins.';
  END IF;

  IF p_idempotency_key IS NOT NULL THEN
    SELECT * INTO v_existing FROM public.coin_transactions WHERE idempotency_key = p_idempotency_key;
    IF FOUND THEN
      RETURN v_existing;
    END IF;
  END IF;

  SELECT display_name, username, mentor_uuid
  INTO v_actor_name, v_actor_user, v_mentor_id
  FROM public.profiles WHERE id = auth.uid();

  SELECT * INTO v_rule FROM public.coin_rules WHERE id = p_rule_id AND is_active = TRUE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Invalid or inactive coin rule.';
  END IF;
  SELECT * INTO v_cat FROM public.coin_categories WHERE id = v_rule.category_id;

  IF v_rule.is_custom THEN
    v_coins := COALESCE(p_custom_coins, 0);
  ELSE
    v_coins := v_rule.coin_value;
  END IF;

  IF v_coins IS NULL OR v_coins <= 0 OR v_coins > 200 THEN
    RAISE EXCEPTION 'Invalid coin amount: %', v_coins;
  END IF;

  IF p_target_type = 'STUDENT' THEN
    SELECT * INTO v_student FROM public.students WHERE id = p_student_uuid AND is_active = TRUE FOR UPDATE;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Student not found.';
    END IF;
    IF v_role = 'MENTOR' AND v_student.mentor_id <> v_mentor_id THEN
      RAISE EXCEPTION 'Access denied: Mentors can only award coins directly to their own assigned mentees.';
    END IF;

    INSERT INTO public.coin_transactions (
      target_type, student_uuid, class_code, mentor_uuid, category_id, rule_id,
      category_name, activity_name, coins_delta, awarded_by_uid, awarded_by_name, notes, idempotency_key
    ) VALUES (
      'STUDENT', v_student.id, v_student.class_code, v_student.mentor_id, v_cat.id, v_rule.id,
      v_cat.category_name, v_rule.activity_name, v_coins, auth.uid(), v_actor_name, p_notes, p_idempotency_key
    )
    RETURNING * INTO v_tx;
  ELSIF p_target_type = 'CLASS' THEN
    IF v_role <> 'SUPER_ADMIN' THEN
      RAISE EXCEPTION 'Only Super Admin can award class-level batch bonus coins.';
    END IF;
    INSERT INTO public.coin_transactions (
      target_type, student_uuid, class_code, mentor_uuid, category_id, rule_id,
      category_name, activity_name, coins_delta, awarded_by_uid, awarded_by_name, notes, idempotency_key
    ) VALUES (
      'CLASS', NULL, p_class_code, NULL, v_cat.id, v_rule.id,
      v_cat.category_name, v_rule.activity_name, v_coins, auth.uid(), v_actor_name, p_notes, p_idempotency_key
    )
    RETURNING * INTO v_tx;
  ELSE
    RAISE EXCEPTION 'Invalid target_type: %', p_target_type;
  END IF;

  INSERT INTO public.audit_logs (
    actor_uid, actor_username, actor_role, action, entity_type, entity_id, after_data
  ) VALUES (
    auth.uid(), v_actor_user, v_role, 'COINS_AWARDED', 'coin_transactions', v_tx.id::text, to_jsonb(v_tx)
  );

  RETURN v_tx;
END;
$$;

-- RPC 6: Super Admin Compensating Reversal Transaction (Never deletes immutable history)
CREATE OR REPLACE FUNCTION public.reverse_coin_transaction(p_tx_id UUID, p_reason TEXT)
RETURNS public.coin_transactions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_orig public.coin_transactions%ROWTYPE;
  v_actor_name TEXT;
  v_actor_user TEXT;
  v_rev public.coin_transactions%ROWTYPE;
BEGIN
  IF NOT public.is_super_admin() THEN
    RAISE EXCEPTION 'Only Super Admin can reverse ledger transactions.';
  END IF;

  SELECT display_name, username INTO v_actor_name, v_actor_user
  FROM public.profiles WHERE id = auth.uid();

  SELECT * INTO v_orig FROM public.coin_transactions WHERE id = p_tx_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Transaction not found.';
  END IF;
  IF v_orig.coins_delta < 0 THEN
    RAISE EXCEPTION 'Cannot reverse a reversal entry.';
  END IF;

  INSERT INTO public.coin_transactions (
    target_type, student_uuid, class_code, mentor_uuid, category_id, rule_id,
    category_name, activity_name, coins_delta, reversal_of_tx_uuid,
    awarded_by_uid, awarded_by_name, notes
  ) VALUES (
    v_orig.target_type,
    v_orig.student_uuid,
    v_orig.class_code,
    v_orig.mentor_uuid,
    v_orig.category_id,
    v_orig.rule_id,
    'REVERSAL: ' || v_orig.category_name,
    'Reversal of ' || v_orig.activity_name || ' (' || v_orig.tx_code || ')',
    -v_orig.coins_delta,
    v_orig.id,
    auth.uid(),
    v_actor_name,
    COALESCE(NULLIF(trim(p_reason), ''), 'Administrative reversal')
  )
  RETURNING * INTO v_rev;

  INSERT INTO public.audit_logs (
    actor_uid, actor_username, actor_role, action, entity_type, entity_id, before_data, after_data
  ) VALUES (
    auth.uid(), v_actor_user, 'SUPER_ADMIN', 'TX_REVERSED', 'coin_transactions', p_tx_id::text, to_jsonb(v_orig), to_jsonb(v_rev)
  );

  RETURN v_rev;
END;
$$;

-- ============================================================================
-- SUPABASE STORAGE BUCKETS & STRICT EVIDENCE RLS
-- ============================================================================
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  VALUES
    ('claim-evidence', 'claim-evidence', FALSE, 5242880, ARRAY['image/jpeg','image/png','image/webp','application/pdf']),
    ('avatars', 'avatars', TRUE, 2097152, ARRAY['image/jpeg','image/png','image/webp'])
  ON CONFLICT (id) DO NOTHING;

  DROP POLICY IF EXISTS "evidence_student_insert" ON storage.objects;
  CREATE POLICY "evidence_student_insert" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'claim-evidence'
    AND public.current_app_role() = 'STUDENT'
    AND (storage.foldername(name))[1] = public.current_student_uuid()::text
  );

  DROP POLICY IF EXISTS "evidence_student_update" ON storage.objects;
  CREATE POLICY "evidence_student_update" ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'claim-evidence'
    AND public.current_app_role() = 'STUDENT'
    AND (storage.foldername(name))[1] = public.current_student_uuid()::text
  );

  DROP POLICY IF EXISTS "evidence_authorized_read" ON storage.objects;
  CREATE POLICY "evidence_authorized_read" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'claim-evidence'
    AND (
      public.is_super_admin()
      OR (storage.foldername(name))[1] = public.current_student_uuid()::text
      OR (
        public.current_app_role() = 'MENTOR'
        AND (storage.foldername(name))[1] IN (
          SELECT id::text FROM public.students WHERE mentor_id = public.current_mentor_uuid()
        )
      )
    )
  );

  DROP POLICY IF EXISTS "avatars_public_read" ON storage.objects;
  CREATE POLICY "avatars_public_read" ON storage.objects
  FOR SELECT USING (bucket_id = 'avatars');

  DROP POLICY IF EXISTS "avatars_authenticated_insert" ON storage.objects;
  CREATE POLICY "avatars_authenticated_insert" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'avatars'
    AND auth.uid() IS NOT NULL
    AND (
      public.is_super_admin()
      OR (storage.foldername(name))[1] = COALESCE(public.current_student_uuid()::text, public.current_mentor_uuid()::text)
    )
  );

  DROP POLICY IF EXISTS "avatars_authenticated_update" ON storage.objects;
  CREATE POLICY "avatars_authenticated_update" ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'avatars'
    AND auth.uid() IS NOT NULL
    AND (
      public.is_super_admin()
      OR (storage.foldername(name))[1] = COALESCE(public.current_student_uuid()::text, public.current_mentor_uuid()::text)
    )
  );
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Storage policy setup notice: %', SQLERRM;
END $$;
`;

fs.writeFileSync(path.join(MIGRATIONS_DIR, '202611050002_rls_and_atomic_rpcs.sql'), rlsSql, 'utf8');
console.log(`[5/6] Migration 002 created: supabase/migrations/202611050002_rls_and_atomic_rpcs.sql`);

// 8. Generate Idempotent SQL Seed Script (290 Students, 20 Mentors, 12 Classes, 9 Unions, 15 Coin Categories)
const sqlLines = [];
sqlLines.push('-- ============================================================================');
sqlLines.push('-- DHAC COIN PORTAL — DETERMINISTIC IDEMPOTENT DATA SEED (290 STUDENTS / 20 MENTORS)');
sqlLines.push('-- Institution: DARUL HUDA ISLAMIC UNIVERSITY — ASSAM CENTRE');
sqlLines.push(`-- Source Backup SHA-256: ${backupDigest}`);
sqlLines.push('-- SECURITY: Contains ZERO plaintext passwords.');
sqlLines.push('-- ============================================================================');
sqlLines.push('BEGIN;');
sqlLines.push('');
sqlLines.push('-- 1. Seed 12 Academic Classes');
for (const c of CLASSES_CONFIG) {
  sqlLines.push(
    `INSERT INTO public.classes (code, batch_name, category, display_order) VALUES (${sqlStr(c.code)}, ${sqlStr(c.batchName)}, ${sqlStr(c.category)}, ${sqlInt(c.order)}) ` +
    `ON CONFLICT (code) DO UPDATE SET batch_name = EXCLUDED.batch_name, category = EXCLUDED.category, display_order = EXCLUDED.display_order;`
  );
}
sqlLines.push('');
sqlLines.push('-- 2. Seed 9 Student Unions & Class Associations');
for (const u of cleanUnions) {
  sqlLines.push(
    `INSERT INTO public.unions (id, union_name, category, is_no_union_batch) VALUES (${sqlStr(u.id)}, ${sqlStr(u.unionName)}, ${sqlStr(u.category)}, ${sqlBool(u.isNoUnionBatch)}) ` +
    `ON CONFLICT (id) DO UPDATE SET union_name = EXCLUDED.union_name, category = EXCLUDED.category, is_no_union_batch = EXCLUDED.is_no_union_batch;`
  );
  for (const cls of u.classes) {
    sqlLines.push(
      `INSERT INTO public.union_classes (class_code, union_id) VALUES (${sqlStr(cls)}, ${sqlStr(u.id)}) ` +
      `ON CONFLICT (class_code) DO UPDATE SET union_id = EXCLUDED.union_id;`
    );
  }
}
sqlLines.push('');
sqlLines.push('-- 3. Seed 20 Faculty Mentors (No Plaintext Passwords)');
for (const m of cleanMentors) {
  sqlLines.push(
    `INSERT INTO public.mentors (staff_code, serial_no, name, username, auth_email) VALUES (${sqlStr(m.staffCode)}, ${sqlStr(m.serialNo)}, ${sqlStr(m.name)}, ${sqlStr(m.username)}, ${sqlStr(m.authEmail)}) ` +
    `ON CONFLICT (staff_code) DO UPDATE SET serial_no = EXCLUDED.serial_no, name = EXCLUDED.name, username = EXCLUDED.username, auth_email = EXCLUDED.auth_email;`
  );
}
sqlLines.push('');
sqlLines.push('-- 4. Seed 15 Coin Categories & Activity Rules');
for (const cat of COIN_CATEGORIES_SEED) {
  sqlLines.push(
    `INSERT INTO public.coin_categories (id, category_name, description, sort_order) VALUES (${sqlStr(cat.id)}, ${sqlStr(cat.categoryName)}, ${sqlStr(cat.description)}, ${sqlInt(cat.sortOrder)}) ` +
    `ON CONFLICT (id) DO UPDATE SET category_name = EXCLUDED.category_name, description = EXCLUDED.description, sort_order = EXCLUDED.sort_order;`
  );
  cat.activities.forEach((act, idx) => {
    sqlLines.push(
      `INSERT INTO public.coin_rules (id, category_id, activity_name, coin_value, is_custom, for_class_only, notes, sort_order) VALUES (` +
      `${sqlStr(act.id)}, ${sqlStr(cat.id)}, ${sqlStr(act.name)}, ${sqlInt(act.coins)}, ${sqlBool(act.isCustom)}, ${sqlBool(act.forClassOnly)}, ${sqlStr(act.notes)}, ${sqlInt(idx + 1)}) ` +
      `ON CONFLICT (id) DO UPDATE SET category_id = EXCLUDED.category_id, activity_name = EXCLUDED.activity_name, coin_value = EXCLUDED.coin_value, is_custom = EXCLUDED.is_custom, for_class_only = EXCLUDED.for_class_only, notes = EXCLUDED.notes, sort_order = EXCLUDED.sort_order;`
    );
  });
}
sqlLines.push('');
sqlLines.push('-- 5. Seed All 290 Preserved Students with Relational Mentor Foreign Keys');
for (const s of cleanStudents) {
  sqlLines.push(
    `INSERT INTO public.students (student_id, official_id, ad_no, ad_flag, name, class_code, mentor_id, auth_email, total_coins, coin_status, rank_status, tier, notes) VALUES (` +
    `${sqlStr(s.studentId)}, ${sqlStr(s.officialId)}, ${sqlStr(s.adNo)}, ${sqlStr(s.adFlag)}, ${sqlStr(s.name)}, ${sqlStr(s.classCode)}, ` +
    `(SELECT id FROM public.mentors WHERE staff_code = ${sqlStr(s.mentorStaffCode)}), ` +
    `${sqlStr(s.authEmail)}, ${sqlInt(s.totalCoins)}, ${sqlStr(s.coinStatus)}, ${sqlStr(s.rankStatus)}, ${sqlStr(s.tier)}, ${sqlStr(s.notes)}) ` +
    `ON CONFLICT (student_id) DO UPDATE SET official_id = EXCLUDED.official_id, ad_no = EXCLUDED.ad_no, ad_flag = EXCLUDED.ad_flag, name = EXCLUDED.name, class_code = EXCLUDED.class_code, mentor_id = EXCLUDED.mentor_id, auth_email = EXCLUDED.auth_email, notes = EXCLUDED.notes;`
  );
}
sqlLines.push('');
sqlLines.push('COMMIT;');

const seedSqlContent = sqlLines.join('\n') + '\n';
fs.writeFileSync(SEED_PATH, seedSqlContent, 'utf8');

// 9. Post-generation Verification Pass on Generated SQL & Manifest
const studentInsertsCount = (seedSqlContent.match(/INSERT INTO public\.students /g) || []).length;
const mentorInsertsCount = (seedSqlContent.match(/INSERT INTO public\.mentors /g) || []).length;
const classInsertsCount = (seedSqlContent.match(/INSERT INTO public\.classes /g) || []).length;
const unionInsertsCount = (seedSqlContent.match(/INSERT INTO public\.unions /g) || []).length;

const generatedBlob = [
  fs.readFileSync(path.join(MIGRATIONS_DIR, '202611050001_schema_and_indexes.sql'), 'utf8'),
  fs.readFileSync(path.join(MIGRATIONS_DIR, '202611050002_rls_and_atomic_rpcs.sql'), 'utf8'),
  seedSqlContent,
  JSON.stringify(manifest.data),
].join('\n');

const forbiddenTokens = ['@sidra.awarrd001', 'dhac@staff26', ...legacyPasswordsDetected.filter(p => p.length >= 6)];
for (const token of forbiddenTokens) {
  if (generatedBlob.includes(token)) {
    throw new Error(`SECURITY AUDIT FAILED: Detected plaintext password token "${token}" in migration output!`);
  }
}

if (studentInsertsCount !== 290 || mentorInsertsCount !== 20 || classInsertsCount !== 12 || unionInsertsCount !== 9) {
  throw new Error(
    `SQL seed verification failed: students=${studentInsertsCount}, mentors=${mentorInsertsCount}, classes=${classInsertsCount}, unions=${unionInsertsCount}`
  );
}

console.log(`[6/6] Seed SQL created & verified: supabase/seed.sql`);
console.log(`      - Verified SQL Statements: ${studentInsertsCount} students, ${mentorInsertsCount} mentors, ${classInsertsCount} classes, ${unionInsertsCount} unions`);
console.log(`      - Security Scan: 0 plaintext password tokens present across all generated files.`);
console.log('\n=== PHASE 1 COMPLETE — ALL CHECKS PASSED ===');
