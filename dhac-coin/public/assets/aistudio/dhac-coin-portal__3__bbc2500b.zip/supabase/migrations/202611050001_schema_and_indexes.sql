-- ============================================================================
-- DHAC COIN PORTAL — SUPABASE POSTGRESQL SCHEMA (MIGRATION 001)
-- Institution: DARUL HUDA ISLAMIC UNIVERSITY — ASSAM CENTRE
-- Safe, idempotent migration preserving all 290 students & 20 faculty mentors
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1. Academic Classes (12 Batches across Degree, Higher Secondary, Secondary)
CREATE TABLE IF NOT EXISTS public.classes (
  code TEXT PRIMARY KEY,
  batch_name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('Degree', 'Higher Secondary', 'Secondary')),
  class_bonus_coins INTEGER NOT NULL DEFAULT 0 CHECK (class_bonus_coins >= 0),
  display_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Student Unions (9 Cohorts)
CREATE TABLE IF NOT EXISTS public.unions (
  id TEXT PRIMARY KEY,
  union_name TEXT NOT NULL UNIQUE,
  category TEXT NOT NULL CHECK (category IN ('Degree', 'Higher Secondary', 'Secondary')),
  is_no_union_batch BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Union <-> Class Association
CREATE TABLE IF NOT EXISTS public.union_classes (
  class_code TEXT PRIMARY KEY REFERENCES public.classes(code) ON UPDATE CASCADE ON DELETE CASCADE,
  union_id TEXT NOT NULL REFERENCES public.unions(id) ON UPDATE CASCADE ON DELETE CASCADE
);

-- 4. Faculty Mentors (20 Verified Hudawi Mentors — ZERO plaintext passwords)
CREATE TABLE IF NOT EXISTS public.mentors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_code TEXT NOT NULL UNIQUE,
  serial_no TEXT NOT NULL,
  name TEXT NOT NULL UNIQUE,
  username TEXT NOT NULL UNIQUE,
  auth_email TEXT UNIQUE,
  department TEXT NOT NULL DEFAULT 'Faculty Mentor',
  avatar_url TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. Students Registry (290 Preserved Student Records)
CREATE TABLE IF NOT EXISTS public.students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id TEXT NOT NULL UNIQUE,
  official_id TEXT NOT NULL UNIQUE,
  ad_no TEXT NOT NULL UNIQUE,
  ad_flag TEXT NOT NULL DEFAULT 'VALID' CHECK (ad_flag IN ('VALID', 'ORIGINAL_ASTERISK', 'MISSING_AD')),
  name TEXT NOT NULL,
  class_code TEXT NOT NULL REFERENCES public.classes(code) ON UPDATE CASCADE ON DELETE RESTRICT,
  mentor_id UUID NOT NULL REFERENCES public.mentors(id) ON UPDATE CASCADE ON DELETE RESTRICT,
  auth_email TEXT UNIQUE,
  total_coins INTEGER NOT NULL DEFAULT 0 CHECK (total_coins >= 0),
  coin_status TEXT NOT NULL DEFAULT 'ZERO' CHECK (coin_status IN ('CONFIRMED', 'MISSING_OR_ZERO', 'ASSUMED_ZERO', 'ZERO')),
  rank_status TEXT NOT NULL DEFAULT 'OFFICIAL' CHECK (rank_status IN ('OFFICIAL', 'PROVISIONAL')),
  tier TEXT NOT NULL DEFAULT 'Zero' CHECK (tier IN ('Diamond', 'Gold', 'Silver', 'Bronze', 'Starter', 'Zero')),
  notes TEXT NOT NULL DEFAULT '',
  photo_url TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_students_class_code ON public.students(class_code);
CREATE INDEX IF NOT EXISTS idx_students_mentor_id ON public.students(mentor_id);
CREATE INDEX IF NOT EXISTS idx_students_total_coins ON public.students(total_coins DESC);
CREATE INDEX IF NOT EXISTS idx_students_ad_no ON public.students(ad_no);

-- 6. Authenticated User Profiles & Role Bindings (RBAC Source of Truth)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT NOT NULL UNIQUE,
  auth_email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('SUPER_ADMIN', 'MENTOR', 'STUDENT')),
  display_name TEXT NOT NULL,
  student_uuid UUID UNIQUE REFERENCES public.students(id) ON DELETE SET NULL,
  mentor_uuid UUID REFERENCES public.mentors(id) ON DELETE SET NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. Coin Categories & Configurable Activity Rules
CREATE TABLE IF NOT EXISTS public.coin_categories (
  id TEXT PRIMARY KEY,
  category_name TEXT NOT NULL UNIQUE,
  description TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.coin_rules (
  id TEXT PRIMARY KEY,
  category_id TEXT NOT NULL REFERENCES public.coin_categories(id) ON UPDATE CASCADE ON DELETE CASCADE,
  activity_name TEXT NOT NULL,
  coin_value INTEGER CHECK (coin_value IS NULL OR coin_value > 0),
  is_custom BOOLEAN NOT NULL DEFAULT FALSE,
  for_class_only BOOLEAN NOT NULL DEFAULT FALSE,
  notes TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_coin_rules_category ON public.coin_rules(category_id);

-- 8. Student Coin Claims (Pending -> Approved / Rejected)
CREATE TABLE IF NOT EXISTS public.coin_claims (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_code TEXT NOT NULL UNIQUE DEFAULT ('CLM-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10))),
  student_uuid UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  mentor_uuid UUID NOT NULL REFERENCES public.mentors(id) ON DELETE RESTRICT,
  category_id TEXT REFERENCES public.coin_categories(id) ON DELETE SET NULL,
  rule_id TEXT REFERENCES public.coin_rules(id) ON DELETE SET NULL,
  category_name TEXT NOT NULL,
  activity_name TEXT NOT NULL,
  coins INTEGER NOT NULL CHECK (coins > 0 AND coins <= 500),
  proof_notes TEXT NOT NULL,
  evidence_path TEXT,
  evidence_mime TEXT,
  idempotency_key TEXT UNIQUE,
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
  submitted_by_uid UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reviewed_by_uid UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewed_by_name TEXT,
  reviewed_at TIMESTAMPTZ,
  rejection_reason TEXT
);

CREATE INDEX IF NOT EXISTS idx_coin_claims_student ON public.coin_claims(student_uuid);
CREATE INDEX IF NOT EXISTS idx_coin_claims_mentor_status ON public.coin_claims(mentor_uuid, status);
CREATE INDEX IF NOT EXISTS idx_coin_claims_submitted_at ON public.coin_claims(submitted_at DESC);

-- 9. Immutable Append-Only Coin Ledger (Single Source of Truth for Coin Balances)
CREATE TABLE IF NOT EXISTS public.coin_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tx_code TEXT NOT NULL UNIQUE DEFAULT ('TX-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10))),
  target_type TEXT NOT NULL CHECK (target_type IN ('STUDENT', 'CLASS')),
  student_uuid UUID REFERENCES public.students(id) ON DELETE RESTRICT,
  class_code TEXT NOT NULL REFERENCES public.classes(code) ON UPDATE CASCADE ON DELETE RESTRICT,
  mentor_uuid UUID REFERENCES public.mentors(id) ON DELETE SET NULL,
  claim_uuid UUID UNIQUE REFERENCES public.coin_claims(id) ON DELETE RESTRICT,
  category_id TEXT REFERENCES public.coin_categories(id) ON DELETE SET NULL,
  rule_id TEXT REFERENCES public.coin_rules(id) ON DELETE SET NULL,
  category_name TEXT NOT NULL,
  activity_name TEXT NOT NULL,
  coins_delta INTEGER NOT NULL CHECK (coins_delta <> 0),
  reversal_of_tx_uuid UUID UNIQUE REFERENCES public.coin_transactions(id) ON DELETE RESTRICT,
  awarded_by_uid UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  awarded_by_name TEXT NOT NULL,
  notes TEXT,
  idempotency_key TEXT UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_target_consistency CHECK (
    (target_type = 'STUDENT' AND student_uuid IS NOT NULL) OR
    (target_type = 'CLASS' AND student_uuid IS NULL)
  )
);

CREATE INDEX IF NOT EXISTS idx_coin_tx_student ON public.coin_transactions(student_uuid);
CREATE INDEX IF NOT EXISTS idx_coin_tx_mentor ON public.coin_transactions(mentor_uuid);
CREATE INDEX IF NOT EXISTS idx_coin_tx_created_at ON public.coin_transactions(created_at DESC);

-- 10. Mentor Group Competitions / Battle Events
CREATE TABLE IF NOT EXISTS public.mentor_group_battles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('UPCOMING', 'ACTIVE', 'COMPLETED')),
  scoring_mode TEXT NOT NULL DEFAULT 'TOTAL_COINS' CHECK (scoring_mode IN ('TOTAL_COINS', 'AVERAGE_PER_MENTEE')),
  prize_label TEXT,
  created_by_uid UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. Immutable Institutional Audit Logs
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_uid UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  actor_username TEXT,
  actor_role TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  before_data JSONB,
  after_data JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON public.audit_logs(created_at DESC);

-- 12. System Settings Singleton
CREATE TABLE IF NOT EXISTS public.system_settings (
  id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  institution_name TEXT NOT NULL DEFAULT 'DARUL HUDA ISLAMIC UNIVERSITY — ASSAM CENTRE',
  short_brand TEXT NOT NULL DEFAULT 'DARUL HUDA ASSAM CENTRE',
  academic_year TEXT NOT NULL DEFAULT '2026-2027',
  allow_public_leaderboard BOOLEAN NOT NULL DEFAULT TRUE,
  allow_student_claims BOOLEAN NOT NULL DEFAULT TRUE,
  require_evidence_photo BOOLEAN NOT NULL DEFAULT FALSE,
  max_claim_coins INTEGER NOT NULL DEFAULT 50 CHECK (max_claim_coins > 0 AND max_claim_coins <= 500),
  tier_thresholds JSONB NOT NULL DEFAULT '{"diamond":60,"gold":30,"silver":15,"bronze":1}'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO public.system_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

-- ============================================================================
-- TRIGGER 1: Enforce Ledger & Audit Log Immutability (Append-Only)
-- ============================================================================
CREATE OR REPLACE FUNCTION public.fn_prevent_ledger_mutation()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE EXCEPTION 'Ledger and audit tables are strictly append-only. Use a compensating reversal transaction instead.';
END;
$$;

DROP TRIGGER IF EXISTS trg_immutable_coin_transactions ON public.coin_transactions;
CREATE TRIGGER trg_immutable_coin_transactions
BEFORE UPDATE OR DELETE ON public.coin_transactions
FOR EACH ROW
EXECUTE FUNCTION public.fn_prevent_ledger_mutation();

DROP TRIGGER IF EXISTS trg_immutable_audit_logs ON public.audit_logs;
CREATE TRIGGER trg_immutable_audit_logs
BEFORE UPDATE OR DELETE ON public.audit_logs
FOR EACH ROW
EXECUTE FUNCTION public.fn_prevent_ledger_mutation();

-- ============================================================================
-- DYNAMIC 1224 COMPETITION RANKING & AGGREGATION VIEWS
-- ============================================================================
CREATE OR REPLACE VIEW public.v_student_leaderboard AS
SELECT
  s.id,
  s.student_id,
  s.official_id,
  s.ad_no,
  s.ad_flag,
  s.name,
  s.class_code AS class_name,
  c.batch_name,
  c.category AS department_category,
  s.mentor_id,
  m.staff_code AS mentor_staff_code,
  m.name AS mentor_name,
  s.total_coins,
  s.coin_status,
  s.rank_status,
  s.tier,
  s.notes,
  s.photo_url,
  s.is_active,
  RANK() OVER (ORDER BY s.total_coins DESC) AS campus_rank_num,
  COUNT(*) OVER () AS campus_total_students,
  RANK() OVER (PARTITION BY s.class_code ORDER BY s.total_coins DESC) AS class_rank_num,
  COUNT(*) OVER (PARTITION BY s.class_code) AS class_size,
  RANK() OVER (PARTITION BY s.mentor_id ORDER BY s.total_coins DESC) AS mentor_rank_num,
  COUNT(*) OVER (PARTITION BY s.mentor_id) AS mentor_group_size,
  s.updated_at
FROM public.students s
JOIN public.classes c ON c.code = s.class_code
JOIN public.mentors m ON m.id = s.mentor_id
WHERE s.is_active = TRUE;

CREATE OR REPLACE VIEW public.v_mentor_standings AS
SELECT
  m.id AS mentor_id,
  m.staff_code,
  m.serial_no,
  m.name AS mentor_name,
  m.username,
  m.avatar_url,
  COUNT(s.id) AS student_count,
  COALESCE(SUM(s.total_coins), 0) AS total_coins,
  ROUND(COALESCE(AVG(s.total_coins), 0)::numeric, 1) AS average_coins,
  COUNT(*) FILTER (WHERE s.total_coins > 0) AS active_students,
  COUNT(*) FILTER (WHERE s.total_coins = 0) AS zero_coin_students,
  RANK() OVER (ORDER BY COALESCE(SUM(s.total_coins), 0) DESC, COALESCE(AVG(s.total_coins), 0) DESC) AS rank
FROM public.mentors m
LEFT JOIN public.students s ON s.mentor_id = m.id AND s.is_active = TRUE
WHERE m.is_active = TRUE
GROUP BY m.id, m.staff_code, m.serial_no, m.name, m.username, m.avatar_url;

CREATE OR REPLACE VIEW public.v_class_standings AS
SELECT
  c.code AS class_name,
  c.batch_name,
  c.category,
  c.display_order,
  COUNT(s.id) AS student_count,
  COALESCE(SUM(s.total_coins), 0) AS student_coins,
  c.class_bonus_coins AS class_award_coins,
  COALESCE(SUM(s.total_coins), 0) + c.class_bonus_coins AS total_coins,
  ROUND(((COALESCE(SUM(s.total_coins), 0) + c.class_bonus_coins)::numeric / GREATEST(COUNT(s.id), 1)), 1) AS average_coins,
  COUNT(*) FILTER (WHERE s.total_coins > 0) AS active_students,
  COUNT(*) FILTER (WHERE s.total_coins = 0) AS zero_coin_students,
  RANK() OVER (ORDER BY (COALESCE(SUM(s.total_coins), 0) + c.class_bonus_coins) DESC) AS rank
FROM public.classes c
LEFT JOIN public.students s ON s.class_code = c.code AND s.is_active = TRUE
GROUP BY c.code, c.batch_name, c.category, c.class_bonus_coins, c.display_order;

CREATE OR REPLACE VIEW public.v_union_standings AS
SELECT
  u.id,
  u.union_name,
  u.category,
  u.is_no_union_batch,
  ARRAY_AGG(DISTINCT uc.class_code ORDER BY uc.class_code) AS classes,
  COALESCE(SUM(cs.student_count), 0) AS student_count,
  COALESCE(SUM(cs.student_coins), 0) AS student_coins,
  COALESCE(SUM(cs.class_award_coins), 0) AS class_award_coins,
  COALESCE(SUM(cs.total_coins), 0) AS total_coins,
  ROUND((COALESCE(SUM(cs.total_coins), 0)::numeric / GREATEST(COALESCE(SUM(cs.student_count), 0), 1)), 1) AS average_coins,
  COALESCE(SUM(cs.active_students), 0) AS active_students,
  COALESCE(SUM(cs.zero_coin_students), 0) AS zero_coin_students,
  RANK() OVER (ORDER BY COALESCE(SUM(cs.total_coins), 0) DESC, (COALESCE(SUM(cs.total_coins), 0)::numeric / GREATEST(COALESCE(SUM(cs.student_count), 0), 1)) DESC) AS rank
FROM public.unions u
JOIN public.union_classes uc ON uc.union_id = u.id
JOIN public.v_class_standings cs ON cs.class_name = uc.class_code
GROUP BY u.id, u.union_name, u.category, u.is_no_union_batch;
