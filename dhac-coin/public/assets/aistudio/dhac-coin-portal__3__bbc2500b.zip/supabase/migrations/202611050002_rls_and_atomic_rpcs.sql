-- ============================================================================
-- DHAC COIN PORTAL — ROW LEVEL SECURITY & ATOMIC RPC ENGINE (MIGRATION 002)
-- Institution: DARUL HUDA ISLAMIC UNIVERSITY — ASSAM CENTRE
-- ============================================================================

-- 1. Non-Recursive Security Helper Functions (SECURITY DEFINER breaks RLS recursion)
CREATE OR REPLACE FUNCTION public.current_app_role()
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid() AND is_active = TRUE LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.current_mentor_uuid()
RETURNS UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT mentor_uuid FROM public.profiles WHERE id = auth.uid() AND is_active = TRUE LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.current_student_uuid()
RETURNS UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT student_uuid FROM public.profiles WHERE id = auth.uid() AND is_active = TRUE LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.is_super_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(public.current_app_role() = 'SUPER_ADMIN', FALSE);
$$;

-- 2. Enable Row Level Security on All Tables
ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.unions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.union_classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mentors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coin_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coin_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coin_claims ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coin_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mentor_group_battles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;

-- 3. Reference Catalog Policies (Read-only for authenticated & public portal view; write restricted to SUPER_ADMIN)
DROP POLICY IF EXISTS "classes_select_all" ON public.classes;
CREATE POLICY "classes_select_all" ON public.classes FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "classes_admin_all" ON public.classes;
CREATE POLICY "classes_admin_all" ON public.classes FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "unions_select_all" ON public.unions;
CREATE POLICY "unions_select_all" ON public.unions FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "unions_admin_all" ON public.unions;
CREATE POLICY "unions_admin_all" ON public.unions FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "union_classes_select_all" ON public.union_classes;
CREATE POLICY "union_classes_select_all" ON public.union_classes FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "union_classes_admin_all" ON public.union_classes;
CREATE POLICY "union_classes_admin_all" ON public.union_classes FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "mentors_select_all" ON public.mentors;
CREATE POLICY "mentors_select_all" ON public.mentors FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "mentors_admin_all" ON public.mentors;
CREATE POLICY "mentors_admin_all" ON public.mentors FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "categories_select_all" ON public.coin_categories;
CREATE POLICY "categories_select_all" ON public.coin_categories FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "categories_admin_all" ON public.coin_categories;
CREATE POLICY "categories_admin_all" ON public.coin_categories FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "rules_select_all" ON public.coin_rules;
CREATE POLICY "rules_select_all" ON public.coin_rules FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "rules_admin_all" ON public.coin_rules;
CREATE POLICY "rules_admin_all" ON public.coin_rules FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "battles_select_all" ON public.mentor_group_battles;
CREATE POLICY "battles_select_all" ON public.mentor_group_battles FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "battles_admin_all" ON public.mentor_group_battles;
CREATE POLICY "battles_admin_all" ON public.mentor_group_battles FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "settings_select_all" ON public.system_settings;
CREATE POLICY "settings_select_all" ON public.system_settings FOR SELECT USING (TRUE);
DROP POLICY IF EXISTS "settings_admin_all" ON public.system_settings;
CREATE POLICY "settings_admin_all" ON public.system_settings FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

-- 4. Profiles Policies (Strict RBAC — Users cannot escalate roles or impersonate student_uuid)
DROP POLICY IF EXISTS "profiles_select_policy" ON public.profiles;
CREATE POLICY "profiles_select_policy" ON public.profiles
FOR SELECT USING (
  id = auth.uid()
  OR public.is_super_admin()
  OR (
    public.current_app_role() = 'MENTOR'
    AND student_uuid IN (SELECT s.id FROM public.students s WHERE s.mentor_id = public.current_mentor_uuid())
  )
);

DROP POLICY IF EXISTS "profiles_update_self_display" ON public.profiles;
CREATE POLICY "profiles_update_self_display" ON public.profiles
FOR UPDATE USING (id = auth.uid())
WITH CHECK (
  id = auth.uid()
  AND role = public.current_app_role()
  AND student_uuid IS NOT DISTINCT FROM public.current_student_uuid()
  AND mentor_uuid IS NOT DISTINCT FROM public.current_mentor_uuid()
);

DROP POLICY IF EXISTS "profiles_admin_manage" ON public.profiles;
CREATE POLICY "profiles_admin_manage" ON public.profiles
FOR ALL USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());

-- 5. Students Table Policies + Column-Level Coin Tamper Protection
DROP POLICY IF EXISTS "students_select_policy" ON public.students;
CREATE POLICY "students_select_policy" ON public.students
FOR SELECT USING (
  public.is_super_admin()
  OR id = public.current_student_uuid()
  OR (public.current_app_role() = 'MENTOR' AND mentor_id = public.current_mentor_uuid())
  OR COALESCE((SELECT allow_public_leaderboard FROM public.system_settings WHERE id = 1), TRUE)
);

DROP POLICY IF EXISTS "students_admin_insert" ON public.students;
CREATE POLICY "students_admin_insert" ON public.students
FOR INSERT WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "students_admin_delete" ON public.students;
CREATE POLICY "students_admin_delete" ON public.students
FOR DELETE USING (public.is_super_admin());

DROP POLICY IF EXISTS "students_update_policy" ON public.students;
CREATE POLICY "students_update_policy" ON public.students
FOR UPDATE USING (
  public.is_super_admin()
  OR id = public.current_student_uuid()
  OR (public.current_app_role() = 'MENTOR' AND mentor_id = public.current_mentor_uuid())
)
WITH CHECK (
  public.is_super_admin()
  OR id = public.current_student_uuid()
  OR (public.current_app_role() = 'MENTOR' AND mentor_id = public.current_mentor_uuid())
);

-- Automatic Atomic Balance & Tier Sync Trigger (Sets transaction-local app.in_ledger_sync flag)
CREATE OR REPLACE FUNCTION public.fn_sync_balances_on_transaction()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_new_total INTEGER;
  v_new_tier TEXT;
  v_new_status TEXT;
BEGIN
  PERFORM set_config('app.in_ledger_sync', 'true', TRUE);

  IF NEW.target_type = 'STUDENT' AND NEW.student_uuid IS NOT NULL THEN
    UPDATE public.students
    SET
      total_coins = GREATEST(0, total_coins + NEW.coins_delta),
      updated_at = NOW()
    WHERE id = NEW.student_uuid
    RETURNING total_coins INTO v_new_total;

    IF v_new_total >= 60 THEN v_new_tier := 'Diamond';
    ELSIF v_new_total >= 30 THEN v_new_tier := 'Gold';
    ELSIF v_new_total >= 15 THEN v_new_tier := 'Silver';
    ELSIF v_new_total > 0 THEN v_new_tier := 'Bronze';
    ELSE v_new_tier := 'Zero';
    END IF;

    v_new_status := CASE WHEN v_new_total > 0 THEN 'CONFIRMED' ELSE 'ZERO' END;

    UPDATE public.students
    SET
      tier = v_new_tier,
      coin_status = v_new_status,
      rank_status = 'OFFICIAL'
    WHERE id = NEW.student_uuid;
  ELSIF NEW.target_type = 'CLASS' THEN
    UPDATE public.classes
    SET
      class_bonus_coins = GREATEST(0, class_bonus_coins + NEW.coins_delta),
      updated_at = NOW()
    WHERE code = NEW.class_code;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_sync_balances_on_transaction ON public.coin_transactions;
CREATE TRIGGER trg_sync_balances_on_transaction
AFTER INSERT ON public.coin_transactions
FOR EACH ROW
EXECUTE FUNCTION public.fn_sync_balances_on_transaction();

-- Column-Level Tamper Guard on Students (Only photo_url editable by non-admin clients)
CREATE OR REPLACE FUNCTION public.fn_guard_student_protected_columns()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND NOT public.is_super_admin() THEN
    IF NEW.total_coins IS DISTINCT FROM OLD.total_coins
       OR NEW.tier IS DISTINCT FROM OLD.tier
       OR NEW.coin_status IS DISTINCT FROM OLD.coin_status
       OR NEW.student_id IS DISTINCT FROM OLD.student_id
       OR NEW.official_id IS DISTINCT FROM OLD.official_id
       OR NEW.ad_no IS DISTINCT FROM OLD.ad_no
       OR NEW.class_code IS DISTINCT FROM OLD.class_code
       OR NEW.mentor_id IS DISTINCT FROM OLD.mentor_id
       OR NEW.name IS DISTINCT FROM OLD.name
       OR NEW.is_active IS DISTINCT FROM OLD.is_active THEN
      IF current_setting('app.in_ledger_sync', TRUE) IS DISTINCT FROM 'true' THEN
        RAISE EXCEPTION 'Unauthorized column mutation on students table. Coin balances can only change via approved ledger RPCs.';
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_guard_student_protected_columns ON public.students;
CREATE TRIGGER trg_guard_student_protected_columns
BEFORE UPDATE ON public.students
FOR EACH ROW
EXECUTE FUNCTION public.fn_guard_student_protected_columns();

-- 6. Coin Claims Policies (Strict Mentee Isolation)
DROP POLICY IF EXISTS "claims_select_policy" ON public.coin_claims;
CREATE POLICY "claims_select_policy" ON public.coin_claims
FOR SELECT USING (
  public.is_super_admin()
  OR student_uuid = public.current_student_uuid()
  OR (public.current_app_role() = 'MENTOR' AND mentor_uuid = public.current_mentor_uuid())
);

DROP POLICY IF EXISTS "claims_student_insert" ON public.coin_claims;
CREATE POLICY "claims_student_insert" ON public.coin_claims
FOR INSERT WITH CHECK (
  public.current_app_role() = 'STUDENT'
  AND student_uuid = public.current_student_uuid()
  AND status = 'PENDING'
  AND mentor_uuid = (SELECT mentor_id FROM public.students WHERE id = public.current_student_uuid())
);

-- 7. Coin Transactions Policies (Read scoped by role; direct client writes revoked)
DROP POLICY IF EXISTS "transactions_select_policy" ON public.coin_transactions;
CREATE POLICY "transactions_select_policy" ON public.coin_transactions
FOR SELECT USING (
  public.is_super_admin()
  OR student_uuid = public.current_student_uuid()
  OR (
    public.current_app_role() = 'MENTOR'
    AND (
      mentor_uuid = public.current_mentor_uuid()
      OR student_uuid IN (SELECT id FROM public.students WHERE mentor_id = public.current_mentor_uuid())
    )
  )
);

-- 8. Audit Logs Policy (Strict SUPER_ADMIN Read Only)
DROP POLICY IF EXISTS "audit_logs_admin_select" ON public.audit_logs;
CREATE POLICY "audit_logs_admin_select" ON public.audit_logs
FOR SELECT USING (public.is_super_admin());

-- ============================================================================
-- SECURE AUTH USER -> PROFILE BINDING TRIGGER (Zero Privilege Escalation)
-- Automatically binds new Supabase Auth users to their verified institutional row
-- ============================================================================
CREATE OR REPLACE FUNCTION public.fn_auto_link_profile_on_signup()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email TEXT;
  v_mentor public.mentors%ROWTYPE;
  v_student public.students%ROWTYPE;
BEGIN
  v_email := lower(trim(COALESCE(NEW.email, '')));
  IF v_email = '' THEN
    RETURN NEW;
  END IF;

  -- 1. Super Admin canonical email binding
  IF v_email = 'sidra2026@admin.dhac.edu.in' THEN
    INSERT INTO public.profiles (id, username, auth_email, role, display_name)
    VALUES (NEW.id, 'sidra2026', v_email, 'SUPER_ADMIN', 'Super Admin (Sidra)')
    ON CONFLICT (id) DO NOTHING;
    RETURN NEW;
  END IF;

  -- 2. Faculty Mentor email binding
  SELECT * INTO v_mentor FROM public.mentors WHERE lower(auth_email) = v_email AND is_active = TRUE LIMIT 1;
  IF FOUND THEN
    INSERT INTO public.profiles (id, username, auth_email, role, display_name, mentor_uuid)
    VALUES (NEW.id, v_mentor.username, v_email, 'MENTOR', v_mentor.name || ' (' || v_mentor.staff_code || ')', v_mentor.id)
    ON CONFLICT (id) DO NOTHING;
    RETURN NEW;
  END IF;

  -- 3. Student email binding
  SELECT * INTO v_student FROM public.students WHERE lower(auth_email) = v_email AND is_active = TRUE LIMIT 1;
  IF FOUND THEN
    INSERT INTO public.profiles (id, username, auth_email, role, display_name, student_uuid)
    VALUES (NEW.id, 'student_' || v_student.ad_no, v_email, 'STUDENT', v_student.name || ' (AD #' || v_student.ad_no || ')', v_student.id)
    ON CONFLICT (id) DO NOTHING;
    RETURN NEW;
  END IF;

  -- 4. Unmatched email defaults strictly to unlinked STUDENT role (never elevates privileges)
  INSERT INTO public.profiles (id, username, auth_email, role, display_name)
  VALUES (NEW.id, split_part(v_email, '@', 1) || '_' || substr(NEW.id::text, 1, 6), v_email, 'STUDENT', COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(v_email, '@', 1)))
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;

DO $$
BEGIN
  DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
  CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.fn_auto_link_profile_on_signup();
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Auth trigger setup notice: %', SQLERRM;
END $$;

-- ============================================================================
-- SECURE SERVER-ENFORCED ATOMIC RPC FUNCTIONS
-- ============================================================================

-- RPC 1: Resolve Username / AD Number / Staff Code -> Supabase Auth Email
CREATE OR REPLACE FUNCTION public.resolve_login_email(p_identifier TEXT)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_clean TEXT;
  v_email TEXT;
  v_ad TEXT;
BEGIN
  v_clean := trim(COALESCE(p_identifier, ''));
  IF v_clean = '' THEN
    RETURN NULL;
  END IF;

  SELECT auth_email INTO v_email
  FROM public.profiles
  WHERE lower(auth_email) = lower(v_clean) AND is_active = TRUE
  LIMIT 1;
  IF v_email IS NOT NULL THEN RETURN v_email; END IF;

  SELECT auth_email INTO v_email
  FROM public.profiles
  WHERE lower(username) = lower(v_clean) AND is_active = TRUE
  LIMIT 1;
  IF v_email IS NOT NULL THEN RETURN v_email; END IF;

  SELECT auth_email INTO v_email
  FROM public.mentors
  WHERE (lower(username) = lower(v_clean) OR lower(staff_code) = lower(v_clean)) AND is_active = TRUE
  LIMIT 1;
  IF v_email IS NOT NULL THEN RETURN v_email; END IF;

  v_ad := regexp_replace(v_clean, '^(student_|STU-)', '', 'i');
  v_ad := replace(v_ad, '*', '');
  SELECT auth_email INTO v_email
  FROM public.students
  WHERE (lower(ad_no) = lower(v_ad) OR lower(student_id) = lower(v_clean)) AND is_active = TRUE
  LIMIT 1;
  IF v_email IS NOT NULL THEN RETURN v_email; END IF;

  IF lower(v_clean) = 'sidra2026' THEN
    RETURN 'sidra2026@admin.dhac.edu.in';
  END IF;

  RETURN NULL;
END;
$$;

-- RPC 2: Student Submits Coin Claim with Server Rule Validation & Duplicate Guard
CREATE OR REPLACE FUNCTION public.submit_coin_claim(
  p_rule_id TEXT,
  p_proof_notes TEXT,
  p_evidence_path TEXT DEFAULT NULL,
  p_custom_coins INTEGER DEFAULT NULL,
  p_idempotency_key TEXT DEFAULT NULL
)
RETURNS public.coin_claims
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_student_id UUID;
  v_student public.students%ROWTYPE;
  v_rule public.coin_rules%ROWTYPE;
  v_cat public.coin_categories%ROWTYPE;
  v_coins INTEGER;
  v_max_coins INTEGER;
  v_claims_enabled BOOLEAN;
  v_existing public.coin_claims%ROWTYPE;
  v_inserted public.coin_claims%ROWTYPE;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Authentication required.';
  END IF;

  IF public.current_app_role() <> 'STUDENT' THEN
    RAISE EXCEPTION 'Only authenticated students can submit activity claims.';
  END IF;

  SELECT allow_student_claims, max_claim_coins INTO v_claims_enabled, v_max_coins
  FROM public.system_settings WHERE id = 1;
  IF NOT COALESCE(v_claims_enabled, TRUE) THEN
    RAISE EXCEPTION 'Student claim submissions are currently paused by administration.';
  END IF;

  IF p_idempotency_key IS NOT NULL THEN
    SELECT * INTO v_existing FROM public.coin_claims WHERE idempotency_key = p_idempotency_key;
    IF FOUND THEN
      RETURN v_existing;
    END IF;
  END IF;

  v_student_id := public.current_student_uuid();
  SELECT * INTO v_student FROM public.students WHERE id = v_student_id AND is_active = TRUE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Student profile not linked to active student record.';
  END IF;

  SELECT * INTO v_rule FROM public.coin_rules WHERE id = p_rule_id AND is_active = TRUE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Invalid or inactive coin activity rule.';
  END IF;
  SELECT * INTO v_cat FROM public.coin_categories WHERE id = v_rule.category_id;

  IF v_rule.is_custom THEN
    v_coins := COALESCE(p_custom_coins, 0);
  ELSE
    v_coins := v_rule.coin_value;
  END IF;

  IF v_coins IS NULL OR v_coins <= 0 OR v_coins > COALESCE(v_max_coins, 50) THEN
    RAISE EXCEPTION 'Claimed coin value (%) is outside permitted bounds (1..%).', v_coins, COALESCE(v_max_coins, 50);
  END IF;

  IF length(trim(COALESCE(p_proof_notes, ''))) < 4 THEN
    RAISE EXCEPTION 'Please provide meaningful achievement details / proof notes.';
  END IF;

  INSERT INTO public.coin_claims (
    student_uuid,
    mentor_uuid,
    category_id,
    rule_id,
    category_name,
    activity_name,
    coins,
    proof_notes,
    evidence_path,
    idempotency_key,
    status,
    submitted_by_uid
  ) VALUES (
    v_student.id,
    v_student.mentor_id,
    v_cat.id,
    v_rule.id,
    v_cat.category_name,
    v_rule.activity_name,
    v_coins,
    trim(p_proof_notes),
    p_evidence_path,
    p_idempotency_key,
    'PENDING',
    auth.uid()
  )
  RETURNING * INTO v_inserted;

  INSERT INTO public.audit_logs (
    actor_uid, actor_username, actor_role, action, entity_type, entity_id, after_data
  ) VALUES (
    auth.uid(),
    (SELECT username FROM public.profiles WHERE id = auth.uid()),
    'STUDENT',
    'CLAIM_SUBMITTED',
    'coin_claims',
    v_inserted.id::text,
    to_jsonb(v_inserted)
  );

  RETURN v_inserted;
END;
$$;

-- RPC 3: Atomic Mentor / Super Admin Claim Approval (Row-Locked + Single Credit Guarantee)
CREATE OR REPLACE FUNCTION public.approve_coin_claim(p_claim_id UUID)
RETURNS public.coin_transactions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role TEXT;
  v_mentor_id UUID;
  v_reviewer_name TEXT;
  v_reviewer_user TEXT;
  v_claim public.coin_claims%ROWTYPE;
  v_student public.students%ROWTYPE;
  v_tx public.coin_transactions%ROWTYPE;
BEGIN
  v_role := public.current_app_role();
  IF v_role NOT IN ('SUPER_ADMIN', 'MENTOR') THEN
    RAISE EXCEPTION 'Only authorized Mentors or Super Admin can approve coin claims.';
  END IF;

  SELECT display_name, username, mentor_uuid
  INTO v_reviewer_name, v_reviewer_user, v_mentor_id
  FROM public.profiles WHERE id = auth.uid();

  SELECT * INTO v_claim FROM public.coin_claims WHERE id = p_claim_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Claim record not found.';
  END IF;

  IF v_claim.status <> 'PENDING' THEN
    RAISE EXCEPTION 'Claim has already been processed (status: %).', v_claim.status;
  END IF;

  IF v_role = 'MENTOR' AND v_claim.mentor_uuid <> v_mentor_id THEN
    RAISE EXCEPTION 'Access denied: Mentors can only approve claims for their own assigned mentees.';
  END IF;

  SELECT * INTO v_student FROM public.students WHERE id = v_claim.student_uuid FOR UPDATE;

  UPDATE public.coin_claims
  SET
    status = 'APPROVED',
    reviewed_by_uid = auth.uid(),
    reviewed_by_name = v_reviewer_name,
    reviewed_at = NOW()
  WHERE id = p_claim_id;

  INSERT INTO public.coin_transactions (
    target_type,
    student_uuid,
    class_code,
    mentor_uuid,
    claim_uuid,
    category_id,
    rule_id,
    category_name,
    activity_name,
    coins_delta,
    awarded_by_uid,
    awarded_by_name,
    notes
  ) VALUES (
    'STUDENT',
    v_student.id,
    v_student.class_code,
    v_claim.mentor_uuid,
    v_claim.id,
    v_claim.category_id,
    v_claim.rule_id,
    v_claim.category_name,
    v_claim.activity_name,
    v_claim.coins,
    auth.uid(),
    'Confirmed by ' || v_reviewer_name,
    v_claim.proof_notes
  )
  RETURNING * INTO v_tx;

  INSERT INTO public.audit_logs (
    actor_uid, actor_username, actor_role, action, entity_type, entity_id, after_data
  ) VALUES (
    auth.uid(), v_reviewer_user, v_role, 'CLAIM_APPROVED', 'coin_claims', p_claim_id::text,
    jsonb_build_object('claim_id', p_claim_id, 'tx_id', v_tx.id, 'coins', v_claim.coins, 'student_id', v_student.student_id)
  );

  RETURN v_tx;
END;
$$;

-- RPC 4: Atomic Mentor / Super Admin Claim Rejection
CREATE OR REPLACE FUNCTION public.reject_coin_claim(p_claim_id UUID, p_reason TEXT DEFAULT NULL)
RETURNS public.coin_claims
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role TEXT;
  v_mentor_id UUID;
  v_reviewer_name TEXT;
  v_reviewer_user TEXT;
  v_claim public.coin_claims%ROWTYPE;
BEGIN
  v_role := public.current_app_role();
  IF v_role NOT IN ('SUPER_ADMIN', 'MENTOR') THEN
    RAISE EXCEPTION 'Only authorized Mentors or Super Admin can reject coin claims.';
  END IF;

  SELECT display_name, username, mentor_uuid
  INTO v_reviewer_name, v_reviewer_user, v_mentor_id
  FROM public.profiles WHERE id = auth.uid();

  SELECT * INTO v_claim FROM public.coin_claims WHERE id = p_claim_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Claim record not found.';
  END IF;

  IF v_claim.status <> 'PENDING' THEN
    RAISE EXCEPTION 'Claim has already been processed (status: %).', v_claim.status;
  END IF;

  IF v_role = 'MENTOR' AND v_claim.mentor_uuid <> v_mentor_id THEN
    RAISE EXCEPTION 'Access denied: Mentors can only reject claims for their own assigned mentees.';
  END IF;

  UPDATE public.coin_claims
  SET
    status = 'REJECTED',
    reviewed_by_uid = auth.uid(),
    reviewed_by_name = v_reviewer_name,
    reviewed_at = NOW(),
    rejection_reason = NULLIF(trim(COALESCE(p_reason, '')), '')
  WHERE id = p_claim_id
  RETURNING * INTO v_claim;

  INSERT INTO public.audit_logs (
    actor_uid, actor_username, actor_role, action, entity_type, entity_id, after_data
  ) VALUES (
    auth.uid(), v_reviewer_user, v_role, 'CLAIM_REJECTED', 'coin_claims', p_claim_id::text, to_jsonb(v_claim)
  );

  RETURN v_claim;
END;
$$;

-- RPC 5: Direct Atomic Coin Award (Mentors for own mentees / Super Admin for any student or class)
CREATE OR REPLACE FUNCTION public.award_coins_atomic(
  p_target_type TEXT,
  p_student_uuid UUID,
  p_class_code TEXT,
  p_rule_id TEXT,
  p_custom_coins INTEGER DEFAULT NULL,
  p_notes TEXT DEFAULT NULL,
  p_idempotency_key TEXT DEFAULT NULL
)
RETURNS public.coin_transactions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role TEXT;
  v_mentor_id UUID;
  v_actor_name TEXT;
  v_actor_user TEXT;
  v_student public.students%ROWTYPE;
  v_rule public.coin_rules%ROWTYPE;
  v_cat public.coin_categories%ROWTYPE;
  v_coins INTEGER;
  v_existing public.coin_transactions%ROWTYPE;
  v_tx public.coin_transactions%ROWTYPE;
BEGIN
  v_role := public.current_app_role();
  IF v_role NOT IN ('SUPER_ADMIN', 'MENTOR') THEN
    RAISE EXCEPTION 'Access denied: Only Mentors and Super Admin can award coins.';
  END IF;

  IF p_idempotency_key IS NOT NULL THEN
    SELECT * INTO v_existing FROM public.coin_transactions WHERE idempotency_key = p_idempotency_key;
    IF FOUND THEN
      RETURN v_existing;
    END IF;
  END IF;

  SELECT display_name, username, mentor_uuid
  INTO v_actor_name, v_actor_user, v_mentor_id
  FROM public.profiles WHERE id = auth.uid();

  SELECT * INTO v_rule FROM public.coin_rules WHERE id = p_rule_id AND is_active = TRUE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Invalid or inactive coin rule.';
  END IF;
  SELECT * INTO v_cat FROM public.coin_categories WHERE id = v_rule.category_id;

  IF v_rule.is_custom THEN
    v_coins := COALESCE(p_custom_coins, 0);
  ELSE
    v_coins := v_rule.coin_value;
  END IF;

  IF v_coins IS NULL OR v_coins <= 0 OR v_coins > 200 THEN
    RAISE EXCEPTION 'Invalid coin amount: %', v_coins;
  END IF;

  IF p_target_type = 'STUDENT' THEN
    SELECT * INTO v_student FROM public.students WHERE id = p_student_uuid AND is_active = TRUE FOR UPDATE;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Student not found.';
    END IF;
    IF v_role = 'MENTOR' AND v_student.mentor_id <> v_mentor_id THEN
      RAISE EXCEPTION 'Access denied: Mentors can only award coins directly to their own assigned mentees.';
    END IF;

    INSERT INTO public.coin_transactions (
      target_type, student_uuid, class_code, mentor_uuid, category_id, rule_id,
      category_name, activity_name, coins_delta, awarded_by_uid, awarded_by_name, notes, idempotency_key
    ) VALUES (
      'STUDENT', v_student.id, v_student.class_code, v_student.mentor_id, v_cat.id, v_rule.id,
      v_cat.category_name, v_rule.activity_name, v_coins, auth.uid(), v_actor_name, p_notes, p_idempotency_key
    )
    RETURNING * INTO v_tx;
  ELSIF p_target_type = 'CLASS' THEN
    IF v_role <> 'SUPER_ADMIN' THEN
      RAISE EXCEPTION 'Only Super Admin can award class-level batch bonus coins.';
    END IF;
    INSERT INTO public.coin_transactions (
      target_type, student_uuid, class_code, mentor_uuid, category_id, rule_id,
      category_name, activity_name, coins_delta, awarded_by_uid, awarded_by_name, notes, idempotency_key
    ) VALUES (
      'CLASS', NULL, p_class_code, NULL, v_cat.id, v_rule.id,
      v_cat.category_name, v_rule.activity_name, v_coins, auth.uid(), v_actor_name, p_notes, p_idempotency_key
    )
    RETURNING * INTO v_tx;
  ELSE
    RAISE EXCEPTION 'Invalid target_type: %', p_target_type;
  END IF;

  INSERT INTO public.audit_logs (
    actor_uid, actor_username, actor_role, action, entity_type, entity_id, after_data
  ) VALUES (
    auth.uid(), v_actor_user, v_role, 'COINS_AWARDED', 'coin_transactions', v_tx.id::text, to_jsonb(v_tx)
  );

  RETURN v_tx;
END;
$$;

-- RPC 6: Super Admin Compensating Reversal Transaction (Never deletes immutable history)
CREATE OR REPLACE FUNCTION public.reverse_coin_transaction(p_tx_id UUID, p_reason TEXT)
RETURNS public.coin_transactions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_orig public.coin_transactions%ROWTYPE;
  v_actor_name TEXT;
  v_actor_user TEXT;
  v_rev public.coin_transactions%ROWTYPE;
BEGIN
  IF NOT public.is_super_admin() THEN
    RAISE EXCEPTION 'Only Super Admin can reverse ledger transactions.';
  END IF;

  SELECT display_name, username INTO v_actor_name, v_actor_user
  FROM public.profiles WHERE id = auth.uid();

  SELECT * INTO v_orig FROM public.coin_transactions WHERE id = p_tx_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Transaction not found.';
  END IF;
  IF v_orig.coins_delta < 0 THEN
    RAISE EXCEPTION 'Cannot reverse a reversal entry.';
  END IF;

  INSERT INTO public.coin_transactions (
    target_type, student_uuid, class_code, mentor_uuid, category_id, rule_id,
    category_name, activity_name, coins_delta, reversal_of_tx_uuid,
    awarded_by_uid, awarded_by_name, notes
  ) VALUES (
    v_orig.target_type,
    v_orig.student_uuid,
    v_orig.class_code,
    v_orig.mentor_uuid,
    v_orig.category_id,
    v_orig.rule_id,
    'REVERSAL: ' || v_orig.category_name,
    'Reversal of ' || v_orig.activity_name || ' (' || v_orig.tx_code || ')',
    -v_orig.coins_delta,
    v_orig.id,
    auth.uid(),
    v_actor_name,
    COALESCE(NULLIF(trim(p_reason), ''), 'Administrative reversal')
  )
  RETURNING * INTO v_rev;

  INSERT INTO public.audit_logs (
    actor_uid, actor_username, actor_role, action, entity_type, entity_id, before_data, after_data
  ) VALUES (
    auth.uid(), v_actor_user, 'SUPER_ADMIN', 'TX_REVERSED', 'coin_transactions', p_tx_id::text, to_jsonb(v_orig), to_jsonb(v_rev)
  );

  RETURN v_rev;
END;
$$;

-- ============================================================================
-- SUPABASE STORAGE BUCKETS & STRICT EVIDENCE RLS
-- ============================================================================
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  VALUES
    ('claim-evidence', 'claim-evidence', FALSE, 5242880, ARRAY['image/jpeg','image/png','image/webp','application/pdf']),
    ('avatars', 'avatars', TRUE, 2097152, ARRAY['image/jpeg','image/png','image/webp'])
  ON CONFLICT (id) DO NOTHING;

  DROP POLICY IF EXISTS "evidence_student_insert" ON storage.objects;
  CREATE POLICY "evidence_student_insert" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'claim-evidence'
    AND public.current_app_role() = 'STUDENT'
    AND (storage.foldername(name))[1] = public.current_student_uuid()::text
  );

  DROP POLICY IF EXISTS "evidence_student_update" ON storage.objects;
  CREATE POLICY "evidence_student_update" ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'claim-evidence'
    AND public.current_app_role() = 'STUDENT'
    AND (storage.foldername(name))[1] = public.current_student_uuid()::text
  );

  DROP POLICY IF EXISTS "evidence_authorized_read" ON storage.objects;
  CREATE POLICY "evidence_authorized_read" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'claim-evidence'
    AND (
      public.is_super_admin()
      OR (storage.foldername(name))[1] = public.current_student_uuid()::text
      OR (
        public.current_app_role() = 'MENTOR'
        AND (storage.foldername(name))[1] IN (
          SELECT id::text FROM public.students WHERE mentor_id = public.current_mentor_uuid()
        )
      )
    )
  );

  DROP POLICY IF EXISTS "avatars_public_read" ON storage.objects;
  CREATE POLICY "avatars_public_read" ON storage.objects
  FOR SELECT USING (bucket_id = 'avatars');

  DROP POLICY IF EXISTS "avatars_authenticated_insert" ON storage.objects;
  CREATE POLICY "avatars_authenticated_insert" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'avatars'
    AND auth.uid() IS NOT NULL
    AND (
      public.is_super_admin()
      OR (storage.foldername(name))[1] = COALESCE(public.current_student_uuid()::text, public.current_mentor_uuid()::text)
    )
  );

  DROP POLICY IF EXISTS "avatars_authenticated_update" ON storage.objects;
  CREATE POLICY "avatars_authenticated_update" ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'avatars'
    AND auth.uid() IS NOT NULL
    AND (
      public.is_super_admin()
      OR (storage.foldername(name))[1] = COALESCE(public.current_student_uuid()::text, public.current_mentor_uuid()::text)
    )
  );
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Storage policy setup notice: %', SQLERRM;
END $$;
