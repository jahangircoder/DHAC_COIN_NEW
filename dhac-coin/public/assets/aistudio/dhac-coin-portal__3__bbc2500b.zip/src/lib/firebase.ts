import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

export const BOOTSTRAP_SUPER_ADMIN_EMAIL = 'sidrastudentunion@gmail.com';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account',
});

export { app, firebaseConfig };

export type FirebaseConnectionState = 'checking' | 'connected' | 'offline' | 'quota_exceeded';

export async function testFirestoreConnection(): Promise<FirebaseConnectionState> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return 'connected';
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('the client is offline')) {
        console.error('Please check your Firebase configuration.');
        return 'offline';
      }
      if (error.message.includes('Quota exceeded')) {
        console.error(
          `Firestore daily quota exceeded. Upgrade or inspect database at: https://console.firebase.google.com/project/${firebaseConfig.projectId}/firestore/databases/${firebaseConfig.firestoreDatabaseId}/data?openUpgradeDialog=true`
        );
        return 'quota_exceeded';
      }
    }
    return 'offline';
  }
}

// Mandatory boot connectivity verification
void testFirestoreConnection();
