import React, { useState, useMemo } from 'react';
import {
  X,
  Lock,
  Shield,
  User,
  CheckCircle2,
  GraduationCap,
  Award,
  Sparkles,
  LogOut,
  Info,
} from 'lucide-react';
import { User as FirebaseUser } from 'firebase/auth';
import { AuthUser, StudentRecord, TeacherRecord } from '../types/student';
import {
  signInWithGoogleAccount,
  signOutFirebase,
  linkCurrentUserToStudent,
  linkCurrentUserToAuthorizedMentor,
} from '../services/firebaseAuthService';
import { BOOTSTRAP_SUPER_ADMIN_EMAIL } from '../lib/firebase';
import { formatFirestoreErrorForUser } from '../lib/firestoreErrors';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess?: (user: AuthUser) => void;
  students: StudentRecord[];
  teachers?: TeacherRecord[];
  firebaseUser?: FirebaseUser | null;
  currentUser?: AuthUser | null;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  students,
  teachers = [],
  firebaseUser,
  currentUser,
}) => {
  const [selectedClass, setSelectedClass] = useState<string>('S4');
  const [adNoInput, setAdNoInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [infoMessage, setInfoMessage] = useState<string | null>(null);

  const availableClasses = useMemo(
    () => Array.from(new Set(students.map((s) => s.className))).sort(),
    [students]
  );

  // Check if signed-in Google email matches an authorized faculty mentor
  const matchedAuthorizedMentor = useMemo(() => {
    const email = firebaseUser?.email?.trim().toLowerCase();
    if (!email) return null;
    return (
      teachers.find(
        (t) => t.assignedEmail && t.assignedEmail.trim().toLowerCase() === email
      ) || null
    );
  }, [firebaseUser, teachers]);

  // Match student by class + AD number when user types in verification form
  const matchedStudent = useMemo(() => {
    const cleanAd = adNoInput.trim().toUpperCase().replace('*', '');
    if (!cleanAd) return null;
    return (
      students.find(
        (s) =>
          s.className === selectedClass &&
          (s.adNo.toUpperCase().replace('*', '') === cleanAd ||
            s.studentId.toUpperCase() === cleanAd)
      ) ||
      students.find(
        (s) => s.adNo.toUpperCase().replace('*', '') === cleanAd
      ) ||
      null
    );
  }, [students, selectedClass, adNoInput]);

  if (!isOpen) return null;

  const handleGoogleLogin = async () => {
    setError(null);
    setInfoMessage(null);
    setIsLoading(true);
    try {
      await signInWithGoogleAccount();
      setInfoMessage('Google authentication verified! Checking your institutional role profile...');
    } catch (err: any) {
      if (err?.code === 'auth/popup-closed-by-user') {
        setError('Sign-in popup was closed before completing Google authentication.');
      } else {
        setError(formatFirestoreErrorForUser(err));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleBindStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser) return;
    setError(null);

    if (!matchedStudent) {
      setError(
        `No student found matching AD #${adNoInput.trim()} in Class ${selectedClass}. Please verify your admission number.`
      );
      return;
    }

    setIsLoading(true);
    try {
      await linkCurrentUserToStudent(firebaseUser, matchedStudent);
      const boundUser: AuthUser = {
        uid: firebaseUser.uid,
        email: firebaseUser.email || undefined,
        role: 'STUDENT',
        displayName: `${matchedStudent.name} (AD #${matchedStudent.adNo})`,
        username: `student_${matchedStudent.adNo}`,
        studentId: matchedStudent.id,
        studentDocId: matchedStudent.id,
        adNo: matchedStudent.adNo,
        className: matchedStudent.className,
        photoUrl: matchedStudent.photoUrl || firebaseUser.photoURL || undefined,
      };
      onLoginSuccess?.(boundUser);
      onClose();
    } catch (err) {
      setError(formatFirestoreErrorForUser(err));
    } finally {
      setIsLoading(false);
    }
  };

  const handleBindAuthorizedMentor = async () => {
    if (!firebaseUser || !matchedAuthorizedMentor) return;
    setError(null);
    setIsLoading(true);
    try {
      await linkCurrentUserToAuthorizedMentor(firebaseUser, matchedAuthorizedMentor);
      const boundMentor: AuthUser = {
        uid: firebaseUser.uid,
        email: firebaseUser.email || undefined,
        role: 'TEACHER_ADMIN',
        displayName: `${matchedAuthorizedMentor.name} (${matchedAuthorizedMentor.teacherId})`,
        username: matchedAuthorizedMentor.username,
        teacherId: matchedAuthorizedMentor.teacherId,
        mentorDocId: matchedAuthorizedMentor.id,
        mentorName: matchedAuthorizedMentor.name,
        photoUrl: firebaseUser.photoURL || undefined,
      };
      onLoginSuccess?.(boundMentor);
      onClose();
    } catch (err) {
      setError(formatFirestoreErrorForUser(err));
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignOut = async () => {
    setIsLoading(true);
    try {
      await signOutFirebase();
      setInfoMessage(null);
      setError(null);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/65 backdrop-blur-xs overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0a1026] via-indigo-950 to-violet-950 text-white p-5 sm:p-6 relative border-b-2 border-amber-400">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition touch-manipulation min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-400 text-amber-300 flex items-center justify-center shadow-xs shrink-0">
              <Lock className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="text-[10px] sm:text-[11px] font-mono tracking-wider text-amber-300 uppercase font-semibold">
                DARUL HUDA ISLAMIC UNIVERSITY • ASSAM CENTRE
              </div>
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                Firebase Cloud Portal Authentication
              </h2>
            </div>
          </div>
          <p className="text-xs text-violet-200/85 mt-1">
            Verified Google Sign-In with Cloud Firestore Role-Based Access Control (Super Admin, Mentors & Students).
          </p>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs rounded-xl font-medium flex items-start gap-2">
              <span className="font-bold shrink-0">✕</span>
              <span>{error}</span>
            </div>
          )}

          {infoMessage && (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs rounded-xl font-medium flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{infoMessage}</span>
            </div>
          )}

          {!firebaseUser ? (
            <>
              {/* Primary Google Sign-In Action */}
              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={isLoading}
                className="w-full py-3.5 px-4 bg-slate-900 dark:bg-white text-white dark:text-slate-950 hover:bg-slate-800 dark:hover:bg-slate-100 rounded-xl font-bold text-sm shadow-lg flex items-center justify-center gap-3 transition cursor-pointer disabled:opacity-60"
              >
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#EA4335"
                    d="M12 5c1.6 0 3 .6 4.1 1.7l3.1-3.1C17.3 1.8 14.8 1 12 1 7.4 1 3.5 3.6 1.6 7.4l3.7 2.8C6.2 7.2 8.9 5 12 5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.6l3.7 2.9c2.2-2 3.7-5 3.7-8.7z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.3 14.8c-.2-.8-.4-1.8-.4-2.8s.2-2 .4-2.8L1.6 6.4C.6 8.1 0 10 0 12s.6 3.9 1.6 5.6l3.7-2.8z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3.1 0-5.8-2.1-6.7-5L1.6 16.1C3.5 20.4 7.4 23 12 23z"
                  />
                </svg>
                <span>{isLoading ? 'Connecting to Firebase Auth...' : 'Continue with Google Account'}</span>
              </button>

              {/* Institutional Access & Credential Reference Guide */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl space-y-2.5 text-xs">
                <div className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-violet-600 dark:text-violet-400" />
                  <span>DHAC Institutional Access Reference Guide</span>
                </div>

                <div className="space-y-2 text-[11px] text-slate-600 dark:text-slate-300">
                  <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700 flex items-start justify-between gap-2">
                    <div>
                      <span className="font-bold text-amber-700 dark:text-amber-300 block">
                        1. Super Admin (Master Console & DB Sync)
                      </span>
                      <span>
                        Sign in using authorized Google email:{' '}
                        <code className="font-mono font-bold text-slate-900 dark:text-white">
                          {BOOTSTRAP_SUPER_ADMIN_EMAIL}
                        </code>
                      </span>
                    </div>
                    <span className="px-1.5 py-0.5 bg-amber-100 dark:bg-amber-900/50 text-amber-900 dark:text-amber-200 rounded font-mono text-[10px] font-bold shrink-0">
                      SUPER_ADMIN
                    </span>
                  </div>

                  <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700 flex items-start justify-between gap-2">
                    <div>
                      <span className="font-bold text-emerald-700 dark:text-emerald-300 block">
                        2. Faculty Mentors (20 Ustads)
                      </span>
                      <span>
                        Sign in with your Google email pre-linked by Admin in the Mentors Registry to open the Claim Confirmation Desk & Coin Engine.
                      </span>
                    </div>
                    <span className="px-1.5 py-0.5 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-900 dark:text-emerald-200 rounded font-mono text-[10px] font-bold shrink-0">
                      TEACHER_ADMIN
                    </span>
                  </div>

                  <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700 flex items-start justify-between gap-2">
                    <div>
                      <span className="font-bold text-indigo-700 dark:text-indigo-300 block">
                        3. Students (290 Cohort Profiles)
                      </span>
                      <span>
                        Sign in with any Google account, then verify your <strong>Academic Class + AD Number</strong> (e.g. Class S4 · AD 635) to access your ID card & submit claims.
                      </span>
                    </div>
                    <span className="px-1.5 py-0.5 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-900 dark:text-indigo-200 rounded font-mono text-[10px] font-bold shrink-0">
                      STUDENT
                    </span>
                  </div>
                </div>
              </div>
            </>
          ) : (
            /* Authenticated Firebase Session View */
            <div className="space-y-4">
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  {firebaseUser.photoURL ? (
                    <img
                      src={firebaseUser.photoURL}
                      alt={firebaseUser.displayName || 'User'}
                      className="w-10 h-10 rounded-full border border-amber-400 shrink-0"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-violet-900 text-amber-300 flex items-center justify-center font-bold shrink-0">
                      {(firebaseUser.displayName || firebaseUser.email || 'U').charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {currentUser?.displayName || firebaseUser.displayName}
                    </div>
                    <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400 truncate">
                      {firebaseUser.email}
                    </div>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold bg-violet-600 text-white shrink-0">
                  {currentUser?.role || 'VIEWER'}
                </span>
              </div>

              {/* Pre-Authorized Faculty Mentor Activation Card */}
              {currentUser?.role === 'VIEWER' && matchedAuthorizedMentor && (
                <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 rounded-xl space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-900 dark:text-emerald-200">
                    <Award className="w-4 h-4 text-emerald-600" />
                    <span>Pre-Authorized Faculty Mentor Detected!</span>
                  </div>
                  <p className="text-xs text-emerald-800 dark:text-emerald-300">
                    Your Google email matches faculty mentor{' '}
                    <strong>{matchedAuthorizedMentor.name}</strong> ({matchedAuthorizedMentor.teacherId}).
                  </p>
                  <button
                    type="button"
                    onClick={handleBindAuthorizedMentor}
                    disabled={isLoading}
                    className="w-full py-2.5 px-4 bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg shadow-xs cursor-pointer"
                  >
                    Activate Faculty Mentor Role Now
                  </button>
                </div>
              )}

              {/* Student Self-Verification & Role Binding Form for VIEWER accounts */}
              {currentUser?.role === 'VIEWER' && (
                <form
                  onSubmit={handleBindStudent}
                  className="p-4 bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800/70 rounded-xl space-y-3"
                >
                  <div className="flex items-center gap-2 text-xs font-bold text-indigo-950 dark:text-indigo-200">
                    <GraduationCap className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                    <span>Verify Student Profile (Unlock Student Coin Portal)</span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300">
                    Select your Academic Class and enter your DHAC Admission Number to bind this Google account to your student record:
                  </p>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Academic Class
                      </label>
                      <select
                        value={selectedClass}
                        onChange={(e) => setSelectedClass(e.target.value)}
                        className="w-full px-2.5 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg font-semibold text-slate-900 dark:text-white"
                      >
                        {availableClasses.map((cls) => (
                          <option key={cls} value={cls}>
                            Class {cls}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Admission No (AD)
                      </label>
                      <input
                        type="text"
                        required
                        value={adNoInput}
                        onChange={(e) => setAdNoInput(e.target.value)}
                        placeholder="e.g. 635"
                        className="w-full px-2.5 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg font-mono text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>

                  {matchedStudent && (
                    <div className="p-2.5 bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700 rounded-lg flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-slate-900 dark:text-white">
                          {matchedStudent.name}
                        </div>
                        <div className="text-[10px] font-mono text-slate-500 dark:text-slate-400">
                          {matchedStudent.officialId} • Mentor: {matchedStudent.mentorName}
                        </div>
                      </div>
                      <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={isLoading || !matchedStudent}
                    className="w-full py-2.5 px-4 bg-indigo-700 hover:bg-indigo-600 disabled:bg-slate-400 text-white font-bold text-xs rounded-lg shadow-xs transition cursor-pointer"
                  >
                    {isLoading ? 'Verifying with Firestore...' : 'Link Student Profile & Open Portal'}
                  </button>
                </form>
              )}

              {/* Already Bound Role Summary */}
              {currentUser && currentUser.role !== 'VIEWER' && (
                <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>
                    Active role <strong>{currentUser.role}</strong> is verified and synchronized with Cloud Firestore.
                  </span>
                </div>
              )}

              <div className="pt-2 flex items-center justify-between gap-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={handleSignOut}
                  disabled={isLoading}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 rounded-lg transition cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2 text-xs font-bold text-white bg-slate-900 dark:bg-violet-600 hover:bg-slate-800 rounded-lg transition cursor-pointer"
                >
                  Continue to Portal
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
