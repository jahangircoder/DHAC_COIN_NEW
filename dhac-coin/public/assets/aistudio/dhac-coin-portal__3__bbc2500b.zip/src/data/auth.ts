import { AuthUser } from '../types/student';
import { BOOTSTRAP_SUPER_ADMIN_EMAIL } from '../lib/firebase';

const AUTH_STORAGE_KEY = 'dhac_firebase_auth_profile_v1';

export { BOOTSTRAP_SUPER_ADMIN_EMAIL };

export function saveAuthProfileCache(user: AuthUser): void {
  try {
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(user));
  } catch {
    // storage unavailable
  }
}

export function getStoredAuth(): AuthUser | null {
  try {
    const stored = localStorage.getItem(AUTH_STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored) as AuthUser;
    }
  } catch {
    // ignore
  }
  return null;
}

export function logoutAuth(): void {
  try {
    localStorage.removeItem(AUTH_STORAGE_KEY);
    localStorage.removeItem('dhac_auth_user_session_v4');
    localStorage.removeItem('dhac_custom_passwords_v2');
  } catch {
    // ignore
  }
}
