import {
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  onSnapshot,
  serverTimestamp,
  collection,
  query,
  where,
} from 'firebase/firestore';
import {
  auth,
  db,
  googleProvider,
  BOOTSTRAP_SUPER_ADMIN_EMAIL,
} from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/firestoreErrors';
import {
  boundNonEmptyString,
  boundOptionalString,
  isValidFirestoreId,
  sanitizeIdSegment,
} from '../lib/validation';
import { AuthUser, StudentRecord, TeacherRecord } from '../types/student';
import { getMentorDocId } from '../data/teachers';
import { saveAuthProfileCache, logoutAuth } from '../data/auth';

export interface FirebaseAuthSessionState {
  firebaseUser: FirebaseUser | null;
  authUser: AuthUser | null;
  authReady: boolean;
  userProfileLoaded: boolean;
}

export interface ManagedUserDirectoryItem {
  uid: string;
  displayName: string;
  role: AuthUser['role'];
  username?: string;
  teacherId?: string;
  mentorDocId?: string;
  mentorName?: string;
  studentDocId?: string;
  adNo?: string;
  className?: string;
}

function mapFirestoreUserToAuthUser(
  fbUser: FirebaseUser,
  data: Record<string, unknown>
): AuthUser {
  const rawRole = String(data.role || 'VIEWER');
  const role: AuthUser['role'] =
    rawRole === 'SUPER_ADMIN' ||
    rawRole === 'TEACHER_ADMIN' ||
    rawRole === 'STUDENT' ||
    rawRole === 'VIEWER'
      ? rawRole
      : 'VIEWER';

  const displayName = boundNonEmptyString(
    data.displayName,
    120,
    fbUser.displayName || fbUser.email?.split('@')[0] || 'DHAC Member'
  );
  const username = boundNonEmptyString(
    data.username,
    64,
    fbUser.email?.split('@')[0] || fbUser.uid.slice(0, 12)
  );

  return {
    uid: fbUser.uid,
    email: fbUser.email || undefined,
    role,
    displayName,
    username,
    teacherId: boundOptionalString(data.teacherId, 32),
    mentorDocId: boundOptionalString(data.mentorDocId, 32),
    mentorName: boundOptionalString(data.mentorName, 100),
    studentId: boundOptionalString(data.studentDocId, 32),
    studentDocId: boundOptionalString(data.studentDocId, 32),
    adNo: boundOptionalString(data.adNo, 20),
    className: boundOptionalString(data.className, 16),
    photoUrl: boundOptionalString(data.photoUrl, 50000) || fbUser.photoURL || undefined,
  };
}

export async function ensureFirebaseUserProvisioned(
  fbUser: FirebaseUser
): Promise<AuthUser> {
  const uid = fbUser.uid;
  const email = (fbUser.email || '').trim().toLowerCase();
  const isBootstrapSuper =
    fbUser.emailVerified === true && email === BOOTSTRAP_SUPER_ADMIN_EMAIL.toLowerCase();

  const userRef = doc(db, 'users', uid);
  const privateRef = doc(db, 'users', uid, 'private', 'info');
  const adminRef = doc(db, 'admins', uid);

  let existingUserData: Record<string, unknown> | null = null;
  try {
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      existingUserData = snap.data() as Record<string, unknown>;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${uid}`);
  }

  // Provision /admins/{uid} first if verified bootstrap Super Admin
  if (isBootstrapSuper) {
    try {
      const adminSnap = await getDoc(adminRef);
      if (!adminSnap.exists()) {
        await setDoc(adminRef, {
          uid,
          email: boundNonEmptyString(fbUser.email, 160, BOOTSTRAP_SUPER_ADMIN_EMAIL),
          role: 'SUPER_ADMIN',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `admins/${uid}`);
    }
  }

  // Create non-PII /users/{uid} document if first login
  if (!existingUserData) {
    const defaultRole: AuthUser['role'] = isBootstrapSuper ? 'SUPER_ADMIN' : 'VIEWER';
    const defaultDisplay = isBootstrapSuper
      ? boundNonEmptyString(fbUser.displayName, 120, 'Super Admin (Sidra)')
      : boundNonEmptyString(
          fbUser.displayName,
          120,
          email ? email.split('@')[0].toUpperCase() : 'Campus Member'
        );
    const defaultUsername = isBootstrapSuper
      ? 'sidra2026'
      : sanitizeIdSegment(email ? email.split('@')[0] : uid, 'DHAC');

    const profilePayload: Record<string, unknown> = {
      uid,
      displayName: defaultDisplay,
      role: defaultRole,
      username: defaultUsername,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    try {
      await setDoc(userRef, profilePayload);
      existingUserData = profilePayload;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${uid}`);
    }
  } else if (isBootstrapSuper && existingUserData.role !== 'SUPER_ADMIN') {
    try {
      await updateDoc(userRef, {
        role: 'SUPER_ADMIN',
        updatedAt: serverTimestamp(),
      });
      existingUserData = { ...existingUserData, role: 'SUPER_ADMIN' };
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
    }
  }

  // Provision isolated PII subcollection /users/{uid}/private/info
  try {
    const privSnap = await getDoc(privateRef);
    if (!privSnap.exists() && fbUser.emailVerified) {
      await setDoc(privateRef, {
        uid,
        email: boundNonEmptyString(fbUser.email, 160, 'member@dhac.edu.in'),
        providerId: boundNonEmptyString(
          fbUser.providerData?.[0]?.providerId || 'google.com',
          64,
          'google.com'
        ),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${uid}/private/info`);
  }

  // Fetch canonical stored document
  try {
    const freshSnap = await getDoc(userRef);
    if (freshSnap.exists()) {
      const mapped = mapFirestoreUserToAuthUser(
        fbUser,
        freshSnap.data() as Record<string, unknown>
      );
      saveAuthProfileCache(mapped);
      return mapped;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${uid}`);
  }

  const fallback = mapFirestoreUserToAuthUser(fbUser, existingUserData || {});
  saveAuthProfileCache(fallback);
  return fallback;
}

export function subscribeToFirebaseAuth(
  onChange: (state: FirebaseAuthSessionState) => void
): () => void {
  let unsubscribeUserDoc: (() => void) | null = null;

  const unsubscribeAuth = onAuthStateChanged(auth, async (fbUser) => {
    if (unsubscribeUserDoc) {
      unsubscribeUserDoc();
      unsubscribeUserDoc = null;
    }

    if (!fbUser) {
      logoutAuth();
      onChange({
        firebaseUser: null,
        authUser: null,
        authReady: true,
        userProfileLoaded: true,
      });
      return;
    }

    try {
      const initialAuthUser = await ensureFirebaseUserProvisioned(fbUser);
      onChange({
        firebaseUser: fbUser,
        authUser: initialAuthUser,
        authReady: true,
        userProfileLoaded: true,
      });

      const userRef = doc(db, 'users', fbUser.uid);
      unsubscribeUserDoc = onSnapshot(
        userRef,
        (snapshot) => {
          if (snapshot.exists()) {
            const updatedAuthUser = mapFirestoreUserToAuthUser(
              fbUser,
              snapshot.data() as Record<string, unknown>
            );
            saveAuthProfileCache(updatedAuthUser);
            onChange({
              firebaseUser: fbUser,
              authUser: updatedAuthUser,
              authReady: true,
              userProfileLoaded: true,
            });
          }
        },
        (error) => {
          handleFirestoreError(error, OperationType.GET, `users/${fbUser.uid}`);
        }
      );
    } catch (error) {
      console.error('[FIREBASE AUTH PROVISION ERROR]:', error);
      onChange({
        firebaseUser: fbUser,
        authUser: null,
        authReady: true,
        userProfileLoaded: true,
      });
    }
  });

  return () => {
    if (unsubscribeUserDoc) unsubscribeUserDoc();
    unsubscribeAuth();
  };
}

export async function signInWithGoogleAccount(): Promise<FirebaseUser> {
  const result = await signInWithPopup(auth, googleProvider);
  return result.user;
}

export async function signOutFirebase(): Promise<void> {
  await signOut(auth);
  logoutAuth();
}

/**
 * Allows a signed-in Google user (currently in VIEWER role) to self-bind
 * to their official Student profile verified against /students/{studentDocId} in Firestore rules.
 */
export async function linkCurrentUserToStudent(
  fbUser: FirebaseUser,
  student: StudentRecord
): Promise<void> {
  if (!isValidFirestoreId(student.id)) {
    throw new Error('Invalid student document identifier.');
  }
  const userRef = doc(db, 'users', fbUser.uid);
  try {
    await updateDoc(userRef, {
      role: 'STUDENT',
      studentDocId: student.id,
      adNo: boundNonEmptyString(student.adNo, 20, student.adNo),
      className: boundNonEmptyString(student.className, 16, student.className),
      displayName: boundNonEmptyString(`${student.name} (AD #${student.adNo})`, 120, student.name),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${fbUser.uid}`);
  }
}

/**
 * Automatically or manually binds a signed-in Google user to a Faculty Mentor record
 * when their verified Google email matches mentor.assignedEmail in Firestore.
 */
export async function linkCurrentUserToAuthorizedMentor(
  fbUser: FirebaseUser,
  mentor: TeacherRecord
): Promise<void> {
  const mentorDocId = getMentorDocId(mentor);
  if (!isValidFirestoreId(mentorDocId)) {
    throw new Error('Invalid mentor document identifier.');
  }
  const userRef = doc(db, 'users', fbUser.uid);
  try {
    await updateDoc(userRef, {
      role: 'TEACHER_ADMIN',
      teacherId: boundNonEmptyString(mentor.teacherId, 32, mentor.teacherId),
      mentorDocId,
      mentorName: boundNonEmptyString(mentor.name, 100, mentor.name),
      displayName: boundNonEmptyString(`${mentor.name} (${mentor.teacherId})`, 120, mentor.name),
      username: boundNonEmptyString(mentor.username, 64, mentor.username),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${fbUser.uid}`);
  }
}

/**
 * Super Admin action: Assign or update any signed-in user's institutional role & link in /users/{uid}.
 */
export async function assignUserRoleBySuperAdmin(params: {
  targetUid: string;
  role: AuthUser['role'];
  displayName: string;
  mentor?: TeacherRecord | null;
  student?: StudentRecord | null;
}): Promise<void> {
  const { targetUid, role, displayName, mentor, student } = params;
  if (!isValidFirestoreId(targetUid)) {
    throw new Error('Invalid target UID.');
  }

  const userRef = doc(db, 'users', targetUid);
  const updatePayload: Record<string, unknown> = {
    role,
    displayName: boundNonEmptyString(displayName, 120, 'DHAC Member'),
    updatedAt: serverTimestamp(),
  };

  if (role === 'TEACHER_ADMIN' && mentor) {
    const mDocId = getMentorDocId(mentor);
    updatePayload.teacherId = boundNonEmptyString(mentor.teacherId, 32, mentor.teacherId);
    updatePayload.mentorDocId = mDocId;
    updatePayload.mentorName = boundNonEmptyString(mentor.name, 100, mentor.name);
  } else if (role === 'STUDENT' && student) {
    updatePayload.studentDocId = student.id;
    updatePayload.adNo = boundNonEmptyString(student.adNo, 20, student.adNo);
    updatePayload.className = boundNonEmptyString(student.className, 16, student.className);
  }

  try {
    await updateDoc(userRef, updatePayload);
    const adminRef = doc(db, 'admins', targetUid);
    if (role === 'SUPER_ADMIN') {
      const existingAdmin = await getDoc(adminRef);
      if (!existingAdmin.exists()) {
        await setDoc(adminRef, {
          uid: targetUid,
          email: `${sanitizeIdSegment(displayName, 'admin').toLowerCase()}@dhac.edu.in`,
          role: 'SUPER_ADMIN',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${targetUid}`);
  }
}

/**
 * Super Admin listener for registered Firebase Auth user profiles in /users.
 */
export function subscribeToUserDirectoryForAdmin(
  onUsers: (users: ManagedUserDirectoryItem[]) => void
): () => void {
  const q = query(collection(db, 'users'), where('uid', '!=', ''));
  return onSnapshot(
    q,
    (snapshot) => {
      const list: ManagedUserDirectoryItem[] = snapshot.docs.map((d) => {
        const data = d.data();
        return {
          uid: String(data.uid || d.id),
          displayName: String(data.displayName || 'User'),
          role: (data.role as AuthUser['role']) || 'VIEWER',
          username: typeof data.username === 'string' ? data.username : undefined,
          teacherId: typeof data.teacherId === 'string' ? data.teacherId : undefined,
          mentorDocId: typeof data.mentorDocId === 'string' ? data.mentorDocId : undefined,
          mentorName: typeof data.mentorName === 'string' ? data.mentorName : undefined,
          studentDocId: typeof data.studentDocId === 'string' ? data.studentDocId : undefined,
          adNo: typeof data.adNo === 'string' ? data.adNo : undefined,
          className: typeof data.className === 'string' ? data.className : undefined,
        };
      });
      onUsers(list);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, 'users');
    }
  );
}
