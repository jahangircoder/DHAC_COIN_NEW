/**
 * Phase 0 Payload-First Security TDD Runner — DHAC Coin Portal
 * Validates all 12 Dirty Dozen adversarial payloads and blueprint invariants.
 */
import assert from 'node:assert/strict';
import blueprint from './firebase-blueprint.json' with { type: 'json' };

interface MockAuthContext {
  uid: string;
  email: string;
  emailVerified: boolean;
}

const VALID_ID_REGEX = new RegExp(blueprint.entities.StudentRecord.properties.id.pattern!);
const BOOTSTRAP_ADMIN_EMAIL = 'sidrastudentunion@gmail.com';

function isValidId(id: unknown): id is string {
  return typeof id === 'string' && id.length > 0 && id.length <= 128 && VALID_ID_REGEX.test(id);
}

// Mirror of firestore.rules validation & authorization gates for TDD verification
function simulateRuleCheck(params: {
  collection: string;
  docId: string;
  op: 'get' | 'create' | 'update' | 'delete';
  auth: MockAuthContext | null;
  incoming?: Record<string, unknown>;
  existing?: Record<string, unknown>;
  dbState?: {
    students: Record<string, Record<string, unknown>>;
    mentors: Record<string, Record<string, unknown>>;
    users: Record<string, Record<string, unknown>>;
    admins: Record<string, Record<string, unknown>>;
    batchPaths?: Set<string>;
  };
}): 'ALLOW' | 'PERMISSION_DENIED' {
  const { collection, docId, op, auth, incoming = {}, existing, dbState } = params;
  const students = dbState?.students ?? {};
  const mentors = dbState?.mentors ?? {};
  const users = dbState?.users ?? {};
  const admins = dbState?.admins ?? {};
  const batchPaths = dbState?.batchPaths ?? new Set<string>();

  if (!isValidId(docId)) return 'PERMISSION_DENIED';

  const isSignedIn = auth !== null;
  const isVerified = isSignedIn && auth.emailVerified === true;
  const isBootstrapAdmin = isVerified && auth.email === BOOTSTRAP_ADMIN_EMAIL;
  const isAdmin =
    isBootstrapAdmin ||
    (isVerified && Boolean(admins[auth.uid] && admins[auth.uid].role === 'SUPER_ADMIN'));
  const userDoc = isSignedIn ? users[auth.uid] : undefined;
  const isMentor = isAdmin || (isVerified && userDoc?.role === 'TEACHER_ADMIN');

  if (op !== 'get' && !isVerified) return 'PERMISSION_DENIED';

  // Dirty Dozen #1, #2, #3, #12: /users/{userId}
  if (collection === 'users') {
    const allowedKeys = new Set(Object.keys(blueprint.entities.UserProfile.properties));
    const requiredKeys = blueprint.entities.UserProfile.required;

    if (op === 'create') {
      const keys = Object.keys(incoming);
      if (!requiredKeys.every((k) => keys.includes(k))) return 'PERMISSION_DENIED';
      if (!keys.every((k) => allowedKeys.has(k))) return 'PERMISSION_DENIED';
      if (incoming.uid !== auth!.uid) return 'PERMISSION_DENIED';
      if (incoming.createdAt !== '__SERVER_TIME__' || incoming.updatedAt !== '__SERVER_TIME__') {
        return 'PERMISSION_DENIED';
      }
      if (incoming.role === 'SUPER_ADMIN' && !isBootstrapAdmin) return 'PERMISSION_DENIED';
      if (incoming.role !== 'VIEWER' && !isBootstrapAdmin) return 'PERMISSION_DENIED';
      return 'ALLOW';
    }

    if (op === 'update' && existing) {
      if (!isAdmin && incoming.role !== existing.role) {
        // Owner verified role binding only from VIEWER, never to SUPER_ADMIN
        if (incoming.role === 'SUPER_ADMIN') return 'PERMISSION_DENIED';
        if (existing.role !== 'VIEWER') return 'PERMISSION_DENIED';
        if (incoming.role === 'TEACHER_ADMIN') {
          const mentor = mentors[String(incoming.mentorDocId || '')];
          if (!mentor || mentor.assignedEmail !== auth!.email) return 'PERMISSION_DENIED';
        }
        if (incoming.role === 'STUDENT') {
          const stu = students[String(incoming.studentDocId || '')];
          if (!stu || stu.adNo !== incoming.adNo || stu.className !== incoming.className) {
            return 'PERMISSION_DENIED';
          }
        }
      }
      return 'ALLOW';
    }
  }

  // Dirty Dozen #4: /admins/{adminUid}
  if (collection === 'admins') {
    return isBootstrapAdmin ? 'ALLOW' : 'PERMISSION_DENIED';
  }

  // Dirty Dozen #3, #5, #6, #7, #11, #12: /coin_claims/{claimId}
  if (collection === 'coin_claims') {
    const allowedKeys = new Set(Object.keys(blueprint.entities.CoinClaimDoc.properties));
    const requiredKeys = blueprint.entities.CoinClaimDoc.required;

    if (op === 'create') {
      const keys = Object.keys(incoming);
      if (!requiredKeys.every((k) => keys.includes(k))) return 'PERMISSION_DENIED';
      if (!keys.every((k) => allowedKeys.has(k))) return 'PERMISSION_DENIED';
      if (incoming.submittedByUid !== auth!.uid) return 'PERMISSION_DENIED';
      if (incoming.status !== 'PENDING') return 'PERMISSION_DENIED';
      if ('reviewedBy' in incoming || 'reviewedByUid' in incoming || 'reviewedAt' in incoming) {
        return 'PERMISSION_DENIED';
      }
      if (incoming.createdAt !== '__SERVER_TIME__' || incoming.updatedAt !== '__SERVER_TIME__') {
        return 'PERMISSION_DENIED';
      }
      if (!students[String(incoming.studentDocId || '')]) return 'PERMISSION_DENIED';
      if (!batchPaths.has('portal_queues/pending_claims')) return 'PERMISSION_DENIED';
      return 'ALLOW';
    }

    if (op === 'update' && existing) {
      if (!isAdmin && existing.status !== 'PENDING') return 'PERMISSION_DENIED';
      if (!isMentor) return 'PERMISSION_DENIED';
      return 'ALLOW';
    }
  }

  // Dirty Dozen #8, #11: /students/{studentDocId}
  if (collection === 'students') {
    const maxNotes = blueprint.entities.StudentRecord.properties.notes.maxLength!;
    if (typeof incoming.notes === 'string' && incoming.notes.length > maxNotes) {
      return 'PERMISSION_DENIED';
    }
    if (op === 'create' || op === 'update') {
      return isMentor ? 'ALLOW' : 'PERMISSION_DENIED';
    }
  }

  // Dirty Dozen #9: /coin_transactions/{txId}
  if (collection === 'coin_transactions') {
    if (!isMentor) return 'PERMISSION_DENIED';
    if (incoming.targetType === 'STUDENT' && !students[String(incoming.studentDocId || '')]) {
      return 'PERMISSION_DENIED';
    }
    return 'ALLOW';
  }

  // Dirty Dozen #10: /users/{userId}/private/info
  if (collection === 'users_private') {
    const [targetUid] = docId.split('__');
    if (op === 'get') {
      return isSignedIn && (auth!.uid === targetUid || isAdmin) ? 'ALLOW' : 'PERMISSION_DENIED';
    }
  }

  return 'PERMISSION_DENIED';
}

function runDirtyDozenSuite() {
  const baseDb = {
    students: {
      'STU-635': { id: 'STU-635', adNo: '635', className: 'S4', totalCoins: 0 },
    },
    mentors: {
      'STAFF-01': {
        id: 'STAFF-01',
        teacherId: 'DHAC/STAFF/01',
        assignedEmail: 'shafi@dhac.edu.in',
      },
    },
    users: {
      'uid-student': { uid: 'uid-student', role: 'STUDENT', studentDocId: 'STU-635' },
      'uid-viewer': { uid: 'uid-viewer', role: 'VIEWER' },
    },
    admins: {
      'uid-super': { uid: 'uid-super', email: BOOTSTRAP_ADMIN_EMAIL, role: 'SUPER_ADMIN' },
    },
    batchPaths: new Set(['portal_queues/pending_claims']),
  };

  // 1. Super Admin Self-Escalation
  assert.equal(
    simulateRuleCheck({
      collection: 'users',
      docId: 'uid-attacker',
      op: 'create',
      auth: { uid: 'uid-attacker', email: 'attacker@gmail.com', emailVerified: true },
      incoming: {
        uid: 'uid-attacker',
        displayName: 'Attacker',
        role: 'SUPER_ADMIN',
        createdAt: '__SERVER_TIME__',
        updatedAt: '__SERVER_TIME__',
      },
      dbState: baseDb,
    }),
    'PERMISSION_DENIED',
    'Test 1 failed: Attacker self-assigned SUPER_ADMIN'
  );

  // 2. RBAC Self-Promotion to TEACHER_ADMIN without assignedEmail match
  assert.equal(
    simulateRuleCheck({
      collection: 'users',
      docId: 'uid-viewer',
      op: 'update',
      auth: { uid: 'uid-viewer', email: 'rogue@gmail.com', emailVerified: true },
      existing: { uid: 'uid-viewer', role: 'VIEWER', createdAt: '__SERVER_TIME__' },
      incoming: {
        uid: 'uid-viewer',
        displayName: 'Rogue',
        role: 'TEACHER_ADMIN',
        teacherId: 'DHAC/STAFF/01',
        mentorDocId: 'STAFF-01',
        createdAt: '__SERVER_TIME__',
        updatedAt: '__SERVER_TIME__',
      },
      dbState: baseDb,
    }),
    'PERMISSION_DENIED',
    'Test 2 failed: Rogue promoted to TEACHER_ADMIN without email match'
  );

  // 3. Shadow / Ghost Field Injection
  assert.equal(
    simulateRuleCheck({
      collection: 'coin_claims',
      docId: 'CLM-101',
      op: 'create',
      auth: { uid: 'uid-student', email: 's@gmail.com', emailVerified: true },
      incoming: {
        id: 'CLM-101',
        submittedByUid: 'uid-student',
        studentDocId: 'STU-635',
        studentId: 'STU-635',
        studentName: 'MAHMUDUL HASSAN',
        adNo: '635',
        className: 'S4',
        mentorName: 'MOHAMED ABDU RAHIM HUDAWI',
        category: 'PUBLICATION',
        activityName: 'Essay & Article',
        coins: 10,
        submittedAt: '1/1/2026',
        status: 'PENDING',
        auditDocId: 'AUD-CLM-101',
        facultyVisible: true,
        isVerified: true, // Ghost field!
        createdAt: '__SERVER_TIME__',
        updatedAt: '__SERVER_TIME__',
      },
      dbState: baseDb,
    }),
    'PERMISSION_DENIED',
    'Test 3 failed: Ghost field isVerified allowed'
  );

  // 4. Email Spoofing with emailVerified = false
  assert.equal(
    simulateRuleCheck({
      collection: 'admins',
      docId: 'spoof-uid',
      op: 'create',
      auth: { uid: 'spoof-uid', email: BOOTSTRAP_ADMIN_EMAIL, emailVerified: false },
      incoming: {
        uid: 'spoof-uid',
        email: BOOTSTRAP_ADMIN_EMAIL,
        role: 'SUPER_ADMIN',
        createdAt: '__SERVER_TIME__',
        updatedAt: '__SERVER_TIME__',
      },
      dbState: baseDb,
    }),
    'PERMISSION_DENIED',
    'Test 4 failed: Unverified email spoofing allowed'
  );

  // 5. Identity Spoofing on Claim Submission
  assert.equal(
    simulateRuleCheck({
      collection: 'coin_claims',
      docId: 'CLM-102',
      op: 'create',
      auth: { uid: 'uid-attacker', email: 'a@gmail.com', emailVerified: true },
      incoming: {
        id: 'CLM-102',
        submittedByUid: 'uid-student', // Spoofed!
        studentDocId: 'STU-635',
        studentId: 'STU-635',
        studentName: 'MAHMUDUL HASSAN',
        adNo: '635',
        className: 'S4',
        mentorName: 'MOHAMED ABDU RAHIM HUDAWI',
        category: 'PUBLICATION',
        activityName: 'Essay & Article',
        coins: 10,
        submittedAt: '1/1/2026',
        status: 'PENDING',
        auditDocId: 'AUD-CLM-102',
        facultyVisible: true,
        createdAt: '__SERVER_TIME__',
        updatedAt: '__SERVER_TIME__',
      },
      dbState: baseDb,
    }),
    'PERMISSION_DENIED',
    'Test 5 failed: Spoofed submittedByUid allowed'
  );

  // 6. State Shortcutting (Submitting Pre-Approved Claim)
  assert.equal(
    simulateRuleCheck({
      collection: 'coin_claims',
      docId: 'CLM-103',
      op: 'create',
      auth: { uid: 'uid-student', email: 's@gmail.com', emailVerified: true },
      incoming: {
        id: 'CLM-103',
        submittedByUid: 'uid-student',
        studentDocId: 'STU-635',
        studentId: 'STU-635',
        studentName: 'MAHMUDUL HASSAN',
        adNo: '635',
        className: 'S4',
        mentorName: 'MOHAMED ABDU RAHIM HUDAWI',
        category: 'PUBLICATION',
        activityName: 'Essay & Article',
        coins: 10,
        submittedAt: '1/1/2026',
        status: 'APPROVED', // Shortcutting!
        reviewedBy: 'Self',
        auditDocId: 'AUD-CLM-103',
        facultyVisible: true,
        createdAt: '__SERVER_TIME__',
        updatedAt: '__SERVER_TIME__',
      },
      dbState: baseDb,
    }),
    'PERMISSION_DENIED',
    'Test 6 failed: Pre-approved claim creation allowed'
  );

  // 7. Terminal State Replay Mutation by Mentor
  assert.equal(
    simulateRuleCheck({
      collection: 'coin_claims',
      docId: 'CLM-104',
      op: 'update',
      auth: { uid: 'uid-mentor', email: 'shafi@dhac.edu.in', emailVerified: true },
      existing: { status: 'APPROVED', coins: 10 },
      incoming: { status: 'APPROVED', coins: 999 },
      dbState: {
        ...baseDb,
        users: { ...baseDb.users, 'uid-mentor': { uid: 'uid-mentor', role: 'TEACHER_ADMIN' } },
      },
    }),
    'PERMISSION_DENIED',
    'Test 7 failed: Terminal APPROVED claim mutated by non-admin mentor'
  );

  // 8. Student Direct Coin Balance Tampering
  assert.equal(
    simulateRuleCheck({
      collection: 'students',
      docId: 'STU-635',
      op: 'update',
      auth: { uid: 'uid-student', email: 's@gmail.com', emailVerified: true },
      incoming: { totalCoins: 5000 },
      dbState: baseDb,
    }),
    'PERMISSION_DENIED',
    'Test 8 failed: Student mutated own coin balance'
  );

  // 9. Orphaned Transaction Injection
  assert.equal(
    simulateRuleCheck({
      collection: 'coin_transactions',
      docId: 'TX-999',
      op: 'create',
      auth: { uid: 'uid-super', email: BOOTSTRAP_ADMIN_EMAIL, emailVerified: true },
      incoming: { targetType: 'STUDENT', studentDocId: 'STU-DOES-NOT-EXIST', coins: 50 },
      dbState: baseDb,
    }),
    'PERMISSION_DENIED',
    'Test 9 failed: Orphaned transaction accepted'
  );

  // 10. Cross-User PII Snooping
  assert.equal(
    simulateRuleCheck({
      collection: 'users_private',
      docId: 'uid-victim__info',
      op: 'get',
      auth: { uid: 'uid-attacker', email: 'a@gmail.com', emailVerified: true },
      dbState: baseDb,
    }),
    'PERMISSION_DENIED',
    'Test 10 failed: Cross-user PII read allowed'
  );

  // 11. Path Variable & 1.5KB Payload Poisoning
  assert.equal(
    simulateRuleCheck({
      collection: 'students',
      docId: 'A'.repeat(200) + '../$bad',
      op: 'create',
      auth: { uid: 'uid-super', email: BOOTSTRAP_ADMIN_EMAIL, emailVerified: true },
      incoming: { notes: 'X'.repeat(2000) },
      dbState: baseDb,
    }),
    'PERMISSION_DENIED',
    'Test 11 failed: Poisoned ID or oversized payload allowed'
  );

  // 12. Temporal Forgery (Client Clock Backdating)
  assert.equal(
    simulateRuleCheck({
      collection: 'coin_claims',
      docId: 'CLM-105',
      op: 'create',
      auth: { uid: 'uid-student', email: 's@gmail.com', emailVerified: true },
      incoming: {
        id: 'CLM-105',
        submittedByUid: 'uid-student',
        studentDocId: 'STU-635',
        studentId: 'STU-635',
        studentName: 'MAHMUDUL HASSAN',
        adNo: '635',
        className: 'S4',
        mentorName: 'MOHAMED ABDU RAHIM HUDAWI',
        category: 'PUBLICATION',
        activityName: 'Essay & Article',
        coins: 10,
        submittedAt: '1/1/2026',
        status: 'PENDING',
        auditDocId: 'AUD-CLM-105',
        facultyVisible: true,
        createdAt: '2020-01-01T00:00:00Z',
        updatedAt: '2020-01-01T00:00:00Z',
      },
      dbState: baseDb,
    }),
    'PERMISSION_DENIED',
    'Test 12 failed: Client-provided timestamp backdating allowed'
  );

  console.log('ALL 12 DIRTY DOZEN ADVERSARIAL TESTS RETURNED PERMISSION_DENIED.');
}

runDirtyDozenSuite();
