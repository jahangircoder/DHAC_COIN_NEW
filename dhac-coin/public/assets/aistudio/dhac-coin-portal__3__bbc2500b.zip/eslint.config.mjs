import firebaseRulesPlugin from '@firebase/eslint-plugin-security-rules';

export default [
  {
    ignores: [
      'dist/**/*',
      'node_modules/**/*',
      'supabase/**/*',
      'scripts/**/*',
      'data/**/*',
      'public/**/*',
      'src/**/*',
      'server.ts',
      'vite.config.ts',
      'firestore.rules.test.ts',
      'eslint.config.mjs',
    ],
  },
  firebaseRulesPlugin.configs['flat/recommended'],
];
