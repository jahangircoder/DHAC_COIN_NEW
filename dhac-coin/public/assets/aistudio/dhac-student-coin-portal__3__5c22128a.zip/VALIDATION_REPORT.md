# Data Quality & Validation Report — DHAC Student Coin Registry

**Registry Title**: `DHAC STUDENTS COIN PORTAL - SIDRA`  
**Dataset Reference**: `DHAC_Student_Coin_Report_ALL_CLEANED_290.csv`  
**Audit Date**: October 2026  
**Status**: All Automated Invariants Passed (10/10 PASS)  

---

## 1. Automated Assertion & Integrity Matrix

| Assertion ID | Verification Domain | Test Specification | Target Expected | Actual Result | Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `VAL-01` | **Total Population** | Total record rows excluding header | 290 | 290 | **PASS** |
| `VAL-02` | **S1A Batch Integrity** | Count of students in class `S1A` | 36 | 36 | **PASS** |
| `VAL-03` | **S1B Batch Integrity** | Count of students in class `S1B` | 38 | 38 | **PASS** |
| `VAL-04` | **Key Uniqueness** | Cardinality of canonical `Student_ID` | 290 distinct | 290 distinct | **PASS** |
| `VAL-05` | **AD No Validation** | Base `AD No` cardinality & missing flags | 290 distinct | 290 distinct (incl. 2 TMP IDs) | **PASS** |
| `VAL-06` | **Mandatory Fields** | Non-null check on `Class` and `Mentor Name` | 0 nulls | 0 nulls | **PASS** |
| `VAL-07` | **Mentor Denominators** | `Mentor_Group_Size` equals count of mentees | 100% match | 100% match across 20 groups | **PASS** |
| `VAL-08` | **Class Denominators** | `Class_Size` equals count of classmates | 100% match | 100% match across 12 classes | **PASS** |
| `VAL-09` | **Campus Denominator** | `Campus_Total_Students` equals 290 | 290 | 290 across all rows | **PASS** |
| `VAL-10` | **Ranking Monotonicity** | Competition rank order descending by coins | 0 violations | 0 violations | **PASS** |

---

## 2. Cohort Distribution Verification

### A. Academic Class Breakdown (12 Classes)
| Class Code | Category | Expected Count | Verified Count | Active Earners | Zero/Assumed Coins |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `D1` | Degree | 15 | 15 | 8 | 7 |
| `D2` | Degree | 14 | 14 | 8 | 6 |
| `HS1` | Higher Secondary | 16 | 16 | 8 | 8 |
| `HS2` | Higher Secondary | 10 | 10 | 5 | 5 |
| `S1A` | Secondary (New) | 36 | 36 | 0 | 36 (`ASSUMED_ZERO`) |
| `S1B` | Secondary (New) | 38 | 38 | 0 | 38 (`ASSUMED_ZERO`) |
| `S2A` | Secondary | 29 | 29 | 10 | 19 |
| `S2B` | Secondary | 28 | 28 | 8 | 20 |
| `S3A` | Secondary | 23 | 23 | 9 | 14 |
| `S3B` | Secondary | 21 | 21 | 5 | 16 |
| `S4` | Secondary | 33 | 33 | 14 | 19 |
| `S5` | Secondary | 27 | 27 | 15 | 12 |
| **Total** | — | **290** | **290** | **90** | **200** |

### B. Mentor Group Breakdown (20 Groups)
| Mentor Name | Role / Department | Group Size | Active Mentees | Total Group Coins | Group Average |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `AFTHAB HUDAWI` | Faculty Mentor | 9 | 5 | 180 | 20.0 |
| `FAISAL HUDAWI` | Faculty Mentor | 10 | 7 | 109 | 10.9 |
| `FAREED KHAN HUDAWI` | Faculty Mentor | 9 | 4 | 48 | 5.3 |
| `FARIDUL ISLAM HUDAWI` | Class Teacher (S1A) | 36 | 0 | 0 | 0.0 (Provisional) |
| `FIROZ BABU KT HUDAWI` | Faculty Mentor | 13 | 7 | 180 | 13.8 |
| `HALIMUZ ZAMAN HUDAWI` | Class Teacher (S1B) | 38 | 0 | 0 | 0.0 (Provisional) |
| `MD FARIDUL ISLAM HUDAWI`| Faculty Mentor | 13 | 5 | 120 | 9.2 |
| `MOHAMED ABDU RAHIM HUDAWI`| Faculty Mentor | 13 | 8 | 245 | 18.8 |
| `MOHAMED SHIBIL HUDAWI` | Faculty Mentor | 13 | 5 | 90 | 6.9 |
| `MOHAMMED MURSHID A HUDAWI`| Faculty Mentor | 14 | 8 | 138 | 9.9 |
| `MOHIYUDHEEN HUDAWI` | Faculty Mentor | 13 | 7 | 270 | 20.8 |
| `MUHAMMED HASSAN HUDAWI`| Faculty Mentor | 13 | 6 | 135 | 10.4 |
| `NASIM AKHTHAR HUDAWI` | Faculty Mentor | 14 | 7 | 195 | 13.9 |
| `RUHUL AMIN HUDAWI` | Faculty Mentor | 14 | 7 | 120 | 8.6 |
| `SHAFI MM HUDAWI` | Faculty Mentor | 9 | 5 | 105 | 11.7 |
| `SHAIKH ALI HUDAWI` | Faculty Mentor | 14 | 6 | 120 | 8.6 |
| `SHARAFATH MS HUDAWI` | Faculty Mentor | 14 | 6 | 105 | 7.5 |
| `SHUAIB A HUDAWI` | Faculty Mentor | 13 | 7 | 180 | 13.8 |
| `SUHAIL HUDAWI` | Faculty Mentor | 9 | 5 | 165 | 18.3 |
| `THAMEEM HUDAWI` | Faculty Mentor | 9 | 5 | 120 | 13.3 |

---

## 3. Flagged Review Anomalies & Governance Recommendations

### Anomaly 1: Dual Enrollment Check for RASHIDUL ALI
- **Records Involved**:
  - `STU-906`: `RASHIDUL ALI` (Class: `S1A`, AD: `906`, Mentor: `FARIDUL ISLAM HUDAWI`)
  - `STU-877`: `RASHIDUL ALI` (Class: `S1B`, AD: `877`, Mentor: `HALIMUZ ZAMAN HUDAWI`)
- **Assessment**: Both entries have distinct admission numbers and belong to different class sections.
- **Audit Decision**: Maintained as two separate individual student records per prompt specification. Both have `Coin_Status = ASSUMED_ZERO`.

### Anomaly 2: Similar Name Review for ASMAUL HAQUE vs ASMAUL HOQUE
- **Records Involved**:
  - `STU-925`: `ASMAUL HAQUE` (Class: `S1B`, AD: `925`, Mentor: `HALIMUZ ZAMAN HUDAWI`)
  - `STU-805`: `ASMAUL HOQUE` (Class: `S2A`, AD: `805`, Mentor: `MOHAMED ABDU RAHIM HUDAWI`)
- **Assessment**: S2A student (AD 805) was admitted in an earlier academic year; S1B student (AD 925) is a newly admitted first-year secondary student.
- **Audit Decision**: Kept distinct. Flagged as independent student records with different class years and admission numbers.

### Anomaly 3: Mentor Nomenclature Check (`MD FARIDUL ISLAM HUDAWI` vs `FARIDUL ISLAM HUDAWI`)
- **Records Involved**:
  - `MD FARIDUL ISLAM HUDAWI`: Mentors 13 cross-batch students across classes S2A–S5.
  - `FARIDUL ISLAM HUDAWI`: Class teacher / mentor for all 36 students in Class S1A.
- **Assessment**: If merged, group size would become 49, violating existing historical mentor group benchmarks.
- **Audit Decision**: Kept as two separate mentor groupings with exact matching group denominators (13 and 36). Administration should confirm whether the prefix "MD" reflects the same individual in multiple roles.

### Anomaly 4: Homonym Verification for ABDUR RAHMAN
- **Records Involved**:
  - `STU-677`: `ABDUR RAHMAN` (Class: `S3B`, AD: `677`, Coins: 0)
  - `STU-831`: `ABDUR RAHMAN` (Class: `S2A`, AD: `831`, Coins: 30)
  - `STU-926`: `ABDUR RAHMAN` (Class: `S1A`, AD: `926`, Coins: 0)
- **Audit Decision**: Validated as distinct students across different academic cohorts with separate admission numbers.
