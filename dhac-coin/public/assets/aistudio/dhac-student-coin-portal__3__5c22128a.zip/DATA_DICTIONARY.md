# Data Dictionary & Codebook — DHAC Student Coin Registry

**Registry Standard**: DHAC Student Merit & Coin Accounting Specification (v2.0)  
**File**: `DHAC_Student_Coin_Report_ALL_CLEANED_290.csv`  
**Population**: 290 Student Records across 12 Academic Batches  

---

## 1. Field Specifications

| Column Name | Data Type | Nullable? | Format / Pattern | Allowed Values / Domain | Description & Business Rules |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `Student_ID` | String (Alpha-Numeric) | NO | `^STU-[A-Za-z0-9\-]+$` | Unique identifier | Canonical persistent system ID. For standard AD numbers: `STU-<AD>`. For missing AD rows: `STU-TMP-<row>`. Guaranteed unique. |
| `AD No` | String (Numeric or TMP) | NO | `^[0-9]+$` or `^TMP-[0-9]+$` | Valid AD or `TMP-<row>` | Base Admission Number assigned by campus registrar. Stripped of historical markers such as `*`. |
| `AD_Flag` | Enum String | NO | UPPERCASE_SNAKE | `VALID`, `ORIGINAL_ASTERISK`, `MISSING_AD` | Indicates data quality status of original admission number in source ledger. |
| `Student Name` | String (Text) | NO | UPPERCASE PROSE | Letters, spaces, dots, hyphens | Full official student name. Standardized against registrar records (e.g. MAHMUDUL HASSAN). |
| `Class` | Enum String | NO | Code | `D1`, `D2`, `HS1`, `HS2`, `S1A`, `S1B`, `S2A`, `S2B`, `S3A`, `S3B`, `S4`, `S5` | Academic class division. D = Degree, HS = Higher Secondary, S = Secondary. |
| `Mentor Name` | String | NO | Uppercase | 20 faculty Hudawi names | Assigned faculty mentor or class teacher responsible for student pastoral care and coin evaluation. |
| `Total Coins` | Integer | NO | `^[0-9]+$` | $\ge 0$ | Cumulative merit incentive coins awarded to the student. |
| `Coin_Status` | Enum String | NO | UPPERCASE_SNAKE | `CONFIRMED`, `MISSING_OR_ZERO`, `ASSUMED_ZERO` | `CONFIRMED`: Verified earn balance >0. `MISSING_OR_ZERO`: Baseline 0 coins. `ASSUMED_ZERO`: Provisional 0 for new cohorts. |
| `Mentor Group Rank` | Integer | NO | `^[0-9]+$` | $1 \le r \le \text{Mentor\_Group\_Size}$ | Competition rank of student within their assigned mentor group ordered by Total Coins descending. |
| `Mentor_Group_Size` | Integer | NO | `^[0-9]+$` | 9, 10, 13, 14, 36, or 38 | Denominator specifying the total number of mentees supervised by that mentor. |
| `Class Rank` | Integer | NO | `^[0-9]+$` | $1 \le r \le \text{Class\_Size}$ | Competition rank of student within their class division ordered by Total Coins descending. |
| `Class_Size` | Integer | NO | `^[0-9]+$` | 10 to 38 | Denominator specifying total enrolled students in that class. |
| `Campus Rank` | Integer | NO | `^[0-9]+$` | $1 \le r \le 290$ | Competition rank across the entire campus student body (124 for tied zero coins). |
| `Campus_Total_Students` | Integer | NO | Integer Constant | 290 | Denominator representing total campus registry count. |
| `Rank_Status` | Enum String | NO | Enum | `OFFICIAL`, `PROVISIONAL` | `OFFICIAL`: Based on confirmed non-zero coins. `PROVISIONAL`: Based on assumed or unconfirmed zero coins. |
| `Notes` | String | YES | Text | Descriptive audit notes | Audit remarks recording historical corrections, name standardization, or temporary ID assignments. |

---

## 2. Classification Taxonomies

### A. Academic Class Taxonomy
| Code | Academic Division | Description | Normal Duration |
| :--- | :--- | :--- | :--- |
| `D1` | Degree 1st Year | Undergraduate studies, Phase 1 | 1 Year |
| `D2` | Degree 2nd Year | Undergraduate studies, Phase 2 | 1 Year |
| `HS1`| Higher Secondary 1st Year | Pre-degree senior secondary | 1 Year |
| `HS2`| Higher Secondary 2nd Year | Pre-degree graduating class | 1 Year |
| `S1A`| Secondary 1st Year (Section A) | Foundational secondary class | 1 Year |
| `S1B`| Secondary 1st Year (Section B) | Foundational secondary class | 1 Year |
| `S2A`| Secondary 2nd Year (Section A) | Secondary division | 1 Year |
| `S2B`| Secondary 2nd Year (Section B) | Secondary division | 1 Year |
| `S3A`| Secondary 3rd Year (Section A) | Secondary intermediate | 1 Year |
| `S3B`| Secondary 3rd Year (Section B) | Secondary intermediate | 1 Year |
| `S4` | Secondary 4th Year | Senior secondary | 1 Year |
| `S5` | Secondary 5th Year | Final year secondary | 1 Year |

### B. Coin Tier Classifications
- **Diamond Tier ($\ge 60$ Coins)**: Top campus champions (Mahmudul Hassan 80c, Md Khairul Islam 75c, Meraimayum Mujakir Ali 60c).
- **Gold Tier ($30 - 59$ Coins)**: High achievers and runners-up.
- **Silver Tier ($15 - 29$ Coins)**: Active consistent contributors.
- **Bronze Tier ($1 - 14$ Coins)**: Emerging coin earners.
- **Zero Coins ($0$ Coins)**: Students without awarded coins (sub-divided into `MISSING_OR_ZERO` and `ASSUMED_ZERO`).
