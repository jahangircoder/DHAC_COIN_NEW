# Changelog — DHAC Student Coin Report & Portal (SIDRA)

**File Reference**: `DHAC_Student_Coin_Report_ALL_CLEANED_290.csv`  
**Initial Baseline**: 216 records (`DHAC_Student_Coin_Report_ALL_9a0ebbdd.csv`)  
**New Total**: 290 records  
**Date**: October 2026  
**Auditor**: Data Quality & Reporting Engineering Team  

---

## 1. Summary of Changes
- **Record Expansion**: Appended 74 new students: 36 in Class S1A and 38 in Class S1B. Total cohort is now exactly 290 students.
- **Canonical Student Identifiers**: Created unique `Student_ID` field (`STU-<AD_No>` / `STU-TMP-<row_number>`). Zero duplicate IDs across the entire 290-student registry.
- **Asterisk Handling (`AD_Flag`)**: Stripped asterisks (`*`) from 10 student records into a dedicated `AD_Flag = "ORIGINAL_ASTERISK"` field while preserving the base numerical admission numbers.
- **Missing AD Recovery (`MISSING_AD`)**: Replaced placeholder `"-"` values on 2 student rows with temporary canonical IDs (`TMP-104` and `TMP-110`) and flagged with `AD_Flag = "MISSING_AD"`.
- **Targeted Spelling Correction**: Corrected `MAHMUDUL HASAN` (AD 635) to `MAHMUDUL HASSAN` as officially requested, while preserving all other baseline records.
- **Explicit Coin Status & Assumptions**:
  - Confirmed earners (>0 coins) marked as `Coin_Status = "CONFIRMED"` and `Rank_Status = "OFFICIAL"`.
  - Baseline zero coins marked as `Coin_Status = "MISSING_OR_ZERO"` and `Rank_Status = "PROVISIONAL"`.
  - New S1A & S1B students assigned `Total Coins = 0` with `Coin_Status = "ASSUMED_ZERO"` and `Rank_Status = "PROVISIONAL"` (no fabricated scores).
- **Competition Ranking Implementation**: Replaced unstandardized text ranks (`#3/9`, `#2`) with standardized integer competition ranks (1, 2, 2, 4) with explicit separate denominators (`Mentor_Group_Size`, `Class_Size`, `Campus_Total_Students`).
- **Mentor Group Calibration**: Configured S1A class mentor `FARIDUL ISLAM HUDAWI` (group size 36) and S1B class mentor `HALIMUZ ZAMAN HUDAWI` (group size 38), preserving cross-batch mentor `MD FARIDUL ISLAM HUDAWI` (group size 13).

---

## 2. Granular Record-by-Record Corrections

### A. Name Corrections
| Student_ID | AD No | Old Name | Corrected Name | Reason |
| :--- | :--- | :--- | :--- | :--- |
| `STU-635` | 635 | `MAHMUDUL HASAN` | `MAHMUDUL HASSAN` | Correction per institutional request for Campus Champion (Row 106 in baseline). |

### B. Asterisk Stripping (`AD_Flag = ORIGINAL_ASTERISK`)
| Student_ID | Base AD No | Original String | Student Name | Class | Mentor |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `STU-272` | 272 | `272*` | RASIDUL ISLAM | D1 | SHAFI MM HUDAWI |
| `STU-436` | 436 | `436*` | MASUD AHMED | HS1 | FAREED KHAN HUDAWI |
| `STU-229` | 229 | `229*` | MD ABDUL KAYUM | D1 | THAMEEM HUDAWI |
| `STU-704` | 704 | `704*` | ROMJAN ALI SHEIKH | S3A | SHAIKH ALI HUDAWI |
| `STU-693` | 693 | `693*` | SAKIB AHAMAD PH | S3A | MOHAMED SHIBIL HUDAWI |
| `STU-760` | 760 | `760*` | MAHMUD JAMAN | S3B | SHUAIB A HUDAWI |
| `STU-585` | 585 | `585*` | JUBAIR BIN AHMED | S5 | SHUAIB A HUDAWI |
| `STU-744` | 744 | `744*` | MIRAZUL SK | S2A | RUHUL AMIN HUDAWI |
| `STU-674` | 674 | `674*` | SAMSUDDIN AHMED | S3B | RUHUL AMIN HUDAWI |
| `STU-673` | 673 | `673*` | MUSTAFIZUR | S3A | MOHAMMED MURSHID A HUDAWI |

### C. Missing Admission Number Remediations (`AD_Flag = MISSING_AD`)
| Student_ID | Temporary AD No | Original Value | Student Name | Class | Mentor | Total Coins | Notes |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `STU-TMP-104` | `TMP-104` | `"-"` | MD ELMAS | S3B | MOHAMED ABDU RAHIM HUDAWI | 15 | Row 104 in source CSV; canonical temporary ID generated. |
| `STU-TMP-110` | `TMP-110` | `"-"` | JUBAIR AHMED | S2A | NASIM AKHTHAR HUDAWI | 30 | Row 110 in source CSV; canonical temporary ID generated. |

### D. New Cohort Additions: Class S1A (36 Students)
- **Class**: `S1A`
- **Class Teacher & Mentor**: `FARIDUL ISLAM HUDAWI`
- **Class Size / Group Size**: `36`
- **Coins Assigned**: `0` (`Coin_Status = ASSUMED_ZERO`, `Rank_Status = PROVISIONAL`)
- **Assigned Ranks**: Class Rank = `1` (tied 36 ways), Mentor Rank = `1` (tied 36 ways), Campus Rank = `124` (tied across 167 zero-coin students).
- **Roster**:
  1. `STU-786`: MD SHARUKH KHAN
  2. `STU-852`: SOHEL TANBIR ISLAM
  3. `STU-856`: MOHAMAD FAJAKIR
  4. `STU-858`: RIJWAN MARGUB
  5. `STU-860`: SABBIR AHMED
  6. `STU-862`: SULTAN MAMUD
  7. `STU-866`: JUBAIR ALKABIR
  8. `STU-870`: SK. ABDUR RAHMAN
  9. `STU-872`: MD REYAN RAHMAN
  10. `STU-874`: ATIKUR ROHMAN
  11. `STU-876`: OSMAN GONI
  12. `STU-878`: BABUL HAQUE
  13. `STU-880`: SHORIFUL ISLAM
  14. `STU-882`: ABDULLAH AL MASUD
  15. `STU-884`: MOSTAFIZUR MOLLAH
  16. `STU-886`: IZAZ IBRAHIM
  17. `STU-888`: MD MUKHTAR
  18. `STU-890`: HAZRAT ABU BAKKAR SIDDIK
  19. `STU-892`: AKHIRUL ISLAM
  20. `STU-894`: FIRDOUS ALOM
  21. `STU-896`: MAKSUD
  22. `STU-900`: NURTAZUR RAHMAN
  23. `STU-902`: KHUTLEIFAM MOHD ANASH
  24. `STU-904`: RABIUL HOQUE
  25. `STU-906`: RASHIDUL ALI
  26. `STU-910`: UBAIDULLA BIN SADEQUE
  27. `STU-912`: SHAHIBUL ALI
  28. `STU-914`: MAHAMMAD ZAKARIA
  29. `STU-916`: REJAUL KHAN
  30. `STU-918`: RAZZAKUL ALOM
  31. `STU-920`: ANAS MONDAL
  32. `STU-922`: RIHAN RAHMAN
  33. `STU-924`: SHEKH ABDUR RAHMAN
  34. `STU-926`: ABDUR RAHMAN
  35. `STU-928`: JULFIKAR ALI
  36. `STU-929`: ASHISH IKRAM

### E. New Cohort Additions: Class S1B (38 Students)
- **Class**: `S1B`
- **Class Teacher & Mentor**: `HALIMUZ ZAMAN HUDAWI`
- **Class Size / Group Size**: `38`
- **Coins Assigned**: `0` (`Coin_Status = ASSUMED_ZERO`, `Rank_Status = PROVISIONAL`)
- **Assigned Ranks**: Class Rank = `1` (tied 38 ways), Mentor Rank = `1` (tied 38 ways), Campus Rank = `124` (tied across 167 zero-coin students).
- **Roster**:
  1. `STU-842`: HABIB IFTIKAR AHMED
  2. `STU-836`: ABDUL WAHID
  3. `STU-853`: AL SABIL MASUD HASAN
  4. `STU-855`: MASHRUFE MURTAZA
  5. `STU-857`: ASHIQUE ABDULLA
  6. `STU-859`: RAJIBUL ISLAM
  7. `STU-861`: EYANUR MULLA
  8. `STU-863`: JUNAID HAQUE
  9. `STU-865`: JUBAIR KHAN
  10. `STU-867`: SAJID AKHTAR MULLAH
  11. `STU-869`: MISQUAT
  12. `STU-871`: RAJDEEP AFCHI
  13. `STU-873`: RIYAZ AHMED
  14. `STU-875`: ISHFAQUR RAHMAN
  15. `STU-877`: RASHIDUL ALI
  16. `STU-879`: SHEIK FARID
  17. `STU-881`: RASIDUL HAQUE
  18. `STU-883`: SINGAMAYUM SAFUWAN
  19. `STU-885`: MAKIBUL ISLAM
  20. `STU-887`: JADID AKHTAR
  21. `STU-889`: RIHANUL HAQUE
  22. `STU-891`: FARIDUL ALI
  23. `STU-893`: HABIB MAHSIN HOQUE
  24. `STU-895`: MAHMUD MADANI
  25. `STU-897`: JABIR ALI
  26. `STU-899`: SHAKIBUL HASAN
  27. `STU-901`: MARUF AHMED
  28. `STU-903`: SAMIM ALI SK
  29. `STU-905`: MD. ASADUZ ZAMAN
  30. `STU-907`: HABIBUR DEWAN
  31. `STU-909`: FARHAN HUSSAIN
  32. `STU-911`: AMIMOON RABUL AKANDA
  33. `STU-917`: SHEIKH RUHUL AMIN
  34. `STU-919`: MEHEBUB ANSARI
  35. `STU-921`: MOHAMMAD NURUL HARISH
  36. `STU-923`: MD WAHID ALAM
  37. `STU-925`: ASMAUL HAQUE
  38. `STU-927`: FAIZUR RAHMAN

---

## 3. Tie Rule Definition & Specification
**Standard Competition Ranking ("1224" Rule)**:
1. Students are ordered descending by `Total Coins`.
2. The student with the highest score receives rank `1`.
3. If $k$ students have identical coin balances, they all share the same rank.
4. The rank awarded to the next student with fewer coins is strictly equal to:
   $$\text{Next Rank} = \text{Current Rank} + k$$
5. Example in Campus Standings:
   - 80 Coins: 1 student $\rightarrow$ Rank 1
   - 75 Coins: 1 student $\rightarrow$ Rank 2
   - 60 Coins: 1 student $\rightarrow$ Rank 3
   - 45 Coins: 10 students $\rightarrow$ Rank 4 (tied)
   - 30 Coins: 21 students $\rightarrow$ Rank 14 (skips 10 positions: $4 + 10 = 14$)
   - 15 Coins: 85 students $\rightarrow$ Rank 35 (skips 21 positions: $14 + 21 = 35$)
   - 5 Coins: 1 student $\rightarrow$ Rank 120 (skips 85 positions: $35 + 85 = 120$)
   - 4 Coins: 1 student $\rightarrow$ Rank 121
   - 3 Coins: 2 students $\rightarrow$ Rank 122
   - 0 Coins: 167 students $\rightarrow$ Rank 124 (skips 2 positions: $122 + 2 = 124$).
