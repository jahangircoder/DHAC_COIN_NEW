import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const DB_FILE = path.join(__dirname, 'data', 'database.json');

if (!fs.existsSync(path.join(__dirname, 'data'))) {
  fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
}

app.use(express.json({ limit: '10mb' }));

interface DatabaseSchema {
  students: any[];
  claims: any[];
  transactions: any[];
  classAwards: Record<string, number>;
  credentials: Record<string, string>; 
  teachers: any[];
}

function readDB(): DatabaseSchema {
  if (fs.existsSync(DB_FILE)) {
    try {
      const data = fs.readFileSync(DB_FILE, 'utf8');
      const parsed = JSON.parse(data);
      if (parsed && typeof parsed === 'object') {
        parsed.students = Array.isArray(parsed.students) ? parsed.students : [];
        parsed.claims = Array.isArray(parsed.claims) ? parsed.claims : [];
        parsed.transactions = Array.isArray(parsed.transactions) ? parsed.transactions : [];
        parsed.classAwards = parsed.classAwards || {};
        parsed.credentials = parsed.credentials || {};
        parsed.teachers = parsed.teachers || [];
        return parsed;
      }
    } catch (err) {
      console.error('[DATABASE LOCK ARREST] Internal data safety buffer deployed:', err);
    }
  }
  return { students: [], claims: [], transactions: [], classAwards: {}, credentials: {}, teachers: [] };
}

function writeDB(data: DatabaseSchema): void {
  const tmpFile = `${DB_FILE}.tmp.${Date.now()}.${Math.floor(Math.random() * 10000)}`;
  try {
    fs.writeFileSync(tmpFile, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tmpFile, DB_FILE);
  } catch (err) {
    console.error('[CRITICAL WRITE ABORT] Resolving thread race lock issue:', err);
    if (fs.existsSync(tmpFile)) {
      try { fs.unlinkSync(tmpFile); } catch {}
    }
  }
}

function deterministicHash(input: string): string {
  let hash = 0;
  const saltedPayload = `salt_dhac_secure_system_v3_institutional_layer_${input}`;
  for (let i = 0; i < saltedPayload.length; i++) {
    hash = (hash << 5) - hash + saltedPayload.charCodeAt(i);
    hash |= 0;
  }
  return `HEX_SECURE_HASH_${Math.abs(hash).toString(16)}`;
}

function recalculateRanksServer(records: any[]) {
  if (!Array.isArray(records) || records.length === 0) return;

  records.sort((a, b) => (b.totalCoins || 0) - (a.totalCoins || 0));
  let currentCampusRank = 1;
  for (let i = 0; i < records.length; i++) {
    if (i > 0 && (records[i].totalCoins || 0) < (records[i - 1].totalCoins || 0)) {
      currentCampusRank = i + 1;
    }
    records[i].campusRankNum = currentCampusRank;
    records[i].campusRank = `#${currentCampusRank}`;
    records[i].campusTotalStudents = records.length;
    
    const score = records[i].totalCoins || 0;
    if (score >= 60) records[i].tier = 'Diamond';
    else if (score >= 30) records[i].tier = 'Gold';
    else if (score >= 15) records[i].tier = 'Silver';
    else if (score > 0) records[i].tier = 'Bronze';
    else records[i].tier = 'Zero';
  }

  const classGroups = new Map<string, any[]>();
  records.forEach(s => {
    if (!classGroups.has(s.className)) classGroups.set(s.className, []);
    classGroups.get(s.className)!.push(s);
  });
  for (const [, classList] of classGroups.entries()) {
    classList.sort((a, b) => (b.totalCoins || 0) - (a.totalCoins || 0));
    let currentClassRank = 1;
    for (let i = 0; i < classList.length; i++) {
      if (i > 0 && (classList[i].totalCoins || 0) < (classList[i - 1].totalCoins || 0)) {
        currentClassRank = i + 1;
      }
      classList[i].classRankNum = currentClassRank;
      classList[i].classRank = `#${currentClassRank}`;
      classList[i].classSize = classList.length;
    }
  }

  const mentorGroups = new Map<string, any[]>();
  records.forEach(s => {
    if (!mentorGroups.has(s.mentorName)) mentorGroups.set(s.mentorName, []);
    mentorGroups.get(s.mentorName)!.push(s);
  });
  for (const [, mentorList] of mentorGroups.entries()) {
    mentorList.sort((a, b) => (b.totalCoins || 0) - (a.totalCoins || 0));
    let currentMentorRank = 1;
    for (let i = 0; i < mentorList.length; i++) {
      if (i > 0 && (mentorList[i].totalCoins || 0) < (mentorList[i - 1].totalCoins || 0)) {
        currentMentorRank = i + 1;
      }
      mentorList[i].mentorRankNum = currentMentorRank;
      mentorList[i].mentorGroupSize = mentorList.length;
      mentorList[i].mentorGroupRank = `#${currentMentorRank}/${mentorList.length}`;
    }
  }
}

app.get('/api/students', (req, res) => {
  res.json({ students: readDB().students });
});

app.post('/api/students/bulk', (req, res) => {
  const { students } = req.body;
  if (!Array.isArray(students)) return res.status(400).json({ error: 'Malformed dataset' });
  const db = readDB();
  db.students = students;
  recalculateRanksServer(db.students);
  writeDB(db);
  res.json({ success: true, count: db.students.length });
});

app.post('/api/students', (req, res) => {
  const newStudent = req.body;
  if (!newStudent || !newStudent.adNo) return res.status(400).json({ error: 'Incomplete student profile configuration' });
  
  const db = readDB();
  db.students = [newStudent, ...(db.students || [])];
  recalculateRanksServer(db.students);
  writeDB(db);
  res.json({ success: true, student: newStudent, students: db.students });
});

app.put('/api/students/:id', (req, res) => {
  const { id } = req.params;
  const updatePayload = req.body;
  const db = readDB();
  const idx = db.students.findIndex(s => s.id === id || s.studentId === id);
  if (idx === -1) return res.status(404).json({ error: 'Target profile missing' });

  db.students[idx] = { ...db.students[idx], ...updatePayload };
  recalculateRanksServer(db.students);
  writeDB(db);
  res.json({ success: true, student: db.students[idx], students: db.students });
});

app.delete('/api/students/:id', (req, res) => {
  const { id } = req.params;
  const db = readDB();
  db.students = db.students.filter(s => s.id !== id && s.studentId !== id);
  recalculateRanksServer(db.students);
  writeDB(db);
  res.json({ success: true, students: db.students });
});

app.post('/api/students/:id/photo', (req, res) => {
  const { id } = req.params;
  const { photoUrl } = req.body;
  const db = readDB();
  const student = db.students.find(s => s.id === id || s.studentId === id);
  if (!student) return res.status(404).json({ error: 'Profile tracking node missing' });
  
  student.photoUrl = photoUrl;
  writeDB(db);
  res.json({ success: true, photoUrl });
});

app.get('/api/claims', (req, res) => { res.json({ claims: readDB().claims || [] }); });

app.post('/api/claims', (req, res) => {
  const claimData = req.body;
  if (!claimData.studentId || !claimData.coins) return res.status(400).json({ error: 'Invalid verification token data' });
  
  const db = readDB();
  const newClaim = {
    ...claimData,
    id: `CLM-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    submittedAt: new Date().toLocaleString('en-US', { dateStyle: 'short', timeStyle: 'medium' }),
    status: 'PENDING',
  };
  db.claims = [newClaim, ...(db.claims || [])];
  writeDB(db);
  res.json({ success: true, claim: newClaim });
});

app.post('/api/claims/:id/approve', (req, res) => {
  const { id } = req.params;
  const { reviewerName } = req.body;
  const db = readDB();
  const claim = db.claims.find(c => c.id === id);
  if (!claim) return res.status(404).json({ error: 'Claim entry missing' });
  
  claim.status = 'APPROVED';
  claim.reviewedBy = reviewerName || 'Faculty Mentor';
  claim.reviewedAt = new Date().toLocaleString('en-US', { dateStyle: 'short', timeStyle: 'medium' });

  const student = db.students.find(s => s.id === claim.studentId || s.studentId === claim.studentId);
  if (student) {
    student.totalCoins = (student.totalCoins || 0) + claim.coins;
    student.coinStatus = 'CONFIRMED';
    student.rankStatus = 'OFFICIAL';
  }
  recalculateRanksServer(db.students);

  const newTx = {
    id: `TX-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: claim.reviewedAt,
    targetType: 'STUDENT',
    studentId: claim.studentId,
    studentName: claim.studentName,
    adNo: claim.adNo,
    className: claim.className,
    category: claim.category,
    activityName: claim.activityName,
    coins: claim.coins,
    awardedBy: `Confirmed by Mentor: ${reviewerName}`,
    notes: claim.proofNotes,
  };
  db.transactions = [newTx, ...(db.transactions || [])];
  writeDB(db);
  res.json({ success: true, claim, student, students: db.students });
});

app.post('/api/claims/:id/reject', (req, res) => {
  const { id } = req.params;
  const { reviewerName, reason } = req.body;
  const db = readDB();
  const claim = db.claims.find(c => c.id === id);
  if (!claim) return res.status(404).json({ error: 'Claim identity trace missing' });
  
  claim.status = 'REJECTED';
  claim.reviewedBy = reviewerName || 'Faculty Mentor';
  claim.reviewedAt = new Date().toLocaleString('en-US', { dateStyle: 'short', timeStyle: 'medium' });
  if (reason) claim.rejectionReason = reason;
  
  writeDB(db);
  res.json({ success: true, claim });
});

app.get('/api/transactions', (req, res) => { res.json({ transactions: readDB().transactions || [] }); });

app.delete('/api/transactions/:id', (req, res) => {
  const { id } = req.params;
  const db = readDB();
  const txIndex = db.transactions.findIndex(t => t.id === id);
  if (txIndex === -1) return res.status(404).json({ error: 'Ledger token transaction missing' });
  
  const tx = db.transactions[txIndex];
  if (tx.targetType === 'STUDENT') {
    const student = db.students.find(s => s.id === tx.studentId || s.studentId === tx.studentId);
    if (student) {
