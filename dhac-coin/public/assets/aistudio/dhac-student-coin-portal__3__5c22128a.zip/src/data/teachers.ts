import { TeacherRecord } from '../types/student';

export const TEACHERS_ROSTER: TeacherRecord[] = [
  { serialNo: '01', teacherId: 'DHAC/STAFF/01', name: 'SHAFI MM HUDAWI', username: 'STAFF.SHAFI', password: '@dhac_01' },
  { serialNo: '02', teacherId: 'DHAC/STAFF/02', name: 'SUHAIL HUDAWI', username: 'STAFF.SUHAIL', password: '@dhac_02' },
  { serialNo: '03', teacherId: 'DHAC/STAFF/03', name: 'FAREED KHAN HUDAWI', username: 'STAFF.FAREED', password: '@dhac_03' },
  { serialNo: '04', teacherId: 'DHAC/STAFF/04', name: 'THAMEEM HUDAWI', username: 'STAFF.THAMEEM', password: '@dhac_04' },
  { serialNo: '05', teacherId: 'DHAC/STAFF/05', name: 'FAISAL HUDAWI', username: 'STAFF.FAISAL', password: '@dhac_05' },
  { serialNo: '06', teacherId: 'DHAC/STAFF/06', name: 'AFTHAB HUDAWI', username: 'STAFF.AFTHAB', password: '@dhac_06' },
  { serialNo: '07', teacherId: 'DHAC/STAFF/07', name: 'SHAIKH ALI HUDAWI', username: 'STAFF.SHAIKH', password: '@dhac_07' },
  { serialNo: '08', teacherId: 'DHAC/STAFF/08', name: 'MOHIYUDHEEN HUDAWI', username: 'STAFF.MOHIYUDHEEN', password: '@dhac_08' },
  { serialNo: '09', teacherId: 'DHAC/STAFF/09', name: 'FIROZ BABU KT HUDAWI', username: 'STAFF.FIROZ', password: '@dhac_09' },
  { serialNo: '10', teacherId: 'DHAC/STAFF/10', name: 'MOHAMED ABDU RAHIM HUDAWI', username: 'STAFF.MOHAMED', password: '@dhac_10' },
  { serialNo: '11', teacherId: 'DHAC/STAFF/11', name: 'NASIM AKHTHAR HUDAWI', username: 'STAFF.NASIM', password: '@dhac_11' },
  { serialNo: '12', teacherId: 'DHAC/STAFF/12', name: 'MUHAMMED HASSAN HUDAWI', username: 'STAFF.MUHAMMED', password: '@dhac_12' },
  { serialNo: '13', teacherId: 'DHAC/STAFF/13', name: 'MOHAMED SHIBIL HUDAWI', username: 'STAFF.SHIBIL', password: '@dhac_13' },
  { serialNo: '14', teacherId: 'DHAC/STAFF/14', name: 'SHUAIB A HUDAWI', username: 'STAFF.SHUAIB', password: '@dhac_14' },
  { serialNo: '15', teacherId: 'DHAC/STAFF/15', name: 'RUHUL AMIN HUDAWI', username: 'STAFF.RUHUL', password: '@dhac_15' },
  { serialNo: '16', teacherId: 'DHAC/STAFF/16', name: 'MD FARIDUL ISLAM HUDAWI', username: 'STAFF.FARIDUL', password: '@dhac_16' },
  { serialNo: '17', teacherId: 'DHAC/STAFF/17', name: 'MOHAMMED MURSHID A HUDAWI', username: 'STAFF.MURSHID', password: '@dhac_17' },
  { serialNo: '18', teacherId: 'DHAC/STAFF/18', name: 'SHARAFATH MS HUDAWI', username: 'STAFF.SHARAFATH', password: '@dhac_18' },
  { serialNo: '19', teacherId: 'DHAC/STAFF/19', name: 'FARIDUL ISLAM HUDAWI', username: 'STAFF.FARIDUL_S1A', password: '@dhac_19' },
  { serialNo: '20', teacherId: 'DHAC/STAFF/20', name: 'HALIMUZ ZAMAN HUDAWI', username: 'STAFF.HALIMUZ', password: '@dhac_20' },
];

export function findTeacherByMentorName(mentorName: string): TeacherRecord | undefined {
  return TEACHERS_ROSTER.find(t => t.name === mentorName);
}

export function findTeacherByCredentials(username: string, pass: string): TeacherRecord | undefined {
  const normUser = username.trim().toUpperCase();
  return TEACHERS_ROSTER.find(
    t => t.username.toUpperCase() === normUser && t.password === pass.trim()
  );
}
