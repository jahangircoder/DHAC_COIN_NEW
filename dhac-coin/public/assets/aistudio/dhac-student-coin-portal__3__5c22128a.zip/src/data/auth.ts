import { AuthUser, StudentRecord, TeacherRecord } from '../types/student';
import { TEACHERS_ROSTER, findTeacherByCredentials } from './teachers';

export const SUPER_ADMIN_CREDENTIAL = {
  username: 'sidra2026',
  password: '@sidra.awarrd001',
  role: 'SUPER_ADMIN' as const,
  displayName: 'Super Admin (Sidra)',
};

export const STAFF_GENERAL_CREDENTIAL = {
  username: 'staff@dhac.2026',
  password: 'dhac@staff26',
  role: 'TEACHER_ADMIN' as const,
  displayName: 'Faculty & Staff Admin',
};

const AUTH_STORAGE_KEY = 'dhac_auth_user_session_v4';
const PASSWORDS_STORAGE_KEY = 'dhac_custom_passwords_v2';

export function getCustomCredentials(): Record<string, string> {
  try {
    const raw = localStorage.getItem(PASSWORDS_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }
  return {};
}

export function saveCustomCredentialLocal(username: string, newPass: string) {
  try {
    const creds = getCustomCredentials();
    creds[username.toLowerCase()] = newPass;
    creds[username] = newPass;
    localStorage.setItem(PASSWORDS_STORAGE_KEY, JSON.stringify(creds));
  } catch {
    // ignore
  }
}

export async function updateUserPassword(username: string, newPassword: string): Promise<boolean> {
  saveCustomCredentialLocal(username, newPassword);
  try {
    await fetch('/api/credentials/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, newPassword }),
    });
    return true;
  } catch {
    // offline success via localStorage
    return true;
  }
}

export async function authenticateAsync(
  usernameInput: string,
  passwordInput: string,
  studentsRegistry: StudentRecord[],
  dynamicTeachers?: TeacherRecord[]
): Promise<AuthUser | null> {
  const u = usernameInput.trim();
  const p = passwordInput.trim();

  // Try strong backend auth first
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: u, password: p }),
    });
    if (res.ok) {
      const data = await res.json();
      if (data.success && data.user) {
        saveSession(data.user);
        return data.user;
      }
    }
  } catch {
    // Offline or server temporarily unreachable -> fallback to local logic
  }

  return authenticate(usernameInput, passwordInput, studentsRegistry, dynamicTeachers);
}

export function authenticate(
  usernameInput: string,
  passwordInput: string,
  studentsRegistry: StudentRecord[],
  dynamicTeachers?: TeacherRecord[]
): AuthUser | null {
  const u = usernameInput.trim();
  const p = passwordInput.trim();
  const customCreds = getCustomCredentials();

  // Helper to check password with custom override
  const verifyPassword = (accountUser: string, defaultPassword: string): boolean => {
    const overridden = customCreds[accountUser.toLowerCase()] || customCreds[accountUser];
    if (overridden !== undefined) {
      return p === overridden;
    }
    return p === defaultPassword;
  };

  // 1. Super Admin: sidra2026 (case-insensitive)
  if (u.toLowerCase() === 'sidra2026') {
    const validSuperPasswords = [
      '@sidra.awarrd001',
      '@sidra.award001',
      'sidra@2026',
      '@sidra2026',
      'sidra2026',
    ];
    const customSuper = customCreds['sidra2026'] || customCreds['SIDRA2026'];
    const isMatch = customSuper ? p === customSuper : validSuperPasswords.includes(p);

    if (isMatch) {
      const user: AuthUser = {
        username: 'sidra2026',
        role: 'SUPER_ADMIN',
        displayName: 'Super Admin (Sidra)',
      };
      saveSession(user);
      return user;
    }
  }

  // 2. General Staff: staff@dhac.2026
  if (u.toLowerCase() === 'staff@dhac.2026' && verifyPassword('staff@dhac.2026', STAFF_GENERAL_CREDENTIAL.password)) {
    const user: AuthUser = {
      username: STAFF_GENERAL_CREDENTIAL.username,
      role: 'TEACHER_ADMIN',
      displayName: STAFF_GENERAL_CREDENTIAL.displayName,
    };
    saveSession(user);
    return user;
  }

  // 3. Specific Teacher: STAFF.[First NAME] / @dhac_[serial]
  const teachersList = dynamicTeachers && dynamicTeachers.length > 0 ? dynamicTeachers : TEACHERS_ROSTER;
  const matchedTeacher = teachersList.find(t => t.username.toUpperCase() === u.toUpperCase());
  if (matchedTeacher && verifyPassword(matchedTeacher.username, matchedTeacher.password)) {
    const user: AuthUser = {
      username: matchedTeacher.username,
      role: 'TEACHER_ADMIN',
      displayName: `${matchedTeacher.name} (${matchedTeacher.teacherId})`,
      teacherId: matchedTeacher.teacherId,
      mentorName: matchedTeacher.name,
    };
    saveSession(user);
    return user;
  }

  // 4. Student Login: student_[Ad.no] OR direct [Ad.no]
  const adInput = u.toLowerCase().startsWith('student_') ? u.substring(8) : u;
  const cleanAd = adInput.replace('*', '').toUpperCase();
  const student = studentsRegistry.find(
    s => s.adNo.toUpperCase() === cleanAd || s.adNo.replace('*', '').toUpperCase() === cleanAd
  );

  if (student) {
    const studentUsername = `student_${student.adNo}`;
    const defaultStudentPass = student.adNo.replace('*', '').toUpperCase();
    const studentPassValid = 
      verifyPassword(studentUsername, defaultStudentPass) || 
      verifyPassword(`student_${student.adNo.replace('*', '')}`, defaultStudentPass) ||
      p.toUpperCase() === defaultStudentPass;

    if (studentPassValid) {
      const user: AuthUser = {
        username: studentUsername,
        role: 'STUDENT',
        displayName: `${student.name} (AD #${student.adNo})`,
        studentId: student.id,
        adNo: student.adNo,
        className: student.className,
        mentorName: student.mentorName,
        photoUrl: student.photoUrl,
      };
      saveSession(user);
      return user;
    }
  }

  return null;
}

function saveSession(user: AuthUser) {
  try {
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(user));
  } catch {
    // storage not available
  }
}

export function getStoredAuth(): AuthUser | null {
  try {
    const stored = localStorage.getItem(AUTH_STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored) as AuthUser;
    }
  } catch {
    // ignore
  }
  return null;
}

export function logoutAuth(): void {
  try {
    localStorage.removeItem(AUTH_STORAGE_KEY);
  } catch {
    // ignore
  }
}

