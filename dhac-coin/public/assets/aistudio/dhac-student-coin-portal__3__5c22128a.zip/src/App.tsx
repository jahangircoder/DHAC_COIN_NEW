/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Navbar, NavTabType } from './components/Navbar';
import { KPISummary } from './components/KPISummary';
import { PodiumTopThree } from './components/PodiumTopThree';
import { ClassLeaderboard } from './components/ClassLeaderboard';
import { StudentTable } from './components/StudentTable';
import { ClassOverview } from './components/ClassOverview';
import { MentorOverview } from './components/MentorOverview';
import { AnalyticsView } from './components/AnalyticsView';
import { AuditView } from './components/AuditView';
import { StudentModal } from './components/StudentModal';
import { MeritPrintView } from './components/MeritPrintView';
import { LoginModal } from './components/LoginModal';
import { AwardCoinModal } from './components/AwardCoinModal';
import { AddStudentModal } from './components/AddStudentModal';
import { AddMentorModal } from './components/AddMentorModal';
import { TransactionHistoryModal } from './components/TransactionHistoryModal';
import { StudentIDCardModal } from './components/StudentIDCardModal';
import { SubmitClaimModal } from './components/SubmitClaimModal';
import { MentorApprovalQueue } from './components/MentorApprovalQueue';
import { StudentPortalView } from './components/StudentPortalView';
import { ChangePasswordModal } from './components/ChangePasswordModal';
import { SuperAdminConsoleModal } from './components/SuperAdminConsoleModal';
import { EditStudentModal } from './components/EditStudentModal';
import { EditMentorModal } from './components/EditMentorModal';
import { CLEANED_290_CSV_RAW } from './data/rawCsv';
import { parseCSV, computeMentorStats, computeClassStats, exportToCleanedCSV, recalculateAllRanks } from './data/studentParser';
import { DEFAULT_UNIONS, computeUnionStats } from './data/batchNames';
import { COIN_RULES_TABLE, CoinCategory } from './data/coinRules';
import { TEACHERS_ROSTER } from './data/teachers';
import { getStoredAuth, logoutAuth } from './data/auth';
import { StudentRecord, CoinTransaction, CoinClaim, AuthUser, TeacherRecord, UnionDefinition, UnionStats } from './types/student';

const STUDENTS_STORAGE_KEY = 'dhac_students_registry_v3_zero_base';
const TRANSACTIONS_STORAGE_KEY = 'dhac_transactions_registry_v3';
const CLAIMS_STORAGE_KEY = 'dhac_claims_registry_v3';
const CLASS_AWARDS_STORAGE_KEY = 'dhac_class_awards_v3';
const TEACHERS_STORAGE_KEY = 'dhac_teachers_roster_v2';
const RULES_STORAGE_KEY = 'dhac_coin_rules_v2';
const UNIONS_STORAGE_KEY = 'dhac_unions_config_v2';

export default function App() {
  // Initialize students with 0 coins baseline
  const [students, setStudents] = useState<StudentRecord[]>(() => {
    try {
      const stored = localStorage.getItem(STUDENTS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as StudentRecord[];
        if (parsed && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }
    return parseCSV(CLEANED_290_CSV_RAW);
  });

  // Class awards balance (credited directly to class batch standings, not individual students)
  const [classAwards, setClassAwards] = useState<Record<string, number>>(() => {
    try {
      const stored = localStorage.getItem(CLASS_AWARDS_STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {
      // ignore
    }
    return {};
  });

  // Transactions log
  const [transactions, setTransactions] = useState<CoinTransaction[]>(() => {
    try {
      const stored = localStorage.getItem(TRANSACTIONS_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored) as CoinTransaction[];
      }
    } catch {
      // ignore
    }
    return [];
  });

  // Student coin claims
  const [claims, setClaims] = useState<CoinClaim[]>(() => {
    try {
      const stored = localStorage.getItem(CLAIMS_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored) as CoinClaim[];
      }
    } catch {
      // ignore
    }
    return [];
  });

  // Teachers roster
  const [teachers, setTeachers] = useState<TeacherRecord[]>(() => {
    try {
      const stored = localStorage.getItem(TEACHERS_STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {
      // ignore
    }
    return TEACHERS_ROSTER;
  });

  // Coin rules
  const [coinCategories, setCoinCategories] = useState<CoinCategory[]>(() => {
    try {
      const stored = localStorage.getItem(RULES_STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {
      // ignore
    }
    return COIN_RULES_TABLE;
  });

  // Unions configuration
  const [unions, setUnions] = useState<UnionDefinition[]>(() => {
    try {
      const stored = localStorage.getItem(UNIONS_STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {
      // ignore
    }
    return DEFAULT_UNIONS;
  });

  // Auth
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(() => getStoredAuth());

  // Dark Mode Theme State
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('dhac_theme');
      if (saved) return saved === 'dark';
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      if (isDarkMode) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('dhac_theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('dhac_theme', 'light');
      }
    } catch {
      // ignore
    }
  }, [isDarkMode]);

  const handleToggleDarkMode = () => {
    setIsDarkMode(prev => !prev);
  };

  // Navigation tab
  const [activeTab, setActiveTab] = useState<NavTabType>('students');
  const [selectedStudent, setSelectedStudent] = useState<StudentRecord | null>(null);
  const [selectedPrintStudent, setSelectedPrintStudent] = useState<StudentRecord | null>(null);
  const [selectedClassFilter, setSelectedClassFilter] = useState<string>('ALL');
  const [selectedMentorFilter, setSelectedMentorFilter] = useState<string>('ALL');
  const [selectedTierFilter, setSelectedTierFilter] = useState<string>('ALL');
  const [selectedCoinStatusFilter, setSelectedCoinStatusFilter] = useState<string>('ALL');
  const [notification, setNotification] = useState<string | null>(null);

  // Modals state
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isAwardCoinOpen, setIsAwardCoinOpen] = useState(false);
  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false);
  const [isAddMentorOpen, setIsAddMentorOpen] = useState(false);
  const [isTransactionsOpen, setIsTransactionsOpen] = useState(false);
  const [isIDCardOpen, setIsIDCardOpen] = useState(false);
  const [idCardStudent, setIdCardStudent] = useState<StudentRecord | null>(null);
  const [isSubmitClaimOpen, setIsSubmitClaimOpen] = useState(false);
  const [claimStudent, setClaimStudent] = useState<StudentRecord | null>(null);
  const [awardPreselectStudent, setAwardPreselectStudent] = useState<StudentRecord | null>(null);
  
  // Super Admin CRUD & Password Modals
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const [isSuperAdminConsoleOpen, setIsSuperAdminConsoleOpen] = useState(false);
  const [isEditStudentOpen, setIsEditStudentOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<StudentRecord | null>(null);
  const [isEditMentorOpen, setIsEditMentorOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<TeacherRecord | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Backend synchronization on mount (Robust 2-way sync)
  useEffect(() => {
    const fetchBackendData = async () => {
      try {
        const [studentsRes, claimsRes, txRes, classRes, credsRes, teachersRes, rulesRes, unionsRes] = await Promise.allSettled([
          fetch('/api/students'),
          fetch('/api/claims'),
          fetch('/api/transactions'),
          fetch('/api/class-awards'),
          fetch('/api/credentials'),
          fetch('/api/teachers'),
          fetch('/api/rules'),
          fetch('/api/unions'),
        ]);

        if (studentsRes.status === 'fulfilled' && studentsRes.value.ok) {
          const data = await studentsRes.value.json();
          if (Array.isArray(data.students) && data.students.length > 0) {
            setStudents(data.students);
          } else {
            // Seed backend with the clean 290 students
            fetch('/api/students/bulk', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ students }),
            }).catch(() => {});
          }
        }

        if (claimsRes.status === 'fulfilled' && claimsRes.value.ok) {
          const data = await claimsRes.value.json();
          if (Array.isArray(data.claims)) {
            setClaims(data.claims);
          }
        }

        if (txRes.status === 'fulfilled' && txRes.value.ok) {
          const data = await txRes.value.json();
          if (Array.isArray(data.transactions)) {
            setTransactions(data.transactions);
          }
        }

        if (classRes.status === 'fulfilled' && classRes.value.ok) {
          const data = await classRes.value.json();
          if (data.classAwards) {
            setClassAwards(data.classAwards);
          }
        }

        if (credsRes.status === 'fulfilled' && credsRes.value.ok) {
          const data = await credsRes.value.json();
          if (data.credentials && typeof data.credentials === 'object') {
            try {
              const currentLocal = JSON.parse(localStorage.getItem('dhac_custom_passwords_v2') || '{}');
              const merged = { ...currentLocal, ...data.credentials };
              localStorage.setItem('dhac_custom_passwords_v2', JSON.stringify(merged));
            } catch {
              // ignore
            }
          }
        }

        if (teachersRes.status === 'fulfilled' && teachersRes.value.ok) {
          const data = await teachersRes.value.json();
          if (Array.isArray(data.teachers) && data.teachers.length > 0) {
            setTeachers(data.teachers);
          }
        }

        if (rulesRes.status === 'fulfilled' && rulesRes.value.ok) {
          const data = await rulesRes.value.json();
          if (Array.isArray(data.rules) && data.rules.length > 0) {
            setCoinCategories(data.rules);
          }
        }

        if (unionsRes.status === 'fulfilled' && unionsRes.value.ok) {
          const data = await unionsRes.value.json();
          if (Array.isArray(data.unions) && data.unions.length > 0) {
            setUnions(data.unions);
          }
        }
      } catch {
        // Backend offline or dev mode fallback
      }
    };

    fetchBackendData();
  }, []);

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem(STUDENTS_STORAGE_KEY, JSON.stringify(students));
    } catch {
      // ignore
    }
  }, [students]);

  useEffect(() => {
    try {
      localStorage.setItem(TRANSACTIONS_STORAGE_KEY, JSON.stringify(transactions));
    } catch {
      // ignore
    }
  }, [transactions]);

  useEffect(() => {
    try {
      localStorage.setItem(CLAIMS_STORAGE_KEY, JSON.stringify(claims));
    } catch {
      // ignore
    }
  }, [claims]);

  useEffect(() => {
    try {
      localStorage.setItem(CLASS_AWARDS_STORAGE_KEY, JSON.stringify(classAwards));
    } catch {
      // ignore
    }
  }, [classAwards]);

  useEffect(() => {
    try {
      localStorage.setItem(TEACHERS_STORAGE_KEY, JSON.stringify(teachers));
    } catch {
      // ignore
    }
  }, [teachers]);

  useEffect(() => {
    try {
      localStorage.setItem(RULES_STORAGE_KEY, JSON.stringify(coinCategories));
    } catch {
      // ignore
    }
  }, [coinCategories]);

  useEffect(() => {
    try {
      localStorage.setItem(UNIONS_STORAGE_KEY, JSON.stringify(unions));
    } catch {
      // ignore
    }
  }, [unions]);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3500);
  };

  // Dynamic statistics
  const mentorStats = useMemo(() => computeMentorStats(students), [students]);
  const classStats = useMemo(() => computeClassStats(students, classAwards), [students, classAwards]);
  const unionStats = useMemo(() => computeUnionStats(students, classAwards, unions), [students, classAwards, unions]);
  const uniqueMentors = useMemo(() => Array.from(new Set(students.map(s => s.mentorName))).sort(), [students]);
  const uniqueClasses = useMemo(() => Array.from(new Set(students.map(s => s.className))).sort(), [students]);

  // Logged-in student record if role is STUDENT
  const loggedInStudent = useMemo(() => {
    if (currentUser?.role === 'STUDENT') {
      return students.find(
        s => s.id === currentUser.studentId || s.adNo === currentUser.adNo || s.adNo.replace('*', '') === currentUser.adNo
      ) || null;
    }
    return null;
  }, [currentUser, students]);

  // Pending claims count for current user
  const pendingClaimsCount = useMemo(() => {
    if (!currentUser) return 0;
    if (currentUser.role === 'SUPER_ADMIN') {
      return claims.filter(c => c.status === 'PENDING').length;
    }
    if (currentUser.role === 'TEACHER_ADMIN') {
      return claims.filter(c => c.status === 'PENDING' && (!currentUser.mentorName || c.mentorName === currentUser.mentorName)).length;
    }
    if (currentUser.role === 'STUDENT') {
      return claims.filter(c => c.status === 'PENDING' && (c.studentId === currentUser.studentId || c.adNo === currentUser.adNo)).length;
    }
    return 0;
  }, [claims, currentUser]);

  // Handlers
  const handleSelectClass = (className: string) => {
    setSelectedClassFilter(className);
    setSelectedMentorFilter('ALL');
    setSelectedTierFilter('ALL');
    setSelectedCoinStatusFilter('ALL');
    setActiveTab('students');
  };

  const handleSelectMentor = (mentorName: string) => {
    setSelectedMentorFilter(mentorName);
    setSelectedClassFilter('ALL');
    setSelectedTierFilter('ALL');
    setSelectedCoinStatusFilter('ALL');
    setActiveTab('students');
  };

  const handleFilterZeroCoins = () => {
    setSelectedTierFilter('0');
    setSelectedClassFilter('ALL');
    setSelectedMentorFilter('ALL');
    setSelectedCoinStatusFilter('ALL');
    setActiveTab('students');
  };

  // Open ID Card modal for student
  const handleOpenIDCard = (student: StudentRecord) => {
    setIdCardStudent(student);
    setIsIDCardOpen(true);
  };

  // Student Profile Picture Update
  const handleUpdatePhoto = async (studentId: string, photoUrl: string) => {
    setStudents(prev =>
      prev.map(s => (s.id === studentId || s.studentId === studentId ? { ...s, photoUrl } : s))
    );

    if (selectedStudent && (selectedStudent.id === studentId || selectedStudent.studentId === studentId)) {
      setSelectedStudent(prev => prev ? { ...prev, photoUrl } : null);
    }
    if (idCardStudent && (idCardStudent.id === studentId || idCardStudent.studentId === studentId)) {
      setIdCardStudent(prev => prev ? { ...prev, photoUrl } : null);
    }

    try {
      await fetch(`/api/students/${studentId}/photo`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ photoUrl }),
      });
    } catch {
      // offline fallback
    }

    showNotification('Student profile photograph updated and saved.');
  };

  // Remove/Delete student (Admin Option)
  const handleDeleteStudent = async (studentId: string) => {
    const student = students.find(s => s.id === studentId || s.studentId === studentId);
    setStudents(prev => {
      const filtered = prev.filter(s => s.id !== studentId && s.studentId !== studentId);
      recalculateAllRanks(filtered);
      return filtered;
    });

    if (selectedStudent && (selectedStudent.id === studentId || selectedStudent.studentId === studentId)) {
      setSelectedStudent(null);
    }
    if (idCardStudent && (idCardStudent.id === studentId || idCardStudent.studentId === studentId)) {
      setIsIDCardOpen(false);
      setIdCardStudent(null);
    }

    try {
      await fetch(`/api/students/${studentId}`, { method: 'DELETE' });
    } catch {
      // offline fallback
    }

    showNotification(`Student ${student ? student.name : studentId} removed from institutional records.`);
  };

  // Student submits a coin claim
  const handleSubmitClaim = async (claimData: Omit<CoinClaim, 'id' | 'submittedAt' | 'status'>) => {
    const newClaim: CoinClaim = {
      ...claimData,
      id: `CLM-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      submittedAt: new Date().toLocaleString('en-US', { dateStyle: 'short', timeStyle: 'medium' }),
      status: 'PENDING',
    };

    setClaims(prev => [newClaim, ...prev]);

    try {
      const res = await fetch('/api/claims', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(claimData),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.claim) {
          setClaims(prev => [data.claim, ...prev.filter(c => c.id !== newClaim.id)]);
        }
      }
    } catch {
      // offline fallback
    }

    showNotification(`Submitted claim for ${claimData.coins} coins! Awaiting mentor confirmation.`);
  };

  // Mentor approves claim
  const handleApproveClaim = async (claimId: string) => {
    const claim = claims.find(c => c.id === claimId);
    if (!claim) return;

    const reviewerName = currentUser?.displayName || 'Faculty Mentor';
    const reviewedAt = new Date().toLocaleString('en-US', { dateStyle: 'short', timeStyle: 'medium' });

    setClaims(prev =>
      prev.map(c =>
        c.id === claimId ? { ...c, status: 'APPROVED', reviewedBy: reviewerName, reviewedAt } : c
      )
    );

    // Credit student totalCoins
    setStudents(prev => {
      const updated = prev.map(s => {
        if (s.id === claim.studentId || s.studentId === claim.studentId || s.adNo === claim.adNo) {
          const newTotal = s.totalCoins + claim.coins;
          let tier = s.tier;
          if (newTotal >= 60) tier = 'Diamond';
          else if (newTotal >= 30) tier = 'Gold';
          else if (newTotal >= 15) tier = 'Silver';
          else if (newTotal > 0) tier = 'Bronze';
          else tier = 'Zero';

          return {
            ...s,
            totalCoins: newTotal,
            coinStatus: 'CONFIRMED' as const,
            rankStatus: 'OFFICIAL' as const,
            tier,
          };
        }
        return s;
      });

      recalculateAllRanks(updated);
      return updated;
    });

    // Record transaction
    const newTx: CoinTransaction = {
      id: `TX-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: reviewedAt,
      targetType: 'STUDENT',
      studentId: claim.studentId,
      studentName: claim.studentName,
      adNo: claim.adNo,
      className: claim.className,
      category: claim.category,
      activityName: claim.activityName,
      coins: claim.coins,
      awardedBy: `Confirmed by Mentor: ${reviewerName}`,
      notes: claim.proofNotes,
    };
    setTransactions(prev => [newTx, ...prev]);

    try {
      await fetch(`/api/claims/${claimId}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reviewerName }),
      });
    } catch {
      // offline fallback
    }

    showNotification(`Confirmed and credited ${claim.coins} coins to ${claim.studentName}!`);
  };

  // Mentor rejects claim
  const handleRejectClaim = async (claimId: string, reason?: string) => {
    const reviewerName = currentUser?.displayName || 'Faculty Mentor';
    const reviewedAt = new Date().toLocaleString('en-US', { dateStyle: 'short', timeStyle: 'medium' });

    setClaims(prev =>
      prev.map(c =>
        c.id === claimId
          ? { ...c, status: 'REJECTED', reviewedBy: reviewerName, reviewedAt, rejectionReason: reason }
          : c
      )
    );

    try {
      await fetch(`/api/claims/${claimId}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reviewerName, reason }),
      });
    } catch {
      // offline fallback
    }

    showNotification('Student claim request was rejected.');
  };

  // Award Coins directly from engine (Admin / Teacher action only)
  const handleAwardCoinsFromEngine = async (txData: Omit<CoinTransaction, 'id' | 'timestamp'>) => {
    // Enforce role check: Only Admin and Teachers can add awards
    if (!currentUser || (currentUser.role !== 'SUPER_ADMIN' && currentUser.role !== 'TEACHER_ADMIN')) {
      showNotification('Access denied: Only administrators and teachers are authorized to award coins.');
      return;
    }

    const timestamp = new Date().toLocaleString('en-US', {
      dateStyle: 'short',
      timeStyle: 'medium',
    });
    const newTx: CoinTransaction = {
      ...txData,
      id: `TX-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp,
    };

    if (txData.targetType === 'STUDENT') {
      // Individual student award: update student balance and ranks
      setStudents(prev => {
        const updated = prev.map(s => {
          if (s.id === txData.studentId || s.studentId === txData.studentId) {
            const newTotal = s.totalCoins + txData.coins;
            let tier = s.tier;
            if (newTotal >= 60) tier = 'Diamond';
            else if (newTotal >= 30) tier = 'Gold';
            else if (newTotal >= 15) tier = 'Silver';
            else if (newTotal > 0) tier = 'Bronze';
            else tier = 'Zero';

            return {
              ...s,
              totalCoins: newTotal,
              coinStatus: 'CONFIRMED' as const,
              rankStatus: 'OFFICIAL' as const,
              tier,
            };
          }
          return s;
        });

        recalculateAllRanks(updated);
        return updated;
      });

      showNotification(`Awarded ${txData.coins} coins to ${txData.studentName} for "${txData.activityName}"!`);
    } else {
      // CLASS AWARD: Credited directly to Class batch standings, NOT to individual students!
      setClassAwards(prev => ({
        ...prev,
        [txData.className]: (prev[txData.className] || 0) + txData.coins,
      }));

      showNotification(`Awarded ${txData.coins} coins to Class ${txData.className} batch standings! (Individual student points remain untouched)`);
    }

    setTransactions(prev => [newTx, ...prev]);

    try {
      await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTx),
      });
      if (txData.targetType === 'STUDENT') {
        await fetch('/api/students/bulk', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ students }),
        });
      }
    } catch {
      // offline fallback
    }
  };

  // Quick award from modal
  const handleQuickAward = (studentId: string, amount: number) => {
    const student = students.find(s => s.id === studentId || s.studentId === studentId);
    if (!student) return;

    handleAwardCoinsFromEngine({
      targetType: 'STUDENT',
      studentId: student.id,
      studentName: student.name,
      adNo: student.adNo,
      className: student.className,
      category: 'SPECIAL APPRECIATION',
      activityName: 'Quick Merit Recognition',
      coins: amount,
      awardedBy: currentUser ? `${currentUser.username} (${currentUser.role})` : 'Faculty Admin',
      notes: 'Quick credit via student profile',
    });
  };

  // Add new student
  const handleAddStudent = async (newStudentData: any) => {
    const student: StudentRecord = {
      ...newStudentData,
      officialId: `DHAC/ST/2026/${newStudentData.className}/${newStudentData.adNo}`,
      campusRank: '#1',
      campusRankNum: 1,
      classRank: '#1',
      classRankNum: 1,
      mentorGroupRank: '#1/1',
      mentorRankNum: 1,
      campusTotalStudents: students.length + 1,
      classSize: 1,
      mentorGroupSize: 1,
      tier: 'Zero',
    };

    setStudents(prev => {
      const updated = [student, ...prev];
      recalculateAllRanks(updated);
      return updated;
    });

    try {
      await fetch('/api/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(student),
      });
    } catch {
      // offline fallback
    }

    showNotification(`Registered new student ${newStudentData.name} (AD #${newStudentData.adNo}) in Class ${newStudentData.className}!`);
  };

  // Add new mentor
  const handleAddMentor = (mentorName: string) => {
    const newRecord: TeacherRecord = {
      serialNo: String(teachers.length + 1).padStart(2, '0'),
      teacherId: `DHAC/STAFF/${String(teachers.length + 1).padStart(2, '0')}`,
      name: mentorName.trim().toUpperCase(),
      username: `STAFF.${mentorName.trim().split(' ')[0].toUpperCase()}`,
      password: `@dhac_${String(teachers.length + 1).padStart(2, '0')}`,
    };
    setTeachers(prev => [...prev, newRecord]);
    fetch('/api/teachers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ teachers: [...teachers, newRecord] }),
    }).catch(() => {});
    showNotification(`Mentor "${mentorName}" added to active faculty roster!`);
  };

  // Super-Admin Revoke / Remove Transaction
  const handleRevokeTransaction = async (txId: string) => {
    if (currentUser?.role !== 'SUPER_ADMIN') {
      showNotification('Access denied: Only Super Admin can revoke transactions.');
      return;
    }

    try {
      const res = await fetch(`/api/transactions/${txId}`, { method: 'DELETE' });
      if (res.ok) {
        const data = await res.json();
        if (data.students) setStudents(data.students);
        if (data.classAwards) setClassAwards(data.classAwards);
        if (data.transactions) setTransactions(data.transactions);
        showNotification('Revoked transaction: coins rolled back and ranks recalculated.');
        return;
      }
    } catch {
      // offline fallback
    }

    // Local fallback
    const tx = transactions.find(t => t.id === txId);
    if (!tx) return;

    if (tx.targetType === 'STUDENT') {
      setStudents(prev => {
        const updated = prev.map(s => {
          if (s.id === tx.studentId || s.studentId === tx.studentId || s.adNo === tx.adNo) {
            const newTotal = Math.max(0, s.totalCoins - tx.coins);
            let tier = s.tier;
            if (newTotal >= 60) tier = 'Diamond';
            else if (newTotal >= 30) tier = 'Gold';
            else if (newTotal >= 15) tier = 'Silver';
            else if (newTotal > 0) tier = 'Bronze';
            else tier = 'Zero';

            return {
              ...s,
              totalCoins: newTotal,
              tier,
              coinStatus: newTotal === 0 ? ('ZERO' as const) : s.coinStatus,
            };
          }
          return s;
        });
        recalculateAllRanks(updated);
        return updated;
      });
    } else if (tx.targetType === 'CLASS' && tx.className) {
      setClassAwards(prev => ({
        ...prev,
        [tx.className]: Math.max(0, (prev[tx.className] || 0) - tx.coins),
      }));
    }

    setTransactions(prev => prev.filter(t => t.id !== txId));
    showNotification('Revoked transaction: coins rolled back and ranks recalculated.');
  };

  // Super-Admin Save Edit Student
  const handleSaveEditStudent = async (updatedStudent: StudentRecord) => {
    setStudents(prev => {
      const updated = prev.map(s => (s.id === updatedStudent.id ? updatedStudent : s));
      recalculateAllRanks(updated);
      return updated;
    });

    if (selectedStudent && selectedStudent.id === updatedStudent.id) {
      setSelectedStudent(updatedStudent);
    }

    try {
      await fetch(`/api/students/${updatedStudent.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedStudent),
      });
    } catch {
      // offline fallback
    }

    showNotification(`Student profile for ${updatedStudent.name} updated successfully.`);
  };

  // Super-Admin Save Edit Mentor
  const handleSaveEditMentor = async (updatedTeacher: TeacherRecord, oldName: string) => {
    setTeachers(prev => prev.map(t => (t.teacherId === updatedTeacher.teacherId ? updatedTeacher : t)));

    // If mentor name changed, update mentees
    if (updatedTeacher.name !== oldName) {
      setStudents(prev => {
        const updated = prev.map(s => (s.mentorName === oldName ? { ...s, mentorName: updatedTeacher.name } : s));
        recalculateAllRanks(updated);
        return updated;
      });
      fetch('/api/students/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ students }),
      }).catch(() => {});
    }

    try {
      await fetch('/api/teachers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ teachers: teachers.map(t => (t.teacherId === updatedTeacher.teacherId ? updatedTeacher : t)) }),
      });
    } catch {}

    showNotification(`Faculty mentor "${updatedTeacher.name}" updated successfully.`);
  };

  // Super-Admin Delete Mentor
  const handleDeleteMentor = async (teacherId: string) => {
    const updated = teachers.filter(t => t.teacherId !== teacherId);
    setTeachers(updated);
    try {
      await fetch('/api/teachers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ teachers: updated }),
      });
    } catch {}
    showNotification('Mentor removed from institutional registry.');
  };

  // Super-Admin Save Rules
  const handleSaveRules = async (updatedCategories: CoinCategory[]) => {
    setCoinCategories(updatedCategories);
    try {
      await fetch('/api/rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rules: updatedCategories }),
      });
    } catch {}
    showNotification('Coin award rules updated and saved to backend.');
  };

  // Super-Admin Save Unions
  const handleSaveUnions = async (updatedUnions: UnionDefinition[]) => {
    setUnions(updatedUnions);
    try {
      await fetch('/api/unions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ unions: updatedUnions }),
      });
    } catch {}
    showNotification('Union configurations and class associations saved.');
  };

  const handleLogout = () => {
    logoutAuth();
    setCurrentUser(null);
    showNotification('Signed out of session.');
  };

  const handleExportCleanedCSV = () => {
    const csvContent = exportToCleanedCSV(students);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `DHAC_Student_Coin_Report_ALL_CLEANED_290_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showNotification('Cleaned 16-Column CSV downloaded successfully.');
  };

  const handleResetData = async () => {
    const initial = parseCSV(CLEANED_290_CSV_RAW);
    setStudents(initial);
    setTransactions([]);
    setClaims([]);
    setClassAwards({});
    try {
      localStorage.removeItem(STUDENTS_STORAGE_KEY);
      localStorage.removeItem(TRANSACTIONS_STORAGE_KEY);
      localStorage.removeItem(CLAIMS_STORAGE_KEY);
      localStorage.removeItem(CLASS_AWARDS_STORAGE_KEY);
      await fetch('/api/reset', { method: 'POST' });
    } catch {
      // ignore
    }
    setSelectedClassFilter('ALL');
    setSelectedMentorFilter('ALL');
    setSelectedTierFilter('ALL');
    setSelectedCoinStatusFilter('ALL');
    showNotification('Reset all 290 students to 0 coins baseline.');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async event => {
      const content = event.target?.result as string;
      if (content) {
        const parsed = parseCSV(content);
        if (parsed.length > 0) {
          setStudents(parsed);
          try {
            await fetch('/api/students/bulk', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ students: parsed }),
            });
          } catch {
            // ignore
          }
          showNotification(`Imported ${parsed.length} student records from ${file.name}.`);
        } else {
          showNotification('Could not parse valid student rows from file.');
        }
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handlePrintCertificate = (student: StudentRecord) => {
    setSelectedPrintStudent(student);
    setActiveTab('certificates');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif] transition-colors duration-150">
      {/* Hidden File Input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileUpload}
        accept=".csv,.txt"
        className="hidden"
      />

      {/* Toast Notification */}
      {notification && (
        <div className="fixed bottom-4 right-4 z-50 bg-slate-900 dark:bg-slate-800 text-white text-xs px-4 py-2.5 rounded-lg shadow-lg flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-200 border border-slate-700">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>{notification}</span>
        </div>
      )}

      {/* Top Institutional Header & Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onExportCleanedCSV={handleExportCleanedCSV}
        onResetData={handleResetData}
        onUploadClick={() => fileInputRef.current?.click()}
        totalStudents={students.length}
        currentUser={currentUser}
        onOpenLogin={() => setIsLoginOpen(true)}
        onLogout={handleLogout}
        onOpenAwardCoins={() => {
          setAwardPreselectStudent(null);
          setIsAwardCoinOpen(true);
        }}
        onOpenAddStudent={() => setIsAddStudentOpen(true)}
        onOpenAddMentor={() => setIsAddMentorOpen(true)}
        onOpenTransactions={() => setIsTransactionsOpen(true)}
        pendingClaimsCount={pendingClaimsCount}
        onOpenIDCard={() => {
          if (loggedInStudent) handleOpenIDCard(loggedInStudent);
        }}
        onOpenSubmitClaim={() => {
          if (loggedInStudent) {
            setClaimStudent(loggedInStudent);
            setIsSubmitClaimOpen(true);
          }
        }}
        onOpenChangePassword={() => setIsChangePasswordOpen(true)}
        onOpenSuperAdminConsole={() => setIsSuperAdminConsoleOpen(true)}
        isDarkMode={isDarkMode}
        onToggleDarkMode={handleToggleDarkMode}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* If Student is logged in, show their quick portal banner on general views */}
        {loggedInStudent && activeTab !== 'portal' && activeTab !== 'certificates' && (
          <div className="mb-6 p-4 bg-emerald-900/90 text-white rounded-xl shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3 border border-emerald-700">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-950 border border-amber-400 text-amber-300 flex items-center justify-center font-bold text-sm shrink-0 overflow-hidden">
                {loggedInStudent.photoUrl ? (
                  <img src={loggedInStudent.photoUrl} alt={loggedInStudent.name} className="w-full h-full object-cover" />
                ) : (
                  <span>{loggedInStudent.name.charAt(0)}</span>
                )}
              </div>
              <div>
                <div className="text-xs font-mono text-amber-300">
                  Signed in as student: {loggedInStudent.officialId}
                </div>
                <div className="text-sm font-bold text-white">
                  {loggedInStudent.name} (Class {loggedInStudent.className}) · Total Balance: {loggedInStudent.totalCoins} Coins
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleOpenIDCard(loggedInStudent)}
                className="px-3 py-1.5 text-xs font-bold text-slate-900 bg-white hover:bg-slate-100 rounded-lg shadow-xs"
              >
                Digital ID Card
              </button>
              <button
                onClick={() => {
                  setClaimStudent(loggedInStudent);
                  setIsSubmitClaimOpen(true);
                }}
                className="px-3 py-1.5 text-xs font-bold text-amber-950 bg-amber-400 hover:bg-amber-300 rounded-lg shadow-xs"
              >
                + Add Coin Claim
              </button>
            </div>
          </div>
        )}

        {/* If Teacher or Super Admin has pending claims, show alert banner */}
        {(currentUser?.role === 'SUPER_ADMIN' || currentUser?.role === 'TEACHER_ADMIN') && pendingClaimsCount > 0 && activeTab !== 'approvals' && (
          <div className="mb-6 p-4 bg-amber-50 border-2 border-amber-300 rounded-xl shadow-xs flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="w-3 h-3 rounded-full bg-amber-500 animate-ping" />
              <div>
                <span className="text-xs font-bold text-amber-900 block">
                  {pendingClaimsCount} Student Coin Claim{pendingClaimsCount > 1 ? 's' : ''} Awaiting Your Mentor Confirmation!
                </span>
                <span className="text-[11px] text-amber-700">
                  Students have submitted activity merit proofs that require faculty review before coins are credited.
                </span>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('approvals')}
              className="px-3.5 py-1.5 text-xs font-bold text-white bg-amber-800 hover:bg-amber-700 rounded-lg whitespace-nowrap shadow-xs"
            >
              Review Desk →
            </button>
          </div>
        )}

        {/* Tab: Student Portal View */}
        {activeTab === 'portal' && loggedInStudent && (
          <StudentPortalView
            student={loggedInStudent}
            claims={claims}
            onOpenSubmitClaim={() => {
              setClaimStudent(loggedInStudent);
              setIsSubmitClaimOpen(true);
            }}
            onOpenIDCard={() => handleOpenIDCard(loggedInStudent)}
            onUpdatePhoto={handleUpdatePhoto}
            onOpenChangePassword={() => setIsChangePasswordOpen(true)}
          />
        )}

        {/* Tab: Mentor Confirmation Desk */}
        {activeTab === 'approvals' && (
          <MentorApprovalQueue
            claims={claims}
            currentUser={currentUser}
            onApproveClaim={handleApproveClaim}
            onRejectClaim={handleRejectClaim}
          />
        )}

        {/* KPI Summary (shown on standard overview tabs) */}
        {activeTab !== 'certificates' && activeTab !== 'audit' && activeTab !== 'approvals' && activeTab !== 'portal' && (
          <KPISummary
            students={students}
            mentorStats={mentorStats}
            classStats={classStats}
            onSelectStudent={setSelectedStudent}
            onFilterZeroCoins={handleFilterZeroCoins}
          />
        )}

        {/* Tab 1: Leaderboard & Students Table */}
        {activeTab === 'students' && (
          <div>
            {/* Campus Honor Roll Podium (Top 3) */}
            <PodiumTopThree
              students={students}
              onSelectStudent={setSelectedStudent}
            />

            {/* Class Rankings & Batch Standings (Requested in Dashboard) */}
            <ClassLeaderboard
              classStats={classStats}
              unionStats={unionStats}
              onSelectClass={handleSelectClass}
              onSelectStudent={setSelectedStudent}
            />

            {/* Searchable Students Table with ID Card and Admin Remove */}
            <StudentTable
              students={students}
              selectedClassFilter={selectedClassFilter}
              setSelectedClassFilter={setSelectedClassFilter}
              selectedMentorFilter={selectedMentorFilter}
              setSelectedMentorFilter={setSelectedMentorFilter}
              selectedTierFilter={selectedTierFilter}
              setSelectedTierFilter={setSelectedTierFilter}
              selectedCoinStatusFilter={selectedCoinStatusFilter}
              setSelectedCoinStatusFilter={setSelectedCoinStatusFilter}
              onSelectStudent={setSelectedStudent}
              onPrintCertificate={handlePrintCertificate}
              onOpenIDCard={handleOpenIDCard}
              onDeleteStudent={handleDeleteStudent}
              onEditStudent={student => {
                setEditingStudent(student);
                setIsEditStudentOpen(true);
              }}
              isAdmin={currentUser?.role === 'SUPER_ADMIN'}
            />
          </div>
        )}

        {/* Tab 2: Classes Overview (12 Classes with Batch Names) */}
        {activeTab === 'classes' && (
          <ClassOverview
            classStats={classStats}
            onSelectClass={handleSelectClass}
            onSelectStudent={setSelectedStudent}
          />
        )}

        {/* Tab 3: Mentor Groups Overview (20 Mentors) */}
        {activeTab === 'mentors' && (
          <MentorOverview
            mentorStats={mentorStats}
            allStudents={students}
            onSelectMentor={handleSelectMentor}
            onSelectStudent={setSelectedStudent}
          />
        )}

        {/* Tab 4: Analytics View */}
        {activeTab === 'analytics' && (
          <AnalyticsView
            students={students}
            classStats={classStats}
            mentorStats={mentorStats}
            onSelectStudent={setSelectedStudent}
            onFilterZeroCoins={handleFilterZeroCoins}
          />
        )}

        {/* Tab 5: Data Quality & Audit Console */}
        {activeTab === 'audit' && (
          <AuditView
            students={students}
            onDownloadCleanedCSV={handleExportCleanedCSV}
          />
        )}

        {/* Tab 6: Merit Certificates Print View */}
        {activeTab === 'certificates' && (
          <MeritPrintView
            students={students}
            selectedStudent={selectedPrintStudent}
            onSelectStudent={setSelectedPrintStudent}
            onBack={() => setActiveTab('students')}
          />
        )}
      </main>

      {/* Student Profile Modal */}
      {selectedStudent && (
        <StudentModal
          student={selectedStudent}
          onClose={() => setSelectedStudent(null)}
          onAwardCoins={handleQuickAward}
          onPrintCertificate={handlePrintCertificate}
          onOpenIDCard={handleOpenIDCard}
          onDeleteStudent={handleDeleteStudent}
          onUpdatePhoto={handleUpdatePhoto}
          currentUser={currentUser}
          totalCampusStudents={students.length}
        />
      )}

      {/* Official Digital Student ID Card Modal */}
      <StudentIDCardModal
        isOpen={isIDCardOpen}
        onClose={() => {
          setIsIDCardOpen(false);
          setIdCardStudent(null);
        }}
        student={idCardStudent}
        currentUser={currentUser}
        onUpdatePhoto={handleUpdatePhoto}
      />

      {/* Submit Coin Claim Modal (For Student submission) */}
      {claimStudent && (
        <SubmitClaimModal
          isOpen={isSubmitClaimOpen}
          onClose={() => {
            setIsSubmitClaimOpen(false);
            setClaimStudent(null);
          }}
          student={claimStudent}
          onSubmitClaim={handleSubmitClaim}
        />
      )}

      {/* Multi-role Login Modal (Masked Inputs for Super Admin, Teachers, and Students) */}
      <LoginModal
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
        students={students}
        teachers={teachers}
        onLoginSuccess={user => {
          setCurrentUser(user);
          if (user.role === 'STUDENT') {
            setActiveTab('portal');
            showNotification(`Welcome, ${user.displayName}! Access granted to Student Coin Portal.`);
          } else if (user.role === 'TEACHER_ADMIN') {
            setActiveTab('approvals');
            showNotification(`Welcome, ${user.displayName}! Signed in to Faculty Desk.`);
          } else {
            showNotification(`Welcome, ${user.displayName}! Signed in as Super Admin.`);
          }
        }}
      />

      {/* Award Coins Modal (Rules Engine Table) */}
      <AwardCoinModal
        isOpen={isAwardCoinOpen}
        onClose={() => setIsAwardCoinOpen(false)}
        students={students}
        currentUser={currentUser}
        onAwardCoins={handleAwardCoinsFromEngine}
        preselectedStudent={awardPreselectStudent}
      />

      {/* Add Student Modal */}
      <AddStudentModal
        isOpen={isAddStudentOpen}
        onClose={() => setIsAddStudentOpen(false)}
        onAddStudent={handleAddStudent}
        existingMentors={uniqueMentors}
        existingClasses={uniqueClasses}
      />

      {/* Add Mentor Modal */}
      <AddMentorModal
        isOpen={isAddMentorOpen}
        onClose={() => setIsAddMentorOpen(false)}
        onAddMentor={handleAddMentor}
        existingMentors={uniqueMentors}
      />

      {/* Transaction History Modal with Super-Admin Revoke Coin */}
      <TransactionHistoryModal
        isOpen={isTransactionsOpen}
        onClose={() => setIsTransactionsOpen(false)}
        transactions={transactions}
        currentUser={currentUser}
        onRevokeTransaction={handleRevokeTransaction}
      />

      {/* Self-Service Change Password Modal (Students & Teachers & Admin) */}
      {currentUser && (
        <ChangePasswordModal
          isOpen={isChangePasswordOpen}
          onClose={() => setIsChangePasswordOpen(false)}
          currentUser={currentUser}
          onSuccess={msg => showNotification(msg)}
        />
      )}

      {/* Super Admin Master Management Console */}
      <SuperAdminConsoleModal
        isOpen={isSuperAdminConsoleOpen}
        onClose={() => setIsSuperAdminConsoleOpen(false)}
        students={students}
        teachers={teachers}
        coinCategories={coinCategories}
        unions={unions}
        onAddStudent={() => setIsAddStudentOpen(true)}
        onEditStudent={s => {
          setEditingStudent(s);
          setIsEditStudentOpen(true);
        }}
        onDeleteStudent={handleDeleteStudent}
        onAddMentor={() => setIsAddMentorOpen(true)}
        onEditMentor={t => {
          setEditingTeacher(t);
          setIsEditMentorOpen(true);
        }}
        onDeleteMentor={handleDeleteMentor}
        onSaveRules={handleSaveRules}
        onSaveUnions={handleSaveUnions}
        onShowNotification={showNotification}
      />

      {/* Edit Student Modal (Super Admin) */}
      {editingStudent && (
        <EditStudentModal
          isOpen={isEditStudentOpen}
          onClose={() => {
            setIsEditStudentOpen(false);
            setEditingStudent(null);
          }}
          student={editingStudent}
          mentorsList={uniqueMentors}
          classesList={uniqueClasses}
          onSave={handleSaveEditStudent}
        />
      )}

      {/* Edit Mentor Modal (Super Admin) */}
      {editingTeacher && (
        <EditMentorModal
          isOpen={isEditMentorOpen}
          onClose={() => {
            setIsEditMentorOpen(false);
            setEditingTeacher(null);
          }}
          teacher={editingTeacher}
          onSave={handleSaveEditMentor}
        />
      )}

      {/* Institutional Footer */}
      <footer className="no-print border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 dark:text-slate-400 gap-2">
          <div className="font-medium text-slate-700 dark:text-slate-300">
            DARUL HUDA ISLAMIC UNIVERSITY, ASSAM CENTRE · STUDENTS AFFAIRS BOARD
          </div>
          <div className="font-mono tabular-nums">
            {students.length} Student Profiles · {classStats.length} Batches · {uniqueMentors.length} Mentors · Official Coin Distribution Engine
          </div>
        </div>
      </footer>
    </div>
  );
}
