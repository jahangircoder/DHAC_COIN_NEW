import React from 'react';
import { StudentRecord, MentorStats, ClassStats } from '../types/student';
import { Coins, Users, Trophy, AlertCircle, TrendingUp, Sparkles, Award } from 'lucide-react';

interface KPISummaryProps {
  students: StudentRecord[];
  mentorStats: MentorStats[];
  classStats: ClassStats[];
  onSelectStudent: (student: StudentRecord) => void;
  onFilterZeroCoins: () => void;
}

export const KPISummary: React.FC<KPISummaryProps> = ({
  students,
  mentorStats,
  classStats,
  onSelectStudent,
  onFilterZeroCoins,
}) => {
  const totalCoins = students.reduce((sum, s) => sum + s.totalCoins, 0);
  const activeCount = students.filter(s => s.totalCoins > 0).length;
  const zeroCount = students.filter(s => s.totalCoins === 0).length;
  const avgCoins = students.length ? Math.round((totalCoins / students.length) * 10) / 10 : 0;

  // Campus topper
  const topper = [...students].sort((a, b) => b.totalCoins - a.totalCoins || a.campusRankNum - b.campusRankNum)[0];
  const topMentor = mentorStats[0];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
      {/* 1. Total Students */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
          <span className="text-xs font-medium">Total Students</span>
          <Users className="w-4 h-4 text-slate-400 dark:text-slate-500" />
        </div>
        <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100 leading-tight">
          {students.length}
        </div>
        <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1">
          <span>{classStats.length} Classes</span>
          <span>·</span>
          <span>{mentorStats.length} Mentors</span>
        </div>
      </div>

      {/* 2. Total Coins */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
          <span className="text-xs font-medium">Total Coins</span>
          <Coins className="w-4 h-4 text-amber-500" />
        </div>
        <div className="text-2xl font-bold font-mono tabular-nums text-amber-600 dark:text-amber-400 leading-tight">
          {totalCoins.toLocaleString()}
        </div>
        <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Across all departments
        </div>
      </div>

      {/* 3. Average Coins */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
          <span className="text-xs font-medium">Avg per Student</span>
          <TrendingUp className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
        </div>
        <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100 leading-tight">
          {avgCoins}
        </div>
        <div className="text-xs text-emerald-600 dark:text-emerald-400 mt-1">
          {Math.round((activeCount / (students.length || 1)) * 100)}% earning rate
        </div>
      </div>

      {/* 4. Campus Champion */}
      <div 
        onClick={() => topper && onSelectStudent(topper)}
        className="bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-900/60 rounded-xl p-4 shadow-xs cursor-pointer hover:border-amber-400 dark:hover:border-amber-500 transition-colors"
      >
        <div className="flex items-center justify-between text-amber-800 dark:text-amber-300 mb-2">
          <span className="text-xs font-semibold flex items-center gap-1">
            <Trophy className="w-3.5 h-3.5 text-amber-500" /> Campus #1
          </span>
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
        </div>
        <div className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate" title={topper?.name}>
          {topper?.name || 'N/A'}
        </div>
        <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1 font-mono tabular-nums">
          <span className="font-semibold text-amber-600 dark:text-amber-400">{topper?.totalCoins} coins</span>
          <span>·</span>
          <span>{topper?.className}</span>
        </div>
      </div>

      {/* 5. Leading Mentor Group */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
          <span className="text-xs font-medium">Top Mentor Group</span>
          <Award className="w-4 h-4 text-indigo-500 dark:text-indigo-400" />
        </div>
        <div className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate" title={topMentor?.mentorName}>
          {topMentor ? topMentor.mentorName.replace(' HUDAWI', '') : 'N/A'}
        </div>
        <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-mono tabular-nums">
          {topMentor?.totalCoins} coins ({topMentor?.averageCoins} avg)
        </div>
      </div>

      {/* 6. Zero Coins (Intervention Needed) */}
      <div 
        onClick={onFilterZeroCoins}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-rose-300 dark:hover:border-rose-700 rounded-xl p-4 shadow-xs cursor-pointer transition-colors"
      >
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
          <span className="text-xs font-medium">0 Coins (Needs Focus)</span>
          <AlertCircle className="w-4 h-4 text-rose-500" />
        </div>
        <div className="text-2xl font-bold font-mono tabular-nums text-rose-600 dark:text-rose-400 leading-tight">
          {zeroCount}
        </div>
        <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 hover:text-rose-600 dark:hover:text-rose-400 transition-colors">
          Click to inspect list →
        </div>
      </div>
    </div>
  );
};
