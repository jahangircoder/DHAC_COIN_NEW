{/* TAB 5: MASTER PASSWORD MANAGEMENT (REWRITTEN FOR MASKED ZERO-KNOWLEDGE SECURITY) */}
{activeTab === 'passwords' && (
  <div className="space-y-4">
    <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-900 flex items-center justify-between shadow-xs">
      <div className="flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse shrink-0" />
        <span>
          <strong>Zero-Knowledge Encryption Standard:</strong> Raw plaintext student and staff credentials are cryptographically protected at the database storage engine layer. Password visibility lookups are restricted. Administration is strictly authorized to perform raw password write-over updates.
        </span>
      </div>
      <span className="font-bold text-rose-950 font-mono tracking-wider text-[10px]">SECURED CONSOLE</span>
    </div>

    {/* Filtering Bar Panel */}
    <div className="relative max-w-md">
      <input
        type="text"
        placeholder="Search account catalog by username, name, or student admission number..."
        value={passwordSearch}
        onChange={e => setPasswordSearch(e.target.value)}
        className="w-full pl-3 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-700 bg-slate-50/50"
      />
    </div>

    {/* High Density Credentials Table Management Window */}
    <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
      <div className="overflow-x-auto max-h-[52vh]">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-100 text-slate-700 sticky top-0 z-10 border-b border-slate-200 font-bold">
            <tr>
              <th className="p-2.5">System Context</th>
              <th className="p-2.5">User Identity Matrix</th>
              <th className="p-2.5">Login Account Username</th>
              <th className="p-2.5">Credential State Map</th>
              <th className="p-2.5 text-center">Institutional Password Reset Overrides</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
            
            {/* 1. Super Admin Account Node Row */}
            <tr className="bg-slate-50/40">
              <td className="p-2.5">
                <span className="px-2 py-0.5 rounded bg-slate-900 text-white font-bold text-[9px]">
                  SUPER_ADMIN
                </span>
              </td>
              <td className="p-2.5 font-sans font-bold text-slate-900">SIDRA System Manager Account</td>
              <td className="p-2.5 font-bold text-slate-800">sidra2026</td>
              <td className="p-2.5 text-slate-400 font-mono italic tracking-wide">
                [SECURED_SERVER_HASH_VALUE]
              </td>
              <td className="p-2.5 text-center font-sans">
                {editingPasswordUser !== 'sidra2026' ? (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingPasswordUser('sidra2026');
                      setNewPasswordVal('');
                    }}
                    className="px-2.5 py-1 text-xs font-bold text-slate-800 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition shadow-xs cursor-pointer"
                  >
                    Reset Password Override
                  </button>
                ) : (
                  <div className="inline-flex items-center gap-1.5">
                    <input
                      type="password"
                      placeholder="Enter raw secret code"
                      value={newPasswordVal}
                      onChange={e => setNewPasswordVal(e.target.value)}
                      className="px-2 py-0.5 border rounded-md text-xs focus:ring-1 focus:ring-emerald-700 bg-white"
                    />
                    <button
                      type="button"
                      onClick={() => handleUpdateUserPasswordDirect('sidra2026')}
                      className="px-2 py-0.5 bg-emerald-800 text-white rounded-md text-xs font-bold hover:bg-emerald-900 transition cursor-pointer"
                    >
                      Save
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingPasswordUser(null)}
                      className="text-xs text-slate-400 hover:text-slate-600 transition cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </td>
            </tr>

            {/* 2. Faculty Teachers / Mentors Block Directory Iteration Loop */}
            {teachers
              .filter(t => t.name.toLowerCase().includes(passwordSearch.toLowerCase()) || t.username.toLowerCase().includes(passwordSearch.toLowerCase()))
              .map(t => (
                <tr key={t.teacherId} className="hover:bg-slate-50/60 transition-colors">
                  <td className="p-2.5">
                    <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-900 font-bold text-[9px]">
                      TEACHER_ADMIN
                    </span>
                  </td>
                  <td className="p-2.5 font-sans font-semibold text-slate-900">{t.name}</td>
                  <td className="p-2.5 text-emerald-950 font-bold">{t.username}</td>
                  <td className="p-2.5 text-slate-400 font-mono italic tracking-wide">
                    [SECURED_SERVER_HASH_VALUE]
                  </td>
                  <td className="p-2.5 text-center font-sans">
                    {editingPasswordUser !== t.username ? (
                      <button
                        type="button"
                        onClick={() => {
                          setEditingPasswordUser(t.username);
                          setNewPasswordVal('');
                        }}
                        className="px-2.5 py-1 text-xs font-bold text-slate-800 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition shadow-xs cursor-pointer"
                      >
                        Reset Password Override
                      </button>
                    ) : (
                      <div className="inline-flex items-center gap-1.5">
                        <input
                          type="password"
                          placeholder="Enter new credential code"
                          value={newPasswordVal}
                          onChange={e => setNewPasswordVal(e.target.value)}
                          className="px-2 py-0.5 border rounded-md text-xs focus:ring-1 focus:ring-emerald-700 bg-white"
                        />
                        <button
                          type="button"
                          onClick={() => handleUpdateUserPasswordDirect(t.username)}
                          className="px-2 py-0.5 bg-emerald-800 text-white rounded-md text-xs font-bold hover:bg-emerald-900 transition cursor-pointer"
                        >
                          Save
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingPasswordUser(null)}
                          className="text-xs text-slate-400 hover:text-slate-600 transition cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}

            {/* 3. Students Registry Cohort Loop Mapping (Windows constrained to 60 elements for performance) */}
            {students
              .filter(s => s.name.toLowerCase().includes(passwordSearch.toLowerCase()) || s.adNo.includes(passwordSearch))
              .slice(0, 60)
              .map(s => {
                const studentUser = `student_${s.adNo}`;
                return (
                  <tr key={s.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="p-2.5">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-800 font-semibold text-[9px]">
                        STUDENT ({s.className})
                      </span>
                    </td>
                    <td className="p-2.5 font-sans font-medium text-slate-900">{s.name}</td>
                    <td className="p-2.5 text-slate-600">{studentUser}</td>
                    <td className="p-2.5 text-slate-400 font-mono italic tracking-wide">
                      [SECURED_SERVER_HASH_VALUE]
                    </td>
                    <td className="p-2.5 text-center font-sans">
                      {editingPasswordUser !== studentUser ? (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingPasswordUser(studentUser);
                            setNewPasswordVal('');
                          }}
                          className="px-2.5 py-1 text-xs font-bold text-slate-800 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition shadow-xs cursor-pointer"
                        >
                          Reset Password Override
                        </button>
                      ) : (
                        <div className="inline-flex items-center gap-1.5">
                          <input
                            type="password"
                            placeholder="Enter new credential code"
                            value={newPasswordVal}
                            onChange={e => setNewPasswordVal(e.target.value)}
                            className="px-2 py-0.5 border rounded-md text-xs focus:ring-1 focus:ring-emerald-700 bg-white"
                          />
