import React, { useState } from 'react';
import { X, Award, Check } from 'lucide-react';

interface AddMentorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddMentor: (mentorName: string) => void;
  existingMentors: string[];
}

export const AddMentorModal: React.FC<AddMentorModalProps> = ({
  isOpen,
  onClose,
  onAddMentor,
  existingMentors,
}) => {
  const [mentorName, setMentorName] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    let clean = mentorName.trim().toUpperCase();
    if (!clean) {
      setError('Please enter a mentor name.');
      return;
    }

    if (!clean.includes('HUDAWI')) {
      clean = `${clean} HUDAWI`;
    }

    if (existingMentors.includes(clean)) {
      setError(`Mentor "${clean}" already exists in the faculty roster.`);
      return;
    }

    onAddMentor(clean);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div 
        className="bg-white border border-slate-200 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-10 h-10 rounded-xl bg-emerald-800 text-amber-400 flex items-center justify-center mb-2 shadow-xs">
            <Award className="w-5 h-5 text-amber-300" />
          </div>

          <h2 className="text-lg font-bold text-white tracking-tight">
            Add Faculty Mentor
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Register a new mentor to supervise mentee groups and award merit points
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg font-medium">
              {error}
            </div>
          )}

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700">
              Mentor Full Name:
            </label>
            <input
              type="text"
              required
              value={mentorName}
              onChange={e => setMentorName(e.target.value)}
              placeholder="e.g. AHMAD KABEER HUDAWI"
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 focus:bg-white uppercase"
            />
            <p className="text-[11px] text-slate-500">
              "HUDAWI" will be automatically appended if omitted.
            </p>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition shadow-xs"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Add Mentor</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
