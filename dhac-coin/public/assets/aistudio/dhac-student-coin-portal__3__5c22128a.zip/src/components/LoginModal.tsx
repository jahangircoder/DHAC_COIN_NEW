import React, { useState } from 'react';
import { X, Lock, Shield, User, Key, Eye, EyeOff, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { authenticateAsync } from '../data/auth';
import { AuthUser, StudentRecord, TeacherRecord } from '../types/student';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: AuthUser) => void;
  students: StudentRecord[];
  teachers?: TeacherRecord[];
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  students,
  teachers,
}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [hidePassword, setHidePassword] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showHelper, setShowHelper] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const user = await authenticateAsync(username, password, students, teachers);
      if (user) {
        onLoginSuccess(user);
        onClose();
      } else {
        setError('Invalid username or password. Please verify your credentials.');
      }
    } catch {
      setError('Connection error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div 
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 my-auto"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-emerald-950 text-white p-5 sm:p-6 relative border-b-2 border-amber-400">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-emerald-900 transition touch-manipulation min-w-[36px] min-h-[36px] flex items-center justify-center cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-900 border border-amber-400 text-amber-300 flex items-center justify-center shadow-xs shrink-0">
              <Lock className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="text-[10px] sm:text-[11px] font-mono tracking-wider text-amber-300 uppercase font-semibold">
                DARUL HUDA ISLAMIC UNIVERSITY
              </div>
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                Institutional Portal Login
              </h2>
            </div>
          </div>
          <p className="text-xs text-emerald-200/80 mt-1">
            Sign in with your assigned institutional credentials (Super Admin, Teacher, or Student).
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs sm:text-sm rounded-lg font-medium flex items-start gap-2">
              <span className="font-bold">✕</span>
              <div>
                <div>{error}</div>
                <button
                  type="button"
                  onClick={() => setShowHelper(true)}
                  className="text-xs underline text-rose-800 dark:text-rose-400 hover:text-rose-900 dark:hover:text-rose-300 mt-1 font-semibold cursor-pointer"
                >
                  View institutional credential format
                </button>
              </div>
            </div>
          )}

          {/* Username Input - Plain text by default to avoid typing errors */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-emerald-800 dark:text-emerald-400" /> Username
            </label>
            <div className="relative">
              <input
                type="text"
                required
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck="false"
                value={username}
                onChange={e => setUsername(e.target.value)}
                placeholder="e.g. sidra2026 or student_635 or STAFF.SHAFI"
                className="w-full px-3.5 py-2.5 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-800 focus:bg-white dark:focus:bg-slate-800 font-mono text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          {/* Password Input (Masked with clear toggle) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-emerald-800 dark:text-emerald-400" /> Password
              </label>
              <button
                type="button"
                onClick={() => setHidePassword(prev => !prev)}
                className="text-xs text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 py-0.5 px-1.5 rounded touch-manipulation cursor-pointer"
              >
                {hidePassword ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>{hidePassword ? 'Show' : 'Hide'}</span>
              </button>
            </div>
            <div className="relative">
              <input
                type={hidePassword ? 'password' : 'text'}
                required
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck="false"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full px-3.5 py-2.5 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-800 focus:bg-white dark:focus:bg-slate-800 font-mono text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          {/* Credential Format Assistance Accordion */}
          <div className="pt-1">
            <button
              type="button"
              onClick={() => setShowHelper(prev => !prev)}
              className="w-full flex items-center justify-between p-2.5 text-xs text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg transition cursor-pointer"
            >
              <span className="flex items-center gap-1.5 font-medium">
                <HelpCircle className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
                <span>Credential Reference Guide</span>
              </span>
              {showHelper ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>

            {showHelper && (
              <div className="mt-2 p-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-lg text-xs space-y-2 text-slate-700 dark:text-slate-300 font-sans">
                <div className="border-b border-slate-200 dark:border-slate-700 pb-1.5">
                  <div className="font-bold text-amber-900 dark:text-amber-400 flex items-center justify-between">
                    <span>👑 Super Admin</span>
                    <button
                      type="button"
                      onClick={() => {
                        setUsername('sidra2026');
                        setPassword('@sidra.awarrd001');
                      }}
                      className="text-[10px] text-emerald-800 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded font-mono font-bold cursor-pointer"
                    >
                      Fill
                    </button>
                  </div>
                  <div className="text-[11px] font-mono text-slate-600 dark:text-slate-400 mt-0.5">
                    User: <strong className="text-slate-900 dark:text-slate-100">sidra2026</strong> | Pass: <strong className="text-slate-900 dark:text-slate-100">@sidra.awarrd001</strong> (or <strong className="text-slate-900 dark:text-slate-100">sidra@2026</strong>)
                  </div>
                </div>

                <div className="border-b border-slate-200 dark:border-slate-700 pb-1.5">
                  <div className="font-bold text-emerald-950 dark:text-emerald-300 flex items-center justify-between">
                    <span>🎓 Faculty Mentors</span>
                    <button
                      type="button"
                      onClick={() => {
                        setUsername('STAFF.SHAFI');
                        setPassword('@dhac_01');
                      }}
                      className="text-[10px] text-emerald-800 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded font-mono font-bold cursor-pointer"
                    >
                      Fill Shafi
                    </button>
                  </div>
                  <div className="text-[11px] font-mono text-slate-600 dark:text-slate-400 mt-0.5">
                    User: <strong className="text-slate-900 dark:text-slate-100">STAFF.[NAME]</strong> | Pass: <strong className="text-slate-900 dark:text-slate-100">@dhac_[01..20]</strong>
                  </div>
                </div>

                <div>
                  <div className="font-bold text-indigo-950 dark:text-indigo-300 flex items-center justify-between">
                    <span>👤 Students (290 Enrolled)</span>
                    <button
                      type="button"
                      onClick={() => {
                        setUsername('student_635');
                        setPassword('635');
                      }}
                      className="text-[10px] text-emerald-800 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded font-mono font-bold cursor-pointer"
                    >
                      Fill 635
                    </button>
                  </div>
                  <div className="text-[11px] font-mono text-slate-600 dark:text-slate-400 mt-0.5">
                    User: <strong className="text-slate-900 dark:text-slate-100">student_[AD_NO]</strong> or <strong className="text-slate-900 dark:text-slate-100">[AD_NO]</strong> | Pass: <strong className="text-slate-900 dark:text-slate-100">[AD_NO]</strong>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="px-4 py-2.5 text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition min-h-[44px] cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-6 py-2.5 text-xs sm:text-sm font-bold text-white bg-emerald-900 hover:bg-emerald-800 active:bg-emerald-950 rounded-lg transition shadow-md min-h-[44px] flex items-center justify-center gap-2 touch-manipulation cursor-pointer"
            >
              {isLoading ? (
                <span>Authenticating...</span>
              ) : (
                <>
                  <Shield className="w-4 h-4 text-amber-300" />
                  <span>Sign In</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
