import React, { useState } from 'react';
import { 
  Award, Download, RefreshCw, ShieldCheck, LogIn, LogOut, Coins, 
  UserPlus, History, Clock, CreditCard, Send, User, KeyRound, 
  ShieldAlert, Menu, X, ChevronRight, Sparkles, Sun, Moon
} from 'lucide-react';
import { AuthUser } from '../types/student';

export type NavTabType = 'students' | 'classes' | 'mentors' | 'analytics' | 'audit' | 'certificates' | 'approvals' | 'portal';

interface NavbarProps {
  activeTab: NavTabType;
  setActiveTab: (tab: NavTabType) => void;
  onExportCleanedCSV: () => void;
  onResetData: () => void;
  onUploadClick: () => void;
  totalStudents: number;
  currentUser: AuthUser | null;
  onOpenLogin: () => void;
  onLogout: () => void;
  onOpenAwardCoins: () => void;
  onOpenAddStudent: () => void;
  onOpenAddMentor: () => void;
  onOpenTransactions: () => void;
  pendingClaimsCount?: number;
  onOpenIDCard?: () => void;
  onOpenSubmitClaim?: () => void;
  onOpenChangePassword?: () => void;
  onOpenSuperAdminConsole?: () => void;
  isDarkMode?: boolean;
  onToggleDarkMode?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onExportCleanedCSV,
  onResetData,
  currentUser,
  onOpenLogin,
  onLogout,
  onOpenAwardCoins,
  onOpenAddStudent,
  onOpenAddMentor,
  onOpenTransactions,
  pendingClaimsCount = 0,
  onOpenIDCard,
  onOpenSubmitClaim,
  onOpenChangePassword,
  onOpenSuperAdminConsole,
  isDarkMode = false,
  onToggleDarkMode,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isSuperAdmin = currentUser?.role === 'SUPER_ADMIN';
  const isTeacher = currentUser?.role === 'TEACHER_ADMIN';
  const isStudent = currentUser?.role === 'STUDENT';
  const isFaculty = isSuperAdmin || isTeacher;

  const handleTabClick = (tab: NavTabType) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 sticky top-0 z-30 shadow-xs transition-colors duration-150">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-2">
          {/* Zone 1: Left Group (Mobile Menu Button on FAR LEFT + Institutional Seal & Wordmark) */}
          <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
            {/* Mobile Menu Icon on the LEFT */}
            <button
              onClick={() => setMobileMenuOpen(prev => !prev)}
              className="lg:hidden p-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 transition touch-manipulation min-w-[40px] min-h-[40px] flex items-center justify-center shrink-0"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5 text-amber-600 dark:text-amber-400" /> : <Menu className="w-5 h-5" />}
            </button>

            <div 
              className="flex items-center gap-2 sm:gap-2.5 min-w-0 cursor-pointer select-none" 
              onClick={() => handleTabClick('students')}
            >
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-emerald-950 border border-emerald-800 text-amber-300 flex items-center justify-center font-bold text-lg shadow-xs overflow-hidden shrink-0">
                <img
                  src="/src/assets/images/darul_huda_logo_seal_1793076694701.jpg"
                  alt="Darul Huda University Seal"
                  className="w-full h-full object-cover"
                  onError={e => {
                    (e.currentTarget as HTMLElement).style.display = 'none';
                  }}
                />
              </div>
              <div className="min-w-0">
                <span className="text-xs sm:text-sm font-black tracking-tight text-emerald-950 dark:text-emerald-300 uppercase truncate block leading-tight">
                  DARUL HUDA ISLAMIC UNIVERSITY
                </span>
                <span className="text-[9px] sm:text-[11px] font-extrabold text-amber-700 dark:text-amber-400 tracking-wider uppercase block truncate">
                  ASSAM CENTRE · STUDENTS AFFAIRS BOARD
                </span>
              </div>
            </div>
          </div>

          {/* Zone 2: Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 sm:gap-1.5 overflow-x-auto py-1 scrollbar-none">
            {isStudent && (
              <button
                onClick={() => handleTabClick('portal')}
                className={`px-3 py-1.5 text-xs font-bold rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                  activeTab === 'portal'
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'text-emerald-900 bg-emerald-50 hover:bg-emerald-100'
                }`}
              >
                <User className="w-3.5 h-3.5 text-amber-300" />
                <span>My Portal</span>
              </button>
            )}

            {isFaculty && (
              <button
                onClick={() => handleTabClick('approvals')}
                className={`px-3 py-1.5 text-xs font-bold rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                  activeTab === 'approvals'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-amber-900 bg-amber-50 hover:bg-amber-100'
                }`}
              >
                <Clock className="w-3.5 h-3.5 text-amber-700" />
                <span>Confirmations</span>
                {pendingClaimsCount > 0 && (
                  <span className="bg-rose-600 text-white text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold animate-pulse">
                    {pendingClaimsCount}
                  </span>
                )}
              </button>
            )}

            <button
              onClick={() => handleTabClick('students')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                activeTab === 'students'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Leaderboard
            </button>
            <button
              onClick={() => handleTabClick('classes')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                activeTab === 'classes'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Batches & Unions
            </button>
            <button
              onClick={() => handleTabClick('mentors')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                activeTab === 'mentors'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Mentors (20)
            </button>
            <button
              onClick={() => handleTabClick('analytics')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                activeTab === 'analytics'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Analytics
            </button>
            <button
              onClick={() => handleTabClick('audit')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors flex items-center gap-1 ${
                activeTab === 'audit'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
              <span>Audit</span>
            </button>
            <button
              onClick={() => handleTabClick('certificates')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                activeTab === 'certificates'
                  ? 'bg-slate-900 dark:bg-slate-800 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              Certificates
            </button>
          </nav>

          {/* Zone 3: Desktop Primary Actions */}
          <div className="hidden lg:flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Desktop Theme Switcher */}
            {onToggleDarkMode && (
              <button
                onClick={onToggleDarkMode}
                title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
                className="p-1.5 px-2.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 rounded-lg transition inline-flex items-center gap-1.5 touch-manipulation"
                aria-label="Toggle theme"
              >
                {isDarkMode ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-slate-600" />}
                <span className="hidden xl:inline">{isDarkMode ? 'Light' : 'Dark'}</span>
              </button>
            )}

            {currentUser ? (
              <div className="flex items-center gap-1.5">
                {isStudent && (
                  <>
                    <button
                      onClick={onOpenIDCard}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 rounded-lg transition shadow-xs whitespace-nowrap"
                    >
                      <CreditCard className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      <span>ID Card</span>
                    </button>

                    <button
                      onClick={onOpenSubmitClaim}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-amber-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition shadow-xs whitespace-nowrap"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Add Coin</span>
                    </button>
                  </>
                )}

                {isFaculty && (
                  <>
                    <button
                      onClick={onOpenAwardCoins}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-amber-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition shadow-xs whitespace-nowrap"
                    >
                      <Coins className="w-3.5 h-3.5" />
                      <span>Award Coins</span>
                    </button>

                    <button
                      onClick={onOpenTransactions}
                      className="p-1.5 sm:px-2.5 sm:py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-lg transition inline-flex items-center gap-1"
                      title="View Coin Ledger"
                    >
                      <History className="w-3.5 h-3.5" />
                      <span>Ledger</span>
                    </button>
                  </>
                )}

                {isSuperAdmin && (
                  <>
                    <button
                      onClick={onOpenAddStudent}
                      className="p-1.5 sm:px-2.5 sm:py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-lg transition inline-flex items-center gap-1"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>+ Student</span>
                    </button>

                    <button
                      onClick={onOpenAddMentor}
                      className="p-1.5 sm:px-2.5 sm:py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-lg transition inline-flex items-center gap-1"
                    >
                      <Award className="w-3.5 h-3.5" />
                      <span>+ Mentor</span>
                    </button>

                    <button
                      onClick={onOpenSuperAdminConsole}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-amber-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition shadow-xs whitespace-nowrap"
                    >
                      <ShieldAlert className="w-3.5 h-3.5" />
                      <span>Admin Console</span>
                    </button>
                  </>
                )}

                <button
                  onClick={onOpenChangePassword}
                  className="p-1.5 sm:px-2.5 sm:py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-lg transition inline-flex items-center gap-1"
                  title="Change Password"
                >
                  <KeyRound className="w-3.5 h-3.5 text-slate-600 dark:text-slate-400" />
                  <span className="hidden xl:inline">Password</span>
                </button>

                <div className="flex items-center text-xs text-slate-600 dark:text-slate-300 font-mono px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg">
                  <span className="truncate max-w-[120px] font-semibold text-slate-800 dark:text-slate-100">
                    {currentUser.displayName}
                  </span>
                </div>

                <button
                  onClick={onLogout}
                  title="Sign Out"
                  className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenLogin}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-slate-900 dark:text-slate-100 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 rounded-lg transition whitespace-nowrap"
              >
                <LogIn className="w-3.5 h-3.5 text-slate-700 dark:text-slate-300" />
                <span>Sign In / Login</span>
              </button>
            )}

            <button
              onClick={onExportCleanedCSV}
              title="Download Cleaned CSV"
              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 rounded-lg transition whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              <span>CSV</span>
            </button>

            <button
              onClick={onResetData}
              title="Reset to 0 coins"
              className="p-1.5 text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Zone 4: Mobile Actions Right Side (Theme toggle + Quick Action Button) */}
          <div className="flex items-center gap-1.5 lg:hidden">
            {/* Mobile Dark Mode Toggle Icon */}
            {onToggleDarkMode && (
              <button
                onClick={onToggleDarkMode}
                className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-amber-300 border border-slate-200 dark:border-slate-700 transition touch-manipulation min-w-[38px] min-h-[38px] flex items-center justify-center shrink-0"
                title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
                aria-label="Toggle theme"
              >
                {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
              </button>
            )}

            {currentUser ? (
              <div className="flex items-center gap-1">
                {isFaculty && (
                  <button
                    onClick={onOpenAwardCoins}
                    className="p-2 text-amber-950 bg-amber-400 hover:bg-amber-300 rounded-lg shadow-xs touch-manipulation min-w-[38px] min-h-[38px] flex items-center justify-center"
                    title="Award Coins"
                  >
                    <Coins className="w-4 h-4" />
                  </button>
                )}
                {isStudent && (
                  <button
                    onClick={onOpenSubmitClaim}
                    className="p-2 text-amber-950 bg-amber-400 hover:bg-amber-300 rounded-lg shadow-xs touch-manipulation min-w-[38px] min-h-[38px] flex items-center justify-center"
                    title="Add Coin Claim"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                )}
                {isSuperAdmin && (
                  <button
                    onClick={onOpenSuperAdminConsole}
                    className="p-2 text-amber-950 bg-amber-400 hover:bg-amber-300 rounded-lg shadow-xs touch-manipulation min-w-[38px] min-h-[38px] flex items-center justify-center"
                    title="Admin Console"
                  >
                    <ShieldAlert className="w-4 h-4" />
                  </button>
                )}
              </div>
            ) : (
              <button
                onClick={onOpenLogin}
                className="px-2.5 py-1.5 text-xs font-bold text-slate-900 dark:text-slate-100 bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg whitespace-nowrap min-h-[38px] flex items-center"
              >
                Login
              </button>
            )}
          </div>
        </div>

        {/* Mobile Horizontal Quick Tab Scroller (Always reachable on mobile) */}
        <div className="flex lg:hidden items-center gap-1 overflow-x-auto py-2 border-t border-slate-100 dark:border-slate-800 text-xs scrollbar-none">
          {isStudent && (
            <button
              onClick={() => handleTabClick('portal')}
              className={`px-3 py-1.5 font-bold rounded-lg whitespace-nowrap touch-manipulation ${
                activeTab === 'portal' ? 'bg-emerald-800 dark:bg-emerald-700 text-white' : 'text-emerald-900 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60'
              }`}
            >
              My Portal
            </button>
          )}
          {isFaculty && (
            <button
              onClick={() => handleTabClick('approvals')}
              className={`px-3 py-1.5 font-bold rounded-lg whitespace-nowrap touch-manipulation ${
                activeTab === 'approvals' ? 'bg-amber-600 text-white' : 'text-amber-900 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/60'
              }`}
            >
              Confirmations {pendingClaimsCount > 0 ? `(${pendingClaimsCount})` : ''}
            </button>
          )}
          <button
            onClick={() => handleTabClick('students')}
            className={`px-3 py-1.5 font-semibold rounded-lg whitespace-nowrap touch-manipulation ${
              activeTab === 'students' ? 'bg-slate-900 dark:bg-slate-800 text-white' : 'text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800/80'
            }`}
          >
            Leaderboard
          </button>
          <button
            onClick={() => handleTabClick('classes')}
            className={`px-3 py-1.5 font-semibold rounded-lg whitespace-nowrap touch-manipulation ${
              activeTab === 'classes' ? 'bg-slate-900 dark:bg-slate-800 text-white' : 'text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800/80'
            }`}
          >
            Batches & Unions
          </button>
          <button
            onClick={() => handleTabClick('mentors')}
            className={`px-3 py-1.5 font-semibold rounded-lg whitespace-nowrap touch-manipulation ${
              activeTab === 'mentors' ? 'bg-slate-900 dark:bg-slate-800 text-white' : 'text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800/80'
            }`}
          >
            Mentors
          </button>
          <button
            onClick={() => handleTabClick('analytics')}
            className={`px-3 py-1.5 font-semibold rounded-lg whitespace-nowrap touch-manipulation ${
              activeTab === 'analytics' ? 'bg-slate-900 dark:bg-slate-800 text-white' : 'text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800/80'
            }`}
          >
            Analytics
          </button>
          <button
            onClick={() => handleTabClick('audit')}
            className={`px-3 py-1.5 font-semibold rounded-lg whitespace-nowrap touch-manipulation ${
              activeTab === 'audit' ? 'bg-emerald-800 dark:bg-emerald-700 text-white' : 'text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800/80'
            }`}
          >
            Audit
          </button>
          <button
            onClick={() => handleTabClick('certificates')}
            className={`px-3 py-1.5 font-semibold rounded-lg whitespace-nowrap touch-manipulation ${
              activeTab === 'certificates' ? 'bg-slate-900 dark:bg-slate-800 text-white' : 'text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800/80'
            }`}
          >
            Certificates
          </button>
        </div>
      </div>

      {/* Mobile Drawer (Full Menu for Mobile Users) */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-4 space-y-4 shadow-xl animate-in slide-in-from-top-4 duration-150 max-h-[80vh] overflow-y-auto">
          {/* Mobile Theme Toggle Card */}
          {onToggleDarkMode && (
            <div className="flex items-center justify-between p-3 bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl">
              <div className="flex items-center gap-2.5">
                {isDarkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-slate-700 dark:text-slate-300" />}
                <div>
                  <div className="text-xs font-bold text-slate-900 dark:text-slate-100">Dark Mode</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">
                    {isDarkMode ? 'Dark theme enabled' : 'Light theme enabled'}
                  </div>
                </div>
              </div>
              <button
                onClick={onToggleDarkMode}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition ${
                  isDarkMode 
                    ? 'bg-amber-400 text-amber-950 border-amber-500 hover:bg-amber-300' 
                    : 'bg-slate-900 text-white border-slate-700 hover:bg-slate-800'
                }`}
              >
                {isDarkMode ? 'Turn Off' : 'Turn On'}
              </button>
            </div>
          )}

          {currentUser && (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl flex items-center justify-between">
              <div>
                <div className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider">
                  Signed In ({currentUser.role})
                </div>
                <div className="text-sm font-bold text-slate-900 dark:text-slate-100">{currentUser.displayName}</div>
              </div>
              <button
                onClick={() => {
                  onLogout();
                  setMobileMenuOpen(false);
                }}
                className="px-2.5 py-1.5 text-xs font-semibold text-rose-700 dark:text-rose-300 bg-white dark:bg-slate-800 border border-rose-200 dark:border-rose-900 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/50"
              >
                Sign Out
              </button>
            </div>
          )}

          {/* Action Grid for Mobile */}
          <div className="space-y-1.5">
            <div className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider px-1">Quick Actions</div>
            <div className="grid grid-cols-2 gap-2">
              {isSuperAdmin && (
                <>
                  <button
                    onClick={() => {
                      onOpenSuperAdminConsole?.();
                      setMobileMenuOpen(false);
                    }}
                    className="p-3 text-left bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/40 border border-amber-300 dark:border-amber-700 rounded-xl flex items-center gap-2 text-xs font-bold text-amber-950 dark:text-amber-200"
                  >
                    <ShieldAlert className="w-4 h-4 text-amber-700 dark:text-amber-400 shrink-0" />
                    <span>Admin Console</span>
                  </button>

                  <button
                    onClick={() => {
                      onOpenAwardCoins();
                      setMobileMenuOpen(false);
                    }}
                    className="p-3 text-left bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 border border-emerald-200 dark:border-emerald-800 rounded-xl flex items-center gap-2 text-xs font-bold text-emerald-950 dark:text-emerald-200"
                  >
                    <Coins className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                    <span>Award Coins</span>
                  </button>

                  <button
                    onClick={() => {
                      onOpenAddStudent();
                      setMobileMenuOpen(false);
                    }}
                    className="p-3 text-left bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200"
                  >
                    <UserPlus className="w-4 h-4 text-slate-600 dark:text-slate-400 shrink-0" />
                    <span>+ New Student</span>
                  </button>

                  <button
                    onClick={() => {
                      onOpenAddMentor();
                      setMobileMenuOpen(false);
                    }}
                    className="p-3 text-left bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200"
                  >
                    <Award className="w-4 h-4 text-slate-600 dark:text-slate-400 shrink-0" />
                    <span>+ New Mentor</span>
                  </button>

                  <button
                    onClick={() => {
                      onOpenTransactions();
                      setMobileMenuOpen(false);
                    }}
                    className="p-3 text-left bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200"
                  >
                    <History className="w-4 h-4 text-slate-600 dark:text-slate-400 shrink-0" />
                    <span>Ledger & Revoke</span>
                  </button>
                </>
              )}

              {isTeacher && (
                <>
                  <button
                    onClick={() => {
                      onOpenAwardCoins();
                      setMobileMenuOpen(false);
                    }}
                    className="p-3 text-left bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 border border-emerald-200 dark:border-emerald-800 rounded-xl flex items-center gap-2 text-xs font-bold text-emerald-950 dark:text-emerald-200"
                  >
                    <Coins className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                    <span>Award Coins</span>
                  </button>

                  <button
                    onClick={() => {
                      onOpenTransactions();
                      setMobileMenuOpen(false);
                    }}
                    className="p-3 text-left bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200"
                  >
                    <History className="w-4 h-4 text-slate-600 dark:text-slate-400 shrink-0" />
                    <span>Coin Ledger</span>
                  </button>
                </>
              )}

              {isStudent && (
                <>
                  <button
                    onClick={() => {
                      onOpenIDCard?.();
                      setMobileMenuOpen(false);
                    }}
                    className="p-3 text-left bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 border border-emerald-200 dark:border-emerald-800 rounded-xl flex items-center gap-2 text-xs font-bold text-emerald-950 dark:text-emerald-200"
                  >
                    <CreditCard className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                    <span>My ID Card</span>
                  </button>

                  <button
                    onClick={() => {
                      onOpenSubmitClaim?.();
                      setMobileMenuOpen(false);
                    }}
                    className="p-3 text-left bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/40 border border-amber-300 dark:border-amber-700 rounded-xl flex items-center gap-2 text-xs font-bold text-amber-950 dark:text-amber-200"
                  >
                    <Send className="w-4 h-4 text-amber-700 dark:text-amber-400 shrink-0" />
                    <span>Add Coin Claim</span>
                  </button>
                </>
              )}

              {currentUser && (
                <button
                  onClick={() => {
                    onOpenChangePassword?.();
                    setMobileMenuOpen(false);
                  }}
                  className="p-3 text-left bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200"
                >
                  <KeyRound className="w-4 h-4 text-slate-600 dark:text-slate-400 shrink-0" />
                  <span>Change Password</span>
                </button>
              )}

              {!currentUser && (
                <button
                  onClick={() => {
                    onOpenLogin();
                    setMobileMenuOpen(false);
                  }}
                  className="p-3 text-left bg-emerald-950 text-white rounded-xl flex items-center gap-2 text-xs font-bold col-span-2 justify-center shadow-md"
                >
                  <LogIn className="w-4 h-4 text-amber-400" />
                  <span>Sign In to Institutional Portal</span>
                </button>
              )}

              <button
                onClick={() => {
                  onExportCleanedCSV();
                  setMobileMenuOpen(false);
                }}
                className="p-3 text-left bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                <Download className="w-4 h-4 text-emerald-700 dark:text-emerald-400 shrink-0" />
                <span>Export CSV</span>
              </button>

              <button
                onClick={() => {
                  onResetData();
                  setMobileMenuOpen(false);
                }}
                className="p-3 text-left bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                <RefreshCw className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" />
                <span>Reset 0-Base</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
