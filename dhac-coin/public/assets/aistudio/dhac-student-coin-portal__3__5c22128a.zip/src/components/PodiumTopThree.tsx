import React from 'react';
import { StudentRecord } from '../types/student';
import { Crown, Medal, Award, ChevronRight } from 'lucide-react';

interface PodiumTopThreeProps {
  students: StudentRecord[];
  onSelectStudent: (student: StudentRecord) => void;
}

export const PodiumTopThree: React.FC<PodiumTopThreeProps> = ({ students, onSelectStudent }) => {
  // Sort students by campusRankNum
  const sorted = [...students].sort((a, b) => a.campusRankNum - b.campusRankNum);
  const first = sorted[0];
  const second = sorted[1];
  const third = sorted[2];
  const runnersUp = sorted.slice(3, 7); // Rank 4 to 7

  if (!first || !second || !third) return null;

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 mb-6 shadow-xs transition-colors duration-150">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 gap-2">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Crown className="w-4 h-4 text-amber-500" />
            Campus Honor Roll · Top Coin Achievers
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Recognizing highest cumulative merit coin milestones across all classes
          </p>
        </div>
        <div className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
          Cutoff for Top 3: <span className="font-semibold text-slate-800 dark:text-slate-200">60+ Coins</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 mb-4">
        {/* 2nd Place */}
        <div
          onClick={() => onSelectStudent(second)}
          className="border border-slate-200 dark:border-slate-700/80 rounded-xl p-4 bg-slate-50/50 dark:bg-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-600 transition cursor-pointer flex flex-col justify-between order-2 md:order-1 relative"
        >
          <div className="flex items-start justify-between">
            <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center font-bold text-sm font-mono">
              2
            </div>
            <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
              Campus {second.campusRank}
            </span>
          </div>

          <div className="my-3">
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base leading-snug hover:text-emerald-700 dark:hover:text-emerald-400 transition-colors">
              {second.name}
            </h3>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
              <span>Class {second.className}</span>
              <span aria-hidden="true">·</span>
              <span>AD #{second.adNo}</span>
            </div>
            <div className="text-xs text-slate-600 dark:text-slate-300 mt-1 truncate" title={second.mentorName}>
              Mentor: {second.mentorName}
            </div>
          </div>

          <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400">Group {second.mentorGroupRank}</span>
            <span className="text-lg font-bold font-mono tabular-nums text-slate-700 dark:text-slate-200">
              {second.totalCoins} <span className="text-xs font-normal text-slate-500 dark:text-slate-400">coins</span>
            </span>
          </div>
        </div>

        {/* 1st Place (Champion) */}
        <div
          onClick={() => onSelectStudent(first)}
          className="border-2 border-amber-300 dark:border-amber-600 rounded-xl p-5 bg-amber-50/40 dark:bg-amber-950/30 hover:bg-amber-50/70 dark:hover:bg-amber-950/50 hover:border-amber-400 dark:hover:border-amber-500 transition cursor-pointer flex flex-col justify-between order-1 md:order-2 shadow-sm relative"
        >
          <div className="flex items-start justify-between">
            <div className="w-10 h-10 rounded-full bg-amber-400 text-amber-950 flex items-center justify-center font-bold text-base font-mono shadow-xs">
              <Crown className="w-5 h-5 text-amber-900" />
            </div>
            <span className="text-xs font-semibold text-amber-800 dark:text-amber-300 font-mono">
              Campus Champion #{first.campusRankNum}
            </span>
          </div>

          <div className="my-3">
            <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-lg leading-snug">
              {first.name}
            </h3>
            <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300 mt-1">
              <span className="font-semibold text-emerald-800 dark:text-emerald-300">Class {first.className} (Rank {first.classRank})</span>
              <span aria-hidden="true">·</span>
              <span>AD #{first.adNo}</span>
            </div>
            <div className="text-xs text-slate-600 dark:text-slate-300 mt-1 truncate" title={first.mentorName}>
              Mentor: {first.mentorName}
            </div>
          </div>

          <div className="pt-2 border-t border-amber-200 dark:border-amber-800/60 flex items-center justify-between">
            <span className="text-xs text-amber-800 dark:text-amber-300 font-medium">Group {first.mentorGroupRank}</span>
            <span className="text-2xl font-extrabold font-mono tabular-nums text-amber-900 dark:text-amber-300">
              {first.totalCoins} <span className="text-xs font-semibold text-amber-700 dark:text-amber-400">coins</span>
            </span>
          </div>
        </div>

        {/* 3rd Place */}
        <div
          onClick={() => onSelectStudent(third)}
          className="border border-slate-200 dark:border-slate-700/80 rounded-xl p-4 bg-slate-50/50 dark:bg-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-600 transition cursor-pointer flex flex-col justify-between order-3 relative"
        >
          <div className="flex items-start justify-between">
            <div className="w-8 h-8 rounded-full bg-amber-700/20 dark:bg-amber-900/40 text-amber-900 dark:text-amber-300 flex items-center justify-center font-bold text-sm font-mono">
              3
            </div>
            <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
              Campus {third.campusRank}
            </span>
          </div>

          <div className="my-3">
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base leading-snug hover:text-emerald-700 dark:hover:text-emerald-400 transition-colors">
              {third.name}
            </h3>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
              <span>Class {third.className}</span>
              <span aria-hidden="true">·</span>
              <span>AD #{third.adNo}</span>
            </div>
            <div className="text-xs text-slate-600 dark:text-slate-300 mt-1 truncate" title={third.mentorName}>
              Mentor: {third.mentorName}
            </div>
          </div>

          <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400">Group {third.mentorGroupRank}</span>
            <span className="text-lg font-bold font-mono tabular-nums text-amber-800 dark:text-amber-400">
              {third.totalCoins} <span className="text-xs font-normal text-slate-500 dark:text-slate-400">coins</span>
            </span>
          </div>
        </div>
      </div>

      {/* Runners-up Bar (45 coins tier) */}
      <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
        <div className="text-xs text-slate-500 dark:text-slate-400 font-medium mb-2">
          Runners Up (Campus Ranks 4–7 · 45 Coins Achievers):
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {runnersUp.map(student => (
            <div
              key={student.id}
              onClick={() => onSelectStudent(student)}
              className="px-3 py-2 border border-slate-100 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 rounded-lg text-left cursor-pointer bg-slate-50/40 dark:bg-slate-800/40 hover:bg-slate-50 dark:hover:bg-slate-800 transition"
            >
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-mono">
                <span>{student.campusRank}</span>
                <span className="font-semibold text-slate-700 dark:text-slate-300">{student.totalCoins}c</span>
              </div>
              <div className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate mt-0.5">
                {student.name}
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                {student.className} · {student.mentorName.split(' ')[0]}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
